#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"

# Guard against environments where the resolved path unexpectedly omits the
# leading slash (for example when `pwd` respects a pre-set `PWD` value).  The
# systemd unit we generate later requires an absolute `WorkingDirectory`, so we
# normalise the value defensively here.
if [[ "${SCRIPT_DIR}" != /* ]]; then
  if command -v python3 >/dev/null 2>&1; then
    SCRIPT_DIR="$(python3 - "$SCRIPT_DIR" <<'PY'
import os
import sys

print(os.path.abspath(sys.argv[1]))
PY
)"
  else
    SCRIPT_DIR="/$(printf '%s' "${SCRIPT_DIR}" | sed 's#^\./##')"
  fi
fi

BACKEND_ENV_FILE="${SCRIPT_DIR}/backend.env"
COMPOSE_ENV_FILE="${SCRIPT_DIR}/.env"
NGINX_TEMPLATE_FILE="${SCRIPT_DIR}/nginx.host.conf.template"

DEFAULT_NGINX_SITE_NAME="culinary-creation-collective"
DEFAULT_SYSTEMD_SERVICE_NAME="culinary-creation-collective"

NGINX_SITE_NAME="${NGINX_SITE_NAME:-${DEFAULT_NGINX_SITE_NAME}}"
SYSTEMD_SERVICE_NAME="${SYSTEMD_SERVICE_NAME:-${DEFAULT_SYSTEMD_SERVICE_NAME}}"

declare -a COMPOSE_CMD
declare -a ENV_WARNINGS
declare -a ENV_NOTICES
declare -a POST_DEPLOY_WARNINGS
SYSTEMD_SERVICE_CREATED=0
APT_UPDATED=0

secure_env_file() {
  local file="$1"

  if [ -f "${file}" ]; then
    chmod 600 "${file}" || true
  fi
}

assert_required_files() {
  local missing=0
  local path

  for path in "$@"; do
    if [ ! -e "${path}" ]; then
      echo "Required file ${path} is missing. Ensure the repository was extracted completely." >&2
      missing=1
    fi
  done

  if [ "${missing}" -ne 0 ]; then
    exit 1
  fi
}

sanitize_compose_project_name() {
  local raw="$1"

  raw="${raw,,}"
  raw="${raw//[^a-z0-9_-]/-}"
  raw="${raw#-}"
  raw="${raw%-}"

  if [ -z "${raw}" ]; then
    raw="culinary-creation-collective"
  fi

  printf '%s\n' "${raw}"
}

ensure_compose_project_name() {
  local raw="${COMPOSE_PROJECT_NAME-}"
  local sanitized

  if [ -z "${raw}" ]; then
    raw="${SYSTEMD_SERVICE_NAME}"
  fi

  sanitized="$(sanitize_compose_project_name "${raw}")"

  if [ -n "${COMPOSE_PROJECT_NAME-}" ] && [ "${sanitized}" != "${raw}" ]; then
    ENV_NOTICES+=("Normalized COMPOSE_PROJECT_NAME to ${sanitized}")
  fi

  export COMPOSE_PROJECT_NAME="${sanitized}"
}

ensure_prerequisite() {
  local binary="$1"
  local package="$2"

  if command -v "${binary}" >/dev/null 2>&1; then
    return
  fi

  echo "Installing missing dependency: ${binary}" >&2

  if command -v apt-get >/dev/null 2>&1; then
    if [ "${APT_UPDATED}" -eq 0 ]; then
      DEBIAN_FRONTEND=noninteractive apt-get update
      APT_UPDATED=1
    fi
    DEBIAN_FRONTEND=noninteractive apt-get install -y "${package}"
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y "${package}"
  elif command -v yum >/dev/null 2>&1; then
    yum install -y "${package}"
  elif command -v apk >/dev/null 2>&1; then
    apk add --no-cache "${package}"
  else
    echo "Unsupported package manager. Please install ${package} manually." >&2
    exit 1
  fi
}

install_docker() {
  if command -v docker >/dev/null 2>&1; then
    if command -v systemctl >/dev/null 2>&1; then
      systemctl enable docker >/dev/null 2>&1 || true
      systemctl start docker >/dev/null 2>&1 || true
    fi
    return
  fi

  ensure_prerequisite curl curl

  echo "Docker not found. Installing using the official convenience script..."
  curl -fsSL https://get.docker.com | sh

  if command -v systemctl >/dev/null 2>&1; then
    systemctl enable docker
    systemctl start docker
  fi
}

install_compose_plugin() {
  if docker compose version >/dev/null 2>&1; then
    return
  fi

  if command -v docker-compose >/dev/null 2>&1; then
    return
  fi

  ensure_prerequisite curl curl

  echo "Docker Compose plugin not found. Installing..."
  mkdir -p /usr/lib/docker/cli-plugins
  curl -SL "https://github.com/docker/compose/releases/download/v2.27.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/lib/docker/cli-plugins/docker-compose
  chmod +x /usr/lib/docker/cli-plugins/docker-compose
}

install_nginx() {
  if command -v nginx >/dev/null 2>&1; then
    if command -v systemctl >/dev/null 2>&1; then
      systemctl enable nginx >/dev/null 2>&1 || true
      systemctl start nginx >/dev/null 2>&1 || true
    fi
    return
  fi

  echo "Installing Nginx..."
  ensure_prerequisite nginx nginx

  if command -v systemctl >/dev/null 2>&1; then
    systemctl enable nginx
    systemctl start nginx
  elif command -v service >/dev/null 2>&1; then
    service nginx start
  fi
}

escape_sed() {
  printf '%s' "$1" | sed -e 's/[\\&/]/\\\\&/g'
}

escape_systemd_path() {
  local path="$1"

  if ! command -v python3 >/dev/null 2>&1; then
    ensure_prerequisite python3 python3
  fi

  python3 - "$path" <<'PY'
import sys

path = sys.argv[1]

def escape_char(ch: str) -> str:
    code = ord(ch)

    if ch == '\\':
        return '\\x5c'

    if code < 32 or code == 127:
        return f'\\x{code:02x}'

    if ch in {' ', '\t'}:
        return f'\\x{code:02x}'

    return ch


print(''.join(escape_char(ch) for ch in path), end='')
PY
}

render_nginx_config() {
  local server_name="$1"
  local backend_port="$2"
  local frontend_port="$3"
  local client_max_body_size="$4"
  local destination="$5"

  if [ ! -f "${NGINX_TEMPLATE_FILE}" ]; then
    echo "Nginx template ${NGINX_TEMPLATE_FILE} is missing." >&2
    exit 1
  fi

  sed \
    -e "s/{{SERVER_NAME}}/$(escape_sed "${server_name}")/g" \
    -e "s/{{BACKEND_PORT}}/$(escape_sed "${backend_port}")/g" \
    -e "s/{{FRONTEND_PORT}}/$(escape_sed "${frontend_port}")/g" \
    -e "s/{{NGINX_CLIENT_MAX_BODY_SIZE}}/$(escape_sed "${client_max_body_size}")/g" \
    "${NGINX_TEMPLATE_FILE}" >"${destination}"
}

reload_nginx() {
  if command -v systemctl >/dev/null 2>&1; then
    systemctl reload nginx
  elif command -v service >/dev/null 2>&1; then
    service nginx reload
  else
    nginx -s reload
  fi
}

configure_nginx() {
  local server_name="${SERVER_NAME:-_}"
  local backend_port="${BACKEND_PORT:-8000}"
  local frontend_port="${FRONTEND_PORT:-8080}"
  local client_max_body_size="${NGINX_CLIENT_MAX_BODY_SIZE:-25m}"
  local nginx_available="/etc/nginx/sites-available"
  local nginx_enabled="/etc/nginx/sites-enabled"
  local config_path="${nginx_available}/${NGINX_SITE_NAME}.conf"

  mkdir -p "${nginx_available}" "${nginx_enabled}"

  if [ -f "${config_path}" ]; then
    cp "${config_path}" "${config_path}.$(date +%Y%m%d%H%M%S).bak"
  fi

  render_nginx_config "${server_name}" "${backend_port}" "${frontend_port}" "${client_max_body_size}" "${config_path}"

  ln -sf "${config_path}" "${nginx_enabled}/${NGINX_SITE_NAME}.conf"

  local default_site="${nginx_enabled}/default"
  if [ -L "${default_site}" ]; then
    rm -f "${default_site}"
  fi

  if nginx -t >/dev/null 2>&1; then
    reload_nginx
  else
    echo "Nginx configuration test failed." >&2
    exit 1
  fi
}

ensure_env_file() {
  local example_file="$1"
  local target_file="$2"

  if [ -f "${target_file}" ]; then
    secure_env_file "${target_file}"
    echo "Using existing ${target_file}"
    return
  fi

  echo "${target_file} not found. Creating it from ${example_file}"
  cp "${example_file}" "${target_file}"
  secure_env_file "${target_file}"
  ENV_WARNINGS+=("${target_file}")
}

read_env_var() {
  local file="$1"
  local key="$2"

  if [ ! -f "${file}" ]; then
    return
  fi

  if ! command -v python3 >/dev/null 2>&1; then
    ensure_prerequisite python3 python3
  fi

  python3 - <<'PY' "${file}" "${key}" || true
import os
import sys

path, key = sys.argv[1:3]
value = ""
if os.path.exists(path):
    with open(path, "r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith(key + "="):
                value = line[len(key) + 1 :].rstrip("\n")
print(value, end="")
PY
}

set_env_var() {
  local file="$1"
  local key="$2"
  local value="$3"
  local escaped_value

  escaped_value="$(escape_sed "${value}")"

  if grep -q "^${key}=" "${file}"; then
    sed -i "s/^${key}=.*/${key}=${escaped_value}/" "${file}"
  else
    printf '%s=%s\n' "${key}" "${value}" >>"${file}"
  fi
}

apply_env_override() {
  local file="$1"
  local key="$2"
  local env_value
  local current_value

  if [ -z "${key}" ]; then
    return
  fi

  env_value="${!key-}"

  if [ -z "${env_value}" ]; then
    return
  fi

  current_value="$(read_env_var "${file}" "${key}")"

  if [ "${current_value}" = "${env_value}" ]; then
    return
  fi

  set_env_var "${file}" "${key}" "${env_value}"
  ENV_NOTICES+=("Applied environment override for ${key} in ${file}")
}

apply_env_overrides() {
  local file="$1"
  shift

  if [ -z "${file}" ] || [ ! -f "${file}" ]; then
    return
  fi

  local key
  for key in "$@"; do
    apply_env_override "${file}" "${key}"
  done
}

generate_secret_key() {
  ensure_prerequisite python3 python3

  python3 - <<'PY'
import secrets

print(secrets.token_urlsafe(64))
PY
}

ensure_secret_key() {
  local env_file="$1"
  local current_key

  if ! command -v python3 >/dev/null 2>&1; then
    ensure_prerequisite python3 python3
  fi

  current_key="$(read_env_var "${env_file}" "SECRET_KEY")"

  if [ -z "${current_key}" ] || [ "${current_key}" = "change-me" ]; then
    local new_key
    new_key="$(generate_secret_key)"
    set_env_var "${env_file}" "SECRET_KEY" "${new_key}"
    chmod 600 "${env_file}" || true
    ENV_NOTICES+=("Generated a random SECRET_KEY in ${env_file}")
  fi
}

update_backend_env_defaults() {
  local env_file="$1"
  local server_name="$2"

  if [ -z "${server_name}" ] || [ "${server_name}" = "_" ]; then
    return
  fi

  if ! command -v python3 >/dev/null 2>&1; then
    ensure_prerequisite python3 python3
  fi

  local result
  result="$(
      python3 - "${env_file}" "${server_name}" <<'PY'
import sys
from pathlib import Path

env_path = Path(sys.argv[1])
server_name = sys.argv[2]

# Remove any port suffix that may be present in SERVER_NAME
hostname = server_name.split(":", 1)[0]

http_origin = f"http://{server_name}"
https_origin = f"https://{server_name}"

lines = []
if env_path.exists():
    lines = env_path.read_text(encoding="utf-8").splitlines()

index = None
origins = []
cookie_idx = None
cookie_value = ""
for idx, line in enumerate(lines):
    if line.startswith("ALLOWED_ORIGINS="):
        index = idx
        origins = [item.strip() for item in line.split("=", 1)[1].split(",") if item.strip()]
    elif line.startswith("COOKIE_DOMAIN="):
        cookie_idx = idx
        cookie_value = line.split("=", 1)[1].strip()

origins_updated = False
for candidate in (http_origin, https_origin):
    if candidate not in origins:
        origins.append(candidate)
        origins_updated = True

cookie_updated = False
if not cookie_value and hostname not in {"_", ""}:
    cookie_value = hostname
    cookie_updated = True

if origins_updated:
    new_line = "ALLOWED_ORIGINS=" + ",".join(origins)
    if index is None:
        lines.append(new_line)
    else:
        lines[index] = new_line

if cookie_updated:
    new_line = "COOKIE_DOMAIN=" + cookie_value
    if cookie_idx is None:
        lines.append(new_line)
    else:
        lines[cookie_idx] = new_line

if origins_updated or cookie_updated:
    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("updated_origins" if origins_updated else "", end="")
    print(" updated_cookie" if cookie_updated else "", end="")
PY
  )"

  if printf '%s' "${result}" | grep -q "updated_origins"; then
    ENV_NOTICES+=("Appended production origins to ALLOWED_ORIGINS in ${env_file}")
  fi

  if printf '%s' "${result}" | grep -q "updated_cookie"; then
    ENV_NOTICES+=("Set COOKIE_DOMAIN to ${server_name%:*} in ${env_file}")
  fi
}

gather_configuration_warnings() {
  local stripe_secret
  local stripe_publishable

  if [ "${SERVER_NAME:-_}" = "_" ]; then
    POST_DEPLOY_WARNINGS+=("SERVER_NAME is still set to '_' in ${COMPOSE_ENV_FILE}. Set it to your public hostname before exposing the site.")
  fi

  stripe_secret="$(read_env_var "${BACKEND_ENV_FILE}" "STRIPE_SECRET_KEY")"
  if [ -z "${stripe_secret}" ]; then
    POST_DEPLOY_WARNINGS+=("STRIPE_SECRET_KEY is empty in ${BACKEND_ENV_FILE}. Payment flows will fail until a real key is provided.")
  fi

  stripe_publishable="$(read_env_var "${BACKEND_ENV_FILE}" "STRIPE_PUBLISHABLE_KEY")"
  if [ -z "${stripe_publishable}" ]; then
    POST_DEPLOY_WARNINGS+=("STRIPE_PUBLISHABLE_KEY is empty in ${BACKEND_ENV_FILE}. The frontend checkout will remain disabled until it is configured.")
  fi
}

update_compose_env_defaults() {
  local env_file="$1"

  if ! command -v python3 >/dev/null 2>&1; then
    ensure_prerequisite python3 python3
  fi

  local server_name
  server_name="$(read_env_var "${env_file}" "SERVER_NAME")"

  if [ -z "${server_name}" ] || [ "${server_name}" = "_" ]; then
    return
  fi

  local vite_api
  vite_api="$(read_env_var "${env_file}" "VITE_API_BASE_URL")"
  local suggested="http://${server_name}/api"

  if [ -z "${vite_api}" ] || [ "${vite_api}" = "http://localhost/api" ] || [ "${vite_api}" = "http://localhost:8000/api" ]; then
    set_env_var "${env_file}" "VITE_API_BASE_URL" "${suggested}"
    ENV_NOTICES+=("Updated VITE_API_BASE_URL in ${env_file} to ${suggested}")
  fi
}

load_compose_env() {
  set -a
  # shellcheck disable=SC1090
  source "${COMPOSE_ENV_FILE}"
  set +a
}

determine_compose_command() {
  if docker compose version >/dev/null 2>&1; then
    COMPOSE_CMD=("$(command -v docker)" compose)
  elif command -v docker-compose >/dev/null 2>&1; then
    COMPOSE_CMD=("$(command -v docker-compose)")
  else
    echo "Docker Compose is required but was not installed successfully." >&2
    exit 1
  fi
}

configure_docker_group() {
  local target_user="${SUDO_USER:-}"

  if [ -z "${target_user}" ] || [ "${target_user}" = "root" ]; then
    return
  fi

  if ! getent group docker >/dev/null 2>&1; then
    groupadd docker
  fi

  if id -nG "${target_user}" | tr ' ' '\n' | grep -qx docker; then
    return
  fi

  usermod -aG docker "${target_user}"
  echo "Added ${target_user} to the docker group. Log out and back in to use Docker without sudo."
}

create_systemd_service() {
  if ! command -v systemctl >/dev/null 2>&1; then
    echo "systemd is not available. Skipping service installation."
    return
  fi

  if [ "${#COMPOSE_CMD[@]}" -eq 0 ]; then
    echo "Docker Compose command is unknown; cannot configure systemd service." >&2
    return
  fi

  local docker_bin
  docker_bin="$(command -v docker)"

  if [ -z "${docker_bin}" ]; then
    echo "Docker binary not found; cannot configure systemd service." >&2
    return
  fi

  local service_file="/etc/systemd/system/${SYSTEMD_SERVICE_NAME}.service"
  local escaped_workdir
  local project_name
  local compose_cmd
  local arg

  project_name="$(sanitize_compose_project_name "${COMPOSE_PROJECT_NAME:-${SYSTEMD_SERVICE_NAME}}")"

  escaped_workdir="$(escape_systemd_path "${SCRIPT_DIR}")"

  compose_cmd=""
  for arg in "${COMPOSE_CMD[@]}"; do
    compose_cmd+="$(printf '%q ' "${arg}")"
  done
  compose_cmd="${compose_cmd% }"

  cat <<EOF >"${service_file}"
[Unit]
Description=Culinary Creation Collective Docker stack
Requires=docker.service
After=docker.service network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=${escaped_workdir}
Environment=COMPOSE_PROJECT_NAME=${project_name}
ExecStartPre=-${compose_cmd} pull
ExecStart=${compose_cmd} up -d --build --remove-orphans
ExecStop=${compose_cmd} down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable "${SYSTEMD_SERVICE_NAME}.service"
  SYSTEMD_SERVICE_CREATED=1
}

start_stack() {
  if [ "${SYSTEMD_SERVICE_CREATED}" -eq 1 ]; then
    systemctl restart "${SYSTEMD_SERVICE_NAME}.service"
    return
  fi

  (cd "${SCRIPT_DIR}" && "${COMPOSE_CMD[@]}" pull)
  (cd "${SCRIPT_DIR}" && "${COMPOSE_CMD[@]}" up -d --build --remove-orphans)
}

wait_for_http() {
  local url="$1"
  local name="$2"
  local attempts="${3:-30}"
  local delay="${4:-2}"
  local attempt

  printf '  Waiting for %s at %s' "${name}" "${url}"

  for attempt in $(seq 1 "${attempts}"); do
    if curl --silent --fail --max-time 5 --output /dev/null "${url}"; then
      printf ' ... ready\n'
      return 0
    fi

    sleep "${delay}"
    printf '.'
  done

  printf '\n'
  echo "Timed out waiting for ${name} to respond at ${url}" >&2
  return 1
}

verify_services() {
  ensure_prerequisite curl curl

  local backend_url="http://127.0.0.1:${BACKEND_PORT:-8000}/api/health"
  local frontend_url="http://127.0.0.1:${FRONTEND_PORT:-8080}"

  echo "Verifying service health..."

  wait_for_http "${backend_url}" "Backend API"
  wait_for_http "${frontend_url}" "Frontend"
}

main() {
  if [ "${EUID}" -ne 0 ]; then
    echo "This script must be run as root or with sudo in order to install Docker and manage containers." >&2
    exit 1
  fi

  assert_required_files \
    "${SCRIPT_DIR}/docker-compose.yml" \
    "${SCRIPT_DIR}/.env.example" \
    "${SCRIPT_DIR}/backend.env.example" \
    "${NGINX_TEMPLATE_FILE}"

  install_docker
  install_compose_plugin
  install_nginx

  configure_docker_group

  ensure_env_file "${SCRIPT_DIR}/.env.example" "${COMPOSE_ENV_FILE}"
  ensure_env_file "${SCRIPT_DIR}/backend.env.example" "${BACKEND_ENV_FILE}"

  apply_env_overrides "${COMPOSE_ENV_FILE}" \
    BACKEND_IMAGE \
    FRONTEND_IMAGE \
    COMPOSE_PROJECT_NAME \
    BACKEND_PORT \
    FRONTEND_PORT \
    SERVER_NAME \
    NGINX_CLIENT_MAX_BODY_SIZE \
    VITE_API_BASE_URL \
    VITE_STRIPE_PUBLISHABLE_KEY \
    VITE_GOOGLE_CLIENT_ID \
    VITE_SENTRY_DSN

  apply_env_overrides "${BACKEND_ENV_FILE}" \
    SECRET_KEY \
    DATABASE_URL \
    ALLOWED_ORIGINS \
    STRIPE_SECRET_KEY \
    STRIPE_PUBLISHABLE_KEY \
    STRIPE_WEBHOOK_SECRET \
    STRIPE_ACCOUNT_ID \
    STRIPE_LIVE_MODE \
    GOOGLE_CLIENT_ID \
    PAYMENT_LOG_DIR \
    COOKIE_DOMAIN \
    PAYMENT_INTENT_STALE_MINUTES \
    ENV \
    RATE_LIMIT_LIMIT \
    RATE_LIMIT_PERIOD

  update_compose_env_defaults "${COMPOSE_ENV_FILE}"
  ensure_secret_key "${BACKEND_ENV_FILE}"

  load_compose_env

  ensure_compose_project_name

  echo "Using Docker Compose project name: ${COMPOSE_PROJECT_NAME}"

  update_backend_env_defaults "${BACKEND_ENV_FILE}" "${SERVER_NAME:-}"

  gather_configuration_warnings

  configure_nginx

  mkdir -p "${SCRIPT_DIR}/data"

  determine_compose_command

  create_systemd_service

  echo "Building and starting containers..."
  start_stack
  verify_services

  echo "Deployment complete. Services are available on the following ports:"
  echo "  Backend (internal): 127.0.0.1:${BACKEND_PORT:-8000}"
  echo "  Frontend (internal): 127.0.0.1:${FRONTEND_PORT:-8080}"
  echo "  Public endpoint: http://${SERVER_NAME:-_}/"

  if [ "${SYSTEMD_SERVICE_CREATED}" -eq 1 ]; then
    echo "A systemd unit (${SYSTEMD_SERVICE_NAME}.service) was installed to manage the Docker stack."
    echo "Use 'systemctl status ${SYSTEMD_SERVICE_NAME}.service' to review its state."
  fi

  if [ "${#ENV_WARNINGS[@]}" -gt 0 ]; then
    echo "The following configuration files were created from defaults:"
    for file in "${ENV_WARNINGS[@]}"; do
      echo "  - ${file}"
    done
    echo "Review and update them before rerunning the deployment if needed."
  fi

  if [ "${#ENV_NOTICES[@]}" -gt 0 ]; then
    echo "Applied the following automatic configuration updates:"
    for notice in "${ENV_NOTICES[@]}"; do
      echo "  - ${notice}"
    done
  fi

  if [ "${#POST_DEPLOY_WARNINGS[@]}" -gt 0 ]; then
    echo "Review the following deployment warnings:"
    for warning in "${POST_DEPLOY_WARNINGS[@]}"; do
      echo "  - ${warning}"
    done
  fi
}

main "$@"
