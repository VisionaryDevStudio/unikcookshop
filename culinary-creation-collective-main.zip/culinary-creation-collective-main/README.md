# Culinary Creation Collective

Culinary Creation Collective is a full-stack recipe ideation and ordering
platform. The React/Vite frontend provides the customer experience, while a
FastAPI backend powers authentication, menus, payments, and operational
workflows. Docker images are provided for both services, along with automation
that installs every prerequisite (Docker, Docker Compose, and Nginx) and keeps
the stack running under systemd for a stable production deployment.

## Monorepo layout

- `frontend/` – React + TypeScript single-page application built with Vite and
  Tailwind CSS.
- `backend/` – FastAPI application exposing REST endpoints for authentication,
  ordering, menus, and third-party integrations.
- `deploy/` – Infrastructure-as-code: Dockerfiles, docker-compose definition,
  Nginx templates, and the automated deployment script.
- `docs/` – Operational runbooks and environment configuration references.

## Local development

1. Install Node.js 20 and pnpm/npm.
2. Install Python 3.11+.
3. Copy the example environment files and provide real secrets:

   ```sh
   cp frontend/.env.example frontend/.env   # if present
   cp backend/.env.example backend/.env
   ```

4. Install dependencies and start the dev servers:

   ```sh
   npm install
   npm run dev
   ```

See [docs/environment.md](docs/environment.md) for the full list of environment
variables needed for local usage.

## Production deployment

The repository ships with an idempotent deployment script that prepares a fresh
Linux host (Debian/Ubuntu, RHEL, Rocky, Alma, Fedora, or Alpine) and brings the
entire stack online with no additional manual steps. See
[docs/deployment.md](docs/deployment.md) for a complete, scripted runbook. In
summary:

```sh
sudo ./deploy/deploy.sh
```

The script will:

- Install Docker, the Docker Compose plugin, Python, curl, and Nginx if they
  are missing.
- Create `.env` and `backend.env` from the examples (or update them with any
  overrides provided as environment variables).
- Generate a cryptographically strong `SECRET_KEY` and update default origins
  based on the configured hostname, also wiring the backend `COOKIE_DOMAIN`
  when a concrete host is supplied.
- Render and install the host-level Nginx virtual host, disabling the default
  site and reloading Nginx after validation.
- Build the backend and frontend Docker images, start them with Docker Compose,
  and verify that the health endpoints respond.
- Register a `culinary-creation-collective.service` systemd unit that keeps the
  stack running across reboots using whichever Docker Compose command (`docker
  compose` or the legacy `docker-compose`) is available on the host.
- Respect optional overrides such as `SYSTEMD_SERVICE_NAME` and
  `NGINX_SITE_NAME`, allowing multiple installations on the same machine without
  manual edits.

To change configuration non-interactively, export the desired variables before
running the script (for example
`SERVER_NAME=example.com FRONTEND_PORT=8081 sudo ./deploy/deploy.sh`). The
script writes those overrides back into the managed environment files so that
subsequent runs remain consistent.

After deployment succeeds, the frontend is served via the host's Nginx reverse
proxy (`http://<SERVER_NAME>/`), while API traffic is proxied to the backend at
`/api`.

## Additional documentation

- [docs/environment.md](docs/environment.md) – Environment variable reference.
- [docs/deployment.md](docs/deployment.md) – Automated production deployment guide.
- [docs/deployment-fa.md](docs/deployment-fa.md) – راهنمای استقرار خودکار به زبان فارسی.
- [docs/operations.md](docs/operations.md) – Operational tasks such as payment
  intent cleanup jobs.
