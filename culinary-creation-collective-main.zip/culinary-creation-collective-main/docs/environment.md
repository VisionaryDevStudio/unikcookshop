# Environment setup

Stripe keys are required for running the application locally.

## Frontend

1. Copy `.env.example` to `.env`.
2. Set `VITE_STRIPE_PUBLISHABLE_KEY` to your Stripe publishable key.
3. Optionally set `VITE_SENTRY_DSN` to your Sentry DSN to enable error monitoring.
4. Optionally set `VITE_API_PROXY_TARGET` if your backend runs on a
   different host during development.

## Backend

1. Copy `backend/.env.example` to `backend/.env`.
2. Set `SECRET_KEY` to a strong secret value used for signing JWTs. The backend
   requires this value and will raise an error at startup if it is missing.
   (The production deployment script automatically generates a secure value when
   `SECRET_KEY` is unset or still equal to `change-me`.)
3. Set `STRIPE_SECRET_KEY` to your Stripe secret key. The backend also requires
   this value and will raise an error at startup if it is missing.
4. Set `STRIPE_WEBHOOK_SECRET` to the signing secret from the Stripe CLI.
5. Optionally set `PAYMENT_INTENT_STALE_MINUTES` to adjust how long an
   incomplete Stripe PaymentIntent may remain open before being cancelled. The
   cleanup script defaults to `60` minutes.
6. Optionally set `PAYMENT_LOG_DIR` to a directory for payment logs. This
   directory should live outside the project tree and be readable/writable only
   by the service account (e.g. `/var/log/culinary-payments`).

## Webhooks

To receive payment notifications locally, install the [Stripe CLI](https://stripe.com/docs/stripe-cli) and run:

```
stripe listen --forward-to localhost:8000/api/webhooks/stripe
```

Copy the webhook signing secret from the command output and add it to `STRIPE_WEBHOOK_SECRET` in `backend/.env`.


Actual `.env` files are ignored by git. Do not commit them.

## Authentication cookies

Authentication tokens are stored in cookies with an explicit `max_age`. Once
the cookies expire, browsers automatically remove them along with their
tokens.
