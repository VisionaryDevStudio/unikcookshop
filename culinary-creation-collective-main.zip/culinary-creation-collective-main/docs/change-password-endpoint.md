# Change Password Endpoint

Front-end Settings page expects an endpoint at `/api/auth/change-password` accepting `current_password` and `new_password` to update the user's password.

## Expected Request
```
POST /api/auth/change-password
{
  "current_password": "old",
  "new_password": "new"
}
```

Server should verify current password, update to the new password, and return success or appropriate error.
