# Automated production deployment

This guide covers end-to-end deployment of the Culinary Creation Collective
stack on a fresh Linux server using the provided `deploy/deploy.sh` script. The
script is designed to be idempotent: you can re-run it at any time to pick up
configuration changes, rebuild images, or restart services without manual
intervention.

## Prerequisites

- A supported 64-bit Linux distribution with root access (Debian/Ubuntu, RHEL,
  Rocky, Alma, Fedora, or Alpine).
- Outbound internet access so the host can download system packages and Docker
  images.
- The repository contents extracted on the server (for example under
  `/opt/culinary-creation-collective`).

### Preparing the repository from a ZIP archive

1. Upload the project archive to the destination server (for instance via
   `scp` or SFTP).
2. SSH into the server as root (or use `sudo su -`) and create a target
   directory:

   ```sh
   mkdir -p /opt
   cd /opt
   ```

3. Extract the archive and ensure the deployment script is executable:

   ```sh
   unzip /path/to/culinary-creation-collective.zip
   cd culinary-creation-collective/deploy
   chmod +x deploy.sh
   ```

   The script can now be run directly from the `deploy/` directory without any
   further manual preparation.

## Running the deployment script

1. Sign in to the server as root (or use `sudo su -`).
2. Change into the repository directory and execute:

   ```sh
   sudo ./deploy/deploy.sh
   ```

The script performs the following actions automatically:

1. Installs missing dependencies: Docker Engine, the Docker Compose CLI plugin,
   curl, Python 3, and Nginx. If the host already provides the legacy
   `docker-compose` binary, the script will reuse it instead of forcing an
   upgrade.
2. Creates `deploy/.env` and `deploy/backend.env` from their respective example
   files if they do not already exist. File permissions are hardened to keep
   secrets private.
3. Applies any environment variable overrides you exported before running the
   script. For example, running `SERVER_NAME=example.com sudo ./deploy/deploy.sh`
   writes `SERVER_NAME=example.com` into `deploy/.env`.
4. Normalises the Docker Compose project name and ensures the backend has a
   secure `SECRET_KEY`. If a hostname is provided, the script appends both the
   HTTP and HTTPS versions to `ALLOWED_ORIGINS` and populates `COOKIE_DOMAIN`
   automatically so browser sessions scope cookies to the live host.
5. Generates an Nginx virtual host configuration from
   `deploy/nginx.host.conf.template`, places it in `/etc/nginx/sites-available`,
   enables it, disables the default site, and validates the configuration before
   reloading Nginx.
6. Builds/pulls the backend and frontend Docker images, starts them in detached
   mode (`docker compose up -d --build --remove-orphans`), and verifies that the
   FastAPI health endpoint and the frontend root respond over HTTP.
7. Installs or updates a `culinary-creation-collective.service` systemd unit that
   manages the Docker Compose stack so that it starts on boot and restarts if the
   script is re-run. The unit is generated dynamically to use the exact Docker
   Compose command (`docker compose` plugin or the standalone `docker-compose`
   binary) detected on the host.
8. Honours optional overrides for the systemd unit name and the Nginx site name
   (export `SYSTEMD_SERVICE_NAME` or `NGINX_SITE_NAME` before running the
   script). This makes it easy to host multiple environments side-by-side.

Before making any changes, the script verifies that `docker-compose.yml`,
`deploy/.env.example`, `deploy/backend.env.example`, and the Nginx template are
present. If the ZIP archive was extracted incompletely, the deployment stops
with a clear error message instead of leaving the host half-configured.

If critical configuration is still missing after the run—such as leaving
`SERVER_NAME` at the default `_` wildcard or omitting Stripe credentials—the
script prints explicit warnings so you can provide the necessary values before
going live.

On success the script prints the internal service ports and the public URL.

## Deployment environment variable reference

The deployment automation manages two environment files under `deploy/`:

- `.env` – Controls Docker Compose behaviour, image names, host ports, and
  frontend build-time variables.
- `backend.env` – Injected into the backend container to configure API
  behaviour and secrets.

If these files do not exist, the script copies them from their `*.example`
counterparts and locks down the permissions (`chmod 600`). You can let the
script populate them automatically by exporting environment variables before
invoking it, or by editing the files directly and re-running the script.

### `deploy/.env`

| Variable | Description |
| --- | --- |
| `BACKEND_IMAGE` / `FRONTEND_IMAGE` | Optional custom names for the built images. Useful when pushing to a registry. |
| `COMPOSE_PROJECT_NAME` | Project slug used by Docker Compose when naming containers and networks. |
| `BACKEND_PORT` / `FRONTEND_PORT` | Host ports that expose the backend and frontend on the loopback interface. |
| `SERVER_NAME` | Hostname (or `_` wildcard) that Nginx should answer. Drives automatic origin configuration. |
| `NGINX_CLIENT_MAX_BODY_SIZE` | Maximum request body size allowed through the reverse proxy (e.g. file uploads). |
| `VITE_API_BASE_URL` | Injected into the frontend build. Automatically updated to `http://<SERVER_NAME>/api` when a concrete host is provided. |
| `VITE_STRIPE_PUBLISHABLE_KEY` | Stripe publishable key for the frontend. |
| `VITE_GOOGLE_CLIENT_ID` | Google OAuth client ID used by the frontend. |
| `VITE_SENTRY_DSN` | Optional Sentry DSN for capturing frontend errors. |

### `deploy/backend.env`

| Variable | Description |
| --- | --- |
| `SECRET_KEY` | Cryptographically secure key for signing backend tokens. Generated automatically when unset or using `change-me`. |
| `DATABASE_URL` | SQLAlchemy database connection string (defaults to SQLite under `deploy/data`). |
| `ALLOWED_ORIGINS` | Comma-separated origins that may call the API. The script appends the configured host automatically. |
| `STRIPE_*` | Stripe credentials (`STRIPE_SECRET_KEY`, `STRIPE_PUBLISHABLE_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_ACCOUNT_ID`, `STRIPE_LIVE_MODE`). |
| `GOOGLE_CLIENT_ID` | Google OAuth client ID for backend verification. |
| `PAYMENT_LOG_DIR` | Directory within the container for payment logs (backed by the `backend_data` volume). |
| `COOKIE_DOMAIN` | Domain scope for authentication cookies. Defaults to the hostname when provided. |
| `PAYMENT_INTENT_STALE_MINUTES` | Minutes before abandoned Stripe PaymentIntents are cleaned up. |
| `ENV` | Backend environment label (defaults to `production`). |
| `RATE_LIMIT_LIMIT` / `RATE_LIMIT_PERIOD` | Rate limiting configuration for API endpoints. |

> **Note:** Any environment variable exported in the shell before running the
> script (for example `SERVER_NAME` or `STRIPE_SECRET_KEY`) overrides the
> corresponding value in the target environment file. The script preserves these
> overrides for subsequent runs.

## Customising configuration

- **One-off overrides:** Export environment variables inline when invoking the
  script. Example:

  ```sh
  SERVER_NAME=app.example.com \
  BACKEND_PORT=9000 \
  FRONTEND_PORT=8081 \
  sudo ./deploy/deploy.sh
  ```

  The script writes these values back into `deploy/.env` and `deploy/backend.env`
  so that subsequent runs remain in sync.

- **Persistent changes:** Edit `deploy/.env` or `deploy/backend.env` directly and
  re-run the script. Sensitive values such as `SECRET_KEY` are only generated if
  they still contain the placeholder `change-me`.
- **Service naming:** Export `SYSTEMD_SERVICE_NAME` and/or `NGINX_SITE_NAME` to
  change the generated systemd unit and Nginx site identifiers. For example:

  ```sh
  SYSTEMD_SERVICE_NAME=ccc-staging \
  NGINX_SITE_NAME=ccc-staging \
  sudo ./deploy/deploy.sh
  ```

## Managing the services

After deployment you can control the stack via systemd:

```sh
sudo systemctl status culinary-creation-collective.service
sudo systemctl restart culinary-creation-collective.service
sudo systemctl stop culinary-creation-collective.service
```

Logs are available from Docker (`docker compose logs`) or via journalctl:

```sh
sudo journalctl -u culinary-creation-collective.service -f
```

To remove the deployment entirely, stop the systemd unit and run
`docker compose down --volumes` inside the `deploy/` directory.

## Updating the application

1. Pull the latest repository changes (or upload a new archive to the server).
2. Review `deploy/.env` and `deploy/backend.env` for new variables.
3. Re-run `sudo ./deploy/deploy.sh` to rebuild images and restart the stack with
   the new code.

The script always performs a `docker compose pull` before rebuilding, so base
images stay current and security patches are applied automatically.
