# Operations

## Scheduled PaymentIntent cleanup

Use the `backend.cancel_stale_payment_intents` module to remove Stripe PaymentIntents that remain incomplete for too long.

### Cron deployment

Add the following entry to the server's crontab to cancel stale intents automatically:

```
0 * * * * cd /path/to/project && \
STRIPE_SECRET_KEY=sk_live_xxx PAYMENT_INTENT_STALE_MINUTES=60 \
python -m backend.cancel_stale_payment_intents >> /var/log/culinary-payments/cleanup.log 2>&1
```

Adjust the schedule, Stripe secret key, and stale threshold as needed. Logs are written to the directory defined by `PAYMENT_LOG_DIR` (default `/var/log/culinary-payments`).

### Environment variables

- `STRIPE_SECRET_KEY` – Stripe secret key used for API authentication.
- `PAYMENT_INTENT_STALE_MINUTES` – Age in minutes before an unfinished PaymentIntent is cancelled. Defaults to `60`.
- `PAYMENT_LOG_DIR` – Directory for log files. Ensure the service account can write to this path.

See `.github/workflows/payment_intent_cleanup.yml` for an example GitHub Actions integration.
