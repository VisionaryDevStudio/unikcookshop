# Admin Panel Review

This document summarizes the current implementation of the admin panel.

## Backend Endpoints

`backend/routers/admin.py` defines the admin API routes. Every route uses `admin_required` from `backend/auth.py`, ensuring only admin users can access the functionality:

- `/api/admin/stats` – returns user and order counts from the database, including a metric for orders placed in the current month and the percentage revenue growth compared to the previous month.
- `/api/admin/create` – allows an admin to create another admin user. Email duplication is checked.
- `/api/admin/users` – lists all users.
- `/api/admin/products` – CRUD operations on products (`list`, `create`, `update`, `delete`).
- `/api/admin/workshops` – CRUD operations on workshops.
- `/api/admin/orders` – lists all transactions.
- `/api/admin/reviews` – lists all reviews and allows updating the status.

All queries rely on SQLAlchemy models located in `backend/models.py` and use a database session from `backend/database.py`.

## Authentication

`backend/auth.py` implements JWT based authentication. The helper `admin_required` verifies the current user and checks the `is_admin` flag before allowing access.

## Frontend Usage

`src/pages/AdminDashboard.tsx` fetches admin data using Axios with the stored `access` token. It displays statistics, lists of products, workshops, users, and orders, and provides forms to approve or reject reviews.

Additional admin pages such as `AddAdmin.tsx`, `AddProduct.tsx`, and `AddWorkshop.tsx` provide forms for creating new records via the admin API routes.

## Testing

Automated tests exist under `backend/tests/` covering profile, dashboard, auth and admin features. Running `pytest` requires FastAPI and other dependencies listed in `backend/requirements.txt`.

## Observations

- Admin endpoints consistently validate admin access.
- Data is fetched directly from the SQLAlchemy models, so any database updates are immediately reflected.
- Frontend pages rely on the API base URL and authorization header to fetch data.
- Tests cannot be executed in the current environment without installing the Python dependencies.

