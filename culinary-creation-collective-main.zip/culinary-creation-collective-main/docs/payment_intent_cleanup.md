# PaymentIntent cleanup service

`cancel_stale_payment_intents` removes open Stripe PaymentIntents that have
not been completed within a configurable time window. The age threshold is
controlled via the `PAYMENT_INTENT_STALE_MINUTES` environment variable and
defaults to 60 minutes.

## Running manually

```
python -m backend.cancel_stale_payment_intents
```

Additional options are available:

- `--minutes <n>` – override the default threshold.
- `--loop` – run continuously, sleeping for the threshold between runs.

## Scheduling with cron

To run the cleanup automatically, add an entry to your crontab using the same
value as `PAYMENT_INTENT_STALE_MINUTES`:

```
*/60 * * * * cd /path/to/project && \
STRIPE_SECRET_KEY=sk_test PAYMENT_INTENT_STALE_MINUTES=60 \
python -m backend.cancel_stale_payment_intents
```

Replace the schedule and environment variable values as needed.

## GitHub Actions

A scheduled workflow at `.github/workflows/payment_intent_cleanup.yml` runs
`python -m backend.cancel_stale_payment_intents` hourly. The job installs the
backend requirements and provides the necessary environment variables:

- `PAYMENT_INTENT_STALE_MINUTES` – defaults to `60` in the workflow but can be
  adjusted as needed.
- `STRIPE_SECRET_KEY` – sourced from the repository's secrets.

Edit the workflow to change the cadence or environment values.
