import os
from datetime import datetime, timezone
from fastapi.testclient import TestClient

from ..main import app
from ..seed import seed
from ..database import SessionLocal
from .. import models

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists("app.db"):
        os.remove("app.db")


def login():
    resp = client.post(
        "/api/auth/login",
        json={"email": "user@example.com", "password": "password"},
    )
    assert resp.status_code == 200
    return resp.json()["access_token"]


def test_transactions_by_payment_intent():
    token = login()
    payment_intent_id = "pi_Test123"
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == "user@example.com").first()
        admin = db.query(models.User).filter(models.User.email == "admin@example.com").first()
        tx1 = models.Transaction(
            user_id=user.id,
            type="Workshop",
            description="PI Test",
            date=datetime.now(timezone.utc),
            amount=10.0,
            status="Paid",
            method="Card",
            payment_intent_id=payment_intent_id,
        )
        tx2 = models.Transaction(
            user_id=user.id,
            type="Workshop",
            description="Other",
            date=datetime.now(timezone.utc),
            amount=5.0,
            status="Paid",
            method="Card",
            payment_intent_id="pi_Other",
        )
        tx3 = models.Transaction(
            user_id=admin.id,
            type="Workshop",
            description="Admin",
            date=datetime.now(timezone.utc),
            amount=7.0,
            status="Paid",
            method="Card",
            payment_intent_id=payment_intent_id,
        )
        db.add_all([tx1, tx2, tx3])
        db.commit()

    resp = client.get(
        f"/api/users/me/transactions/{payment_intent_id}",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 1
    assert data[0]["description"] == "PI Test"
    assert data[0]["payment_intent_id"] == payment_intent_id


def test_transactions_by_payment_intent_invalid_id():
    token = login()
    invalid_id = "invalid"
    resp = client.get(
        f"/api/users/me/transactions/{invalid_id}",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code in (400, 422)
