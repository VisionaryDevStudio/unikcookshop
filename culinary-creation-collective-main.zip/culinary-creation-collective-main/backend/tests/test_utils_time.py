from datetime import datetime, timezone, timedelta

from backend.utils.time import to_utc


def test_to_utc_naive():
    dt = datetime(2023, 1, 1, 12, 0)
    result = to_utc(dt)
    assert result.tzinfo == timezone.utc
    assert result == datetime(2023, 1, 1, 12, 0, tzinfo=timezone.utc)


def test_to_utc_with_timezone():
    dt = datetime(2023, 1, 1, 3, 0, tzinfo=timezone(timedelta(hours=3)))
    result = to_utc(dt)
    assert result.tzinfo == timezone.utc
    assert result == datetime(2023, 1, 1, 0, 0, tzinfo=timezone.utc)
