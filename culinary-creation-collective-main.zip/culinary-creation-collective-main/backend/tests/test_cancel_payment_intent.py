import os
import stripe
from fastapi.testclient import TestClient
from ..main import app
from ..seed import seed

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def login():
    resp = client.post('/api/auth/login', json={'email': 'user@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def test_cancel_payment_intent_success(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    user_id = client.get('/api/users/me', headers=headers).json()['id']

    def fake_retrieve(pid):
        assert pid == 'pi_good'
        return type('obj', (), {'metadata': {'user_id': str(user_id)}})()

    canceled = {}

    def fake_cancel(pid):
        assert pid == 'pi_good'
        canceled['called'] = True
        return type('obj', (), {'status': 'canceled'})()

    monkeypatch.setattr(stripe.PaymentIntent, 'retrieve', fake_retrieve)
    monkeypatch.setattr(stripe.PaymentIntent, 'cancel', fake_cancel)

    resp = client.post(
        '/api/cart/cancel-payment-intent',
        json={'payment_intent_id': 'pi_good'},
        headers=headers,
    )
    assert resp.status_code == 200
    assert resp.json() == {'status': 'canceled'}
    assert canceled['called']


def test_cancel_payment_intent_wrong_owner(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    def fake_retrieve(pid):
        assert pid == 'pi_other'
        return type('obj', (), {'metadata': {'user_id': '999'}})()

    monkeypatch.setattr(stripe.PaymentIntent, 'retrieve', fake_retrieve)

    resp = client.post(
        '/api/cart/cancel-payment-intent',
        json={'payment_intent_id': 'pi_other'},
        headers=headers,
    )
    assert resp.status_code == 404
    assert resp.json()['detail'] == 'Payment intent not found'
