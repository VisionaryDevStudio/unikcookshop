import pytest

from ..utils.stripe_config import load_stripe_secret_key


def test_load_stripe_secret_key_allows_placeholder(monkeypatch):
    monkeypatch.setenv("STRIPE_SECRET_KEY", "sk_test")
    assert load_stripe_secret_key() == "sk_test"


@pytest.mark.parametrize(
    "value",
    [
        "sk_test_*****6789",
        "sk_test_1234567890...",
        "sk_test_redacted",
        "sk_test_with spaces",
    ],
)
def test_load_stripe_secret_key_rejects_masked_values(monkeypatch, value):
    monkeypatch.setenv("STRIPE_SECRET_KEY", value)
    with pytest.raises(RuntimeError):
        load_stripe_secret_key()


def test_load_stripe_secret_key_accepts_full_value(monkeypatch):
    monkeypatch.setenv(
        "STRIPE_SECRET_KEY",
        "sk_test_4eC39HqLyjWDarjtT1zdp7dc",
    )
    assert (
        load_stripe_secret_key()
        == "sk_test_4eC39HqLyjWDarjtT1zdp7dc"
    )
