import os
import stripe
from fastapi.testclient import TestClient
from ..main import app
from ..seed import seed
from ..database import SessionLocal
from .. import models
from ..services import payments
from decimal import Decimal

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def test_webhook_invalid_signature(monkeypatch):
    def fake_construct(payload, sig_header, secret):
        raise stripe.error.SignatureVerificationError('bad', 'header', 'sig')
    monkeypatch.setattr(stripe.Webhook, 'construct_event', fake_construct)
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'bad'})
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Invalid payload or signature'


def test_webhook_environment_mismatch(monkeypatch, caplog):
    event = {
        'id': 'evt_env_mismatch',
        'type': 'payment_intent.succeeded',
        'livemode': True,
        'account': 'acct_wrong',
        'data': {'object': {'id': 'pi_env_mismatch'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with caplog.at_level('WARNING', logger='culinary'):
        resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Account mismatch'
    assert any('livemode/account mismatch' in record.message for record in caplog.records)


def test_webhook_payment_intent_succeeded(monkeypatch):
    event = {
        'id': 'evt_pi_123',
        'type': 'payment_intent.succeeded',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'id': 'pi_123'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=Decimal('10.0'),
            status='Pending',
            method='Card',
            payment_intent_id='pi_123',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        tx = db.query(models.Transaction).filter(models.Transaction.payment_intent_id == 'pi_123').first()
        assert tx.status == 'Paid'


def test_webhook_no_transactions(monkeypatch, caplog):
    event = {
        'id': 'evt_no_tx',
        'type': 'payment_intent.succeeded',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'id': 'pi_missing'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    monkeypatch.setattr(payments, 'schedule_reconciliation', lambda: None)
    with caplog.at_level('WARNING', logger='culinary'):
        resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    assert any(
        'No transactions found for payment intent pi_missing' in record.message
        for record in caplog.records
    )
    with SessionLocal() as db:
        pending = (
            db.query(models.PendingStripeEvent)
            .filter(models.PendingStripeEvent.event_id == 'evt_no_tx')
            .first()
        )
        assert pending is not None
        assert pending.payment_intent_id == 'pi_missing'


def test_webhook_amount_mismatch(monkeypatch, caplog):
    event = {
        'id': 'evt_mismatch',
        'type': 'payment_intent.succeeded',
        'livemode': False,
        'account': 'acct_test',
        'data': {
            'object': {
                'id': 'pi_mismatch',
                'amount_received': 1000,
                'currency': 'usd',
            }
        },
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=Decimal('9.00'),
            status='Pending',
            method='Card',
            payment_intent_id='pi_mismatch',
        )
        db.add(tx)
        db.commit()
    with caplog.at_level('WARNING', logger='culinary'):
        resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Amount mismatch'
    assert any(
        'pi_mismatch' in record.message and 'expected 900' in record.message and 'received 1000' in record.message
        for record in caplog.records
    )


def test_reconcile_queued_payment_intent(monkeypatch):
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        user.stripe_customer_id = 'cus_reconcile'
        user_id = user.id
        db.commit()

    event = {
        'id': 'evt_reconcile',
        'type': 'payment_intent.succeeded',
        'livemode': False,
        'account': 'acct_test',
        'data': {
            'object': {
                'id': 'pi_reconcile',
                'customer': 'cus_reconcile',
                'metadata': {'user_id': str(user_id)},
            }
        },
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    monkeypatch.setattr(payments, 'schedule_reconciliation', lambda: None)
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        pending = (
            db.query(models.PendingStripeEvent)
            .filter(models.PendingStripeEvent.payment_intent_id == 'pi_reconcile')
            .first()
        )
        assert pending is not None

    def fake_retrieve(payment_intent_id):
        assert payment_intent_id == 'pi_reconcile'
        return {
            'id': 'pi_reconcile',
            'metadata': {'user_id': str(user_id)},
            'amount_received': 2500,
            'currency': 'usd',
            'customer': 'cus_reconcile',
        }

    monkeypatch.setattr(stripe.PaymentIntent, 'retrieve', fake_retrieve)

    processed = payments.reconcile_pending_payment_events()
    assert processed == 1

    with SessionLocal() as db:
        txs = (
            db.query(models.Transaction)
            .filter(models.Transaction.payment_intent_id == 'pi_reconcile')
            .all()
        )
        assert len(txs) == 1
        tx = txs[0]
        assert tx.status == 'Paid'
        assert tx.amount == Decimal('25.00')
        pending = (
            db.query(models.PendingStripeEvent)
            .filter(models.PendingStripeEvent.payment_intent_id == 'pi_reconcile')
            .first()
        )
        assert pending is None
        processed_pi = (
            db.query(models.ProcessedPaymentIntent)
            .filter(models.ProcessedPaymentIntent.payment_intent_id == 'pi_reconcile')
            .first()
        )
        assert processed_pi is not None


def test_webhook_customer_mismatch(monkeypatch):
    event = {
        'id': 'evt_cus_mismatch',
        'type': 'payment_intent.succeeded',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'id': 'pi_cus_mismatch', 'customer': 'cus_wrong'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        user.stripe_customer_id = 'cus_correct'
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=Decimal('10.0'),
            status='Pending',
            method='Card',
            payment_intent_id='pi_cus_mismatch',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Customer mismatch'


def test_webhook_payment_intent_processing(monkeypatch):
    event = {
        'id': 'evt_pi_processing',
        'type': 'payment_intent.processing',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'id': 'pi_processing'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=Decimal('10.0'),
            status='Pending',
            method='Card',
            payment_intent_id='pi_processing',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        tx = db.query(models.Transaction).filter(models.Transaction.payment_intent_id == 'pi_processing').first()
        assert tx.status == 'Processing'
        assert db.query(models.ProcessedEvent).filter(models.ProcessedEvent.id == 'evt_pi_processing').count() == 1


def test_webhook_currency_mismatch(monkeypatch, caplog):
    event = {
        'id': 'evt_currency_mismatch',
        'type': 'payment_intent.succeeded',
        'livemode': False,
        'account': 'acct_test',
        'data': {
            'object': {
                'id': 'pi_currency_mismatch',
                'amount_received': 1000,
                'currency': 'eur',
            }
        },
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=Decimal('10.00'),
            status='Pending',
            method='Card',
            payment_intent_id='pi_currency_mismatch',
        )
        db.add(tx)
        db.commit()
    with caplog.at_level('WARNING', logger='culinary'):
        resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Currency mismatch'
    assert any(
        'pi_currency_mismatch' in record.message and 'expected usd' in record.message and 'received eur' in record.message
        for record in caplog.records
    )
    with SessionLocal() as db:
        assert (
            db.query(models.ProcessedEvent)
            .filter(models.ProcessedEvent.id == 'evt_currency_mismatch')
            .count()
            == 0
        )


def test_webhook_payment_intent_failed(monkeypatch):
    event = {
        'id': 'evt_pi_fail',
        'type': 'payment_intent.payment_failed',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'id': 'pi_fail'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=Decimal('10.0'),
            status='Pending',
            method='Card',
            payment_intent_id='pi_fail',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        tx = db.query(models.Transaction).filter(models.Transaction.payment_intent_id == 'pi_fail').first()
        assert tx.status == 'Failed'


def test_webhook_charge_refunded(monkeypatch):
    event = {
        'id': 'evt_refund',
        'type': 'charge.refunded',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'payment_intent': 'pi_refund'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=Decimal('10.0'),
            status='Paid',
            method='Card',
            payment_intent_id='pi_refund',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        tx = db.query(models.Transaction).filter(models.Transaction.payment_intent_id == 'pi_refund').first()
        assert tx.status == 'Refunded'
        assert db.query(models.ProcessedEvent).filter(models.ProcessedEvent.id == 'evt_refund').count() == 1


def test_webhook_payment_intent_canceled(monkeypatch):
    event = {
        'id': 'evt_cancel',
        'type': 'payment_intent.canceled',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'id': 'pi_cancel'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=Decimal('10.0'),
            status='Pending',
            method='Card',
            payment_intent_id='pi_cancel',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        tx = db.query(models.Transaction).filter(models.Transaction.payment_intent_id == 'pi_cancel').first()
        assert tx.status == 'Canceled'
        assert db.query(models.ProcessedEvent).filter(models.ProcessedEvent.id == 'evt_cancel').count() == 1


def test_webhook_charge_dispute_created(monkeypatch):
    event = {
        'id': 'evt_dispute_created',
        'type': 'charge.dispute.created',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'payment_intent': 'pi_dispute_created'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=10.0,
            status='Paid',
            method='Card',
            payment_intent_id='pi_dispute_created',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        tx = db.query(models.Transaction).filter(models.Transaction.payment_intent_id == 'pi_dispute_created').first()
        assert tx.status == 'Disputed'
        assert db.query(models.ProcessedEvent).filter(models.ProcessedEvent.id == 'evt_dispute_created').count() == 1


def test_webhook_charge_dispute_closed_won(monkeypatch):
    event = {
        'id': 'evt_dispute_won',
        'type': 'charge.dispute.closed',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'payment_intent': 'pi_dispute_won', 'status': 'won'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=10.0,
            status='Paid',
            method='Card',
            payment_intent_id='pi_dispute_won',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        tx = db.query(models.Transaction).filter(models.Transaction.payment_intent_id == 'pi_dispute_won').first()
        assert tx.status == 'Paid'
        assert db.query(models.ProcessedEvent).filter(models.ProcessedEvent.id == 'evt_dispute_won').count() == 1


def test_webhook_charge_dispute_closed_lost(monkeypatch):
    event = {
        'id': 'evt_dispute_lost',
        'type': 'charge.dispute.closed',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'payment_intent': 'pi_dispute_lost', 'status': 'lost'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=10.0,
            status='Paid',
            method='Card',
            payment_intent_id='pi_dispute_lost',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        tx = db.query(models.Transaction).filter(models.Transaction.payment_intent_id == 'pi_dispute_lost').first()
        assert tx.status == 'Dispute Lost'
        assert db.query(models.ProcessedEvent).filter(models.ProcessedEvent.id == 'evt_dispute_lost').count() == 1


def test_webhook_charge_dispute_funds_reinstated(monkeypatch):
    event = {
        'id': 'evt_dispute_reinstated',
        'type': 'charge.dispute.funds_reinstated',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'payment_intent': 'pi_dispute_reinstated'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=10.0,
            status='Paid',
            method='Card',
            payment_intent_id='pi_dispute_reinstated',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        tx = db.query(models.Transaction).filter(models.Transaction.payment_intent_id == 'pi_dispute_reinstated').first()
        assert tx.status == 'Paid'
        assert db.query(models.ProcessedEvent).filter(models.ProcessedEvent.id == 'evt_dispute_reinstated').count() == 1


def test_webhook_idempotent(monkeypatch):
    event = {
        'id': 'evt_dup',
        'type': 'payment_intent.succeeded',
        'livemode': False,
        'account': 'acct_test',
        'data': {'object': {'id': 'pi_dup'}},
    }
    monkeypatch.setattr(
        stripe.Webhook,
        'construct_event',
        lambda payload, sig_header, secret: event,
    )
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        tx = models.Transaction(
            user_id=user.id,
            type='Product',
            description='Test',
            amount=Decimal('10.0'),
            status='Pending',
            method='Card',
            payment_intent_id='pi_dup',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        tx = db.query(models.Transaction).filter(models.Transaction.payment_intent_id == 'pi_dup').first()
        assert tx.status == 'Paid'
        tx.status = 'Pending'
        db.commit()
    resp = client.post('/api/webhooks/stripe', data='{}', headers={'Stripe-Signature': 'good'})
    assert resp.status_code == 200
    with SessionLocal() as db:
        tx = db.query(models.Transaction).filter(models.Transaction.payment_intent_id == 'pi_dup').first()
        assert tx.status == 'Pending'
        assert db.query(models.ProcessedEvent).filter(models.ProcessedEvent.id == 'evt_dup').count() == 1

