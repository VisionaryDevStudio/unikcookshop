import os
import json
import hashlib
import stripe
from datetime import datetime, timezone
from fastapi.testclient import TestClient

from ..main import app
from ..seed import seed
from ..database import SessionLocal
from .. import models
from decimal import Decimal

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def login():
    resp = client.post('/api/auth/login', json={'email': 'user@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def _create_pending_transactions(monkeypatch, headers, payment_intent_id, expected_amount):
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'search',
        lambda **kwargs: type('obj', (), {'data': []})(),
    )

    def fake_create(**kwargs):
        assert kwargs.get('amount') == expected_amount
        return type(
            'obj',
            (),
            {
                'id': payment_intent_id,
                'client_secret': f'{payment_intent_id}_secret',
                'status': 'requires_payment_method',
                'amount': kwargs.get('amount'),
                'currency': kwargs.get('currency'),
                'metadata': kwargs.get('metadata'),
                'customer': kwargs.get('customer'),
            },
        )()

    monkeypatch.setattr(stripe.PaymentIntent, 'create', fake_create)

    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 200, resp.json()


def login_admin():
    resp = client.post('/api/auth/login', json={'email': 'admin@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def test_cart_and_transaction_store_scheduled_at_in_utc(monkeypatch):
    admin_token = login_admin()
    wdata = {
        'title': 'TZ',
        'date': '2030-01-01T00:00:00+00:00',
        'instructor': 'Chef',
        'location': 'A',
        'price': 50,
    }
    resp = client.post('/api/admin/workshops', json=wdata, headers={'Authorization': f'Bearer {admin_token}'})
    assert resp.status_code == 200
    wid = resp.json()['id']

    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    user_id = client.get('/api/users/me', headers=headers).json()['id']

    scheduled = '2030-01-01T10:00:00+05:00'
    add = {
        'item_id': wid,
        'name': 'TZ',
        'price': '$50',
        'category': 'Workshops',
        'image': 'img',
        'quantity': 1,
        'type': 'workshop',
        'scheduled_at': scheduled,
    }
    resp = client.post('/api/cart/items', json=add, headers=headers)
    assert resp.status_code == 200
    scheduled_norm = datetime.fromisoformat(resp.json()['scheduled_at'])
    assert scheduled_norm == datetime(2030, 1, 1, 5, 0, tzinfo=timezone.utc)

    with SessionLocal() as db:
        item = db.query(models.CartItem).filter(models.CartItem.user_id == user_id).first()
        assert item.scheduled_at == datetime(2030, 1, 1, 5, 0)

    unit = int(Decimal("50") * 100)
    expected_total = unit * 1
    line_items = [{"type": "workshop", "id": wid, "qty": 1, "unit": unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()

    _create_pending_transactions(monkeypatch, headers, 'pi_test', expected_total)

    monkeypatch.setattr(stripe.Customer, 'create', lambda **kw: type('obj', (), {'id': 'cus_test'})())
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'retrieve',
        lambda pid: type(
            'obj',
            (),
            {
                'status': 'succeeded',
                'amount_received': expected_total,
                'currency': 'usd',
                'payment_method': 'pm_test',
                'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
                'customer': 'cus_test',
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'retrieve',
        lambda pmid: type(
            'obj',
            (),
            {
                'id': pmid,
                'card': type(
                    'card',
                    (),
                    {'brand': 'visa', 'last4': '4242', 'exp_month': 12, 'exp_year': 2027},
                )(),
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.PaymentMethod, 'attach', lambda pmid, customer: type('obj', (), {'id': pmid})()
    )

    resp = client.post('/api/cart/checkout', json={'payment_intent_id': 'pi_test'}, headers=headers)
    assert resp.status_code == 200
    tr = resp.json()[0]
    stored = datetime.fromisoformat(tr['workshop_date'])
    assert stored == datetime(2030, 1, 1, 5, 0, tzinfo=timezone.utc)

    with SessionLocal() as db:
        tr_db = db.query(models.Transaction).filter(models.Transaction.id == tr['id']).first()
        assert tr_db.workshop_date == datetime(2030, 1, 1, 5, 0)
