import os
import json
import hashlib
import threading
from decimal import Decimal

import stripe
from fastapi.testclient import TestClient

from ..main import app
from ..seed import seed
from ..database import SessionLocal
from .. import models


client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def login():
    resp = client.post(
        '/api/auth/login',
        json={'email': 'user@example.com', 'password': 'password'},
    )
    assert resp.status_code == 200
    return resp.json()['access_token']


def _create_pending_transactions(monkeypatch, headers, payment_intent_id, expected_amount):
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'search',
        lambda **kwargs: type('obj', (), {'data': []})(),
    )

    def fake_create(**kwargs):
        assert kwargs.get('amount') == expected_amount
        return type(
            'obj',
            (),
            {
                'id': payment_intent_id,
                'client_secret': f'{payment_intent_id}_secret',
                'status': 'requires_payment_method',
                'amount': kwargs.get('amount'),
                'currency': kwargs.get('currency'),
                'metadata': kwargs.get('metadata'),
                'customer': kwargs.get('customer'),
            },
        )()

    monkeypatch.setattr(stripe.PaymentIntent, 'create', fake_create)

    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 200, resp.json()


def test_checkout_concurrent_requests(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product',
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200

    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal('1')))

    line_items = [{'type': 'product', 'id': 1, 'qty': 1, 'unit': unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()
    user_id = client.get('/api/users/me', headers=headers).json()['id']

    _create_pending_transactions(monkeypatch, headers, 'pi_test', unit)

    monkeypatch.setattr(
        stripe.PaymentIntent,
        'retrieve',
        lambda pid: type(
            'obj',
            (),
            {
                'status': 'succeeded',
                'amount_received': unit,
                'currency': 'usd',
                'payment_method': 'pm_test',
                'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
                'customer': 'cus_test',
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'retrieve',
        lambda pmid: type(
            'obj',
            (),
            {
                'id': pmid,
                'card': type(
                    'card',
                    (),
                    {
                        'brand': 'visa',
                        'last4': '4242',
                        'exp_month': 12,
                        'exp_year': 2027,
                    },
                )(),
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'attach',
        lambda pmid, customer: type('obj', (), {'id': pmid})(),
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'detach',
        lambda pmid: None,
    )
    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )

    results = [None, None]
    start = threading.Event()

    def worker(idx: int):
        start.wait()
        results[idx] = client.post(
            '/api/cart/checkout',
            json={'payment_intent_id': 'pi_test'},
            headers=headers,
        )

    t1 = threading.Thread(target=worker, args=(0,))
    t2 = threading.Thread(target=worker, args=(1,))
    t1.start()
    t2.start()
    start.set()
    t1.join()
    t2.join()

    statuses = sorted(res.status_code for res in results)
    assert statuses == [200, 400]

    with SessionLocal() as db:
        tx = (
            db.query(models.Transaction)
            .filter(models.Transaction.payment_intent_id == 'pi_test')
            .first()
        )
        assert tx is not None
        assert tx.status == 'Paid'

