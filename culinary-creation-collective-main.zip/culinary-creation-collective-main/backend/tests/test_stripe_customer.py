import os
import stripe
from concurrent.futures import ThreadPoolExecutor
from fastapi.testclient import TestClient

os.environ.setdefault('STRIPE_SECRET_KEY', 'sk_test')

from ..main import app
from ..seed import seed
from ..database import SessionLocal
from .. import models
from ..routers import auth as auth_router
from ..routers.cart import _get_or_create_customer


client = TestClient(app)


def login():
    resp = client.post('/api/auth/login', json={'email': 'user@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def test_create_customer_on_first_payment(monkeypatch):
    seed()
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    # Ensure user starts without a customer id
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        user.stripe_customer_id = None
        db.commit()

    # Add an item to cart so payment intent can be created
    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product'
    }
    client.post('/api/cart/items', json=data, headers=headers)

    customer_called = {}

    def mock_customer_create(**kw):
        customer_called['called'] = True
        return type('obj', (), {'id': 'cus_123'})()

    monkeypatch.setattr(stripe.Customer, 'create', mock_customer_create)
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'search',
        lambda query, limit: type('obj', (), {'data': []})(),
    )
    pi_kwargs = {}

    def mock_pi_create(**kw):
        pi_kwargs.update(kw)
        return type('obj', (), {'client_secret': 'secret'})()

    monkeypatch.setattr(stripe.PaymentIntent, 'create', mock_pi_create)

    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 200
    assert customer_called.get('called') is True
    assert pi_kwargs.get('customer') == 'cus_123'

    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        assert user.stripe_customer_id == 'cus_123'


def test_use_existing_customer(monkeypatch):
    seed()
    # Pre-set a customer id for the user
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        user.stripe_customer_id = 'cus_existing'
        db.commit()

    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    # Add an item to cart so payment intent can be created
    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product'
    }
    client.post('/api/cart/items', json=data, headers=headers)

    customer_called = {'called': False}

    def mock_customer_create(**kw):
        customer_called['called'] = True
        return type('obj', (), {'id': 'cus_new'})()

    monkeypatch.setattr(stripe.Customer, 'create', mock_customer_create)
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'search',
        lambda query, limit: type('obj', (), {'data': []})(),
    )
    pi_kwargs = {}

    def mock_pi_create(**kw):
        pi_kwargs.update(kw)
        return type('obj', (), {'client_secret': 'secret'})()

    monkeypatch.setattr(stripe.PaymentIntent, 'create', mock_pi_create)

    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 200
    assert customer_called['called'] is False
    assert pi_kwargs.get('customer') == 'cus_existing'


def test_get_or_create_customer_race(monkeypatch):
    seed()

    created_ids: list[str] = []

    def mock_customer_create(**kw):
        cid = f"cus_{len(created_ids) + 1}"
        created_ids.append(cid)
        return type("obj", (), {"id": cid})()

    monkeypatch.setattr(stripe.Customer, "create", mock_customer_create)

    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        user.stripe_customer_id = None
        db.commit()

    def worker() -> str:
        with SessionLocal() as db:
            user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
            return _get_or_create_customer(db, user)

    with ThreadPoolExecutor(max_workers=5) as executor:
        results = list(executor.map(lambda _: worker(), range(5)))

    assert len(created_ids) == 1
    assert len(set(results)) == 1
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        assert user.stripe_customer_id == results[0]

