import os
import pytest
from fastapi.testclient import TestClient

from ..main import app
from ..seed import seed

client = TestClient(app)

def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def test_login_success():
    resp = client.post('/api/auth/login', json={'email': 'admin@example.com', 'password': 'password'})
    assert resp.status_code == 200
    data = resp.json()
    assert 'access_token' in data
    assert data['user']['email'] == 'admin@example.com'


def test_admin_required():
    resp = client.post('/api/auth/login', json={'email': 'admin@example.com', 'password': 'password'})
    token = resp.json()['access_token']
    headers = {'Authorization': f'Bearer {token}'}
    resp2 = client.get('/api/admin/stats', headers=headers)
    assert resp2.status_code == 200
    data = resp2.json()
    assert 'users' in data and data['users'] >= 2
    assert 'orders' in data and data['orders'] >= 4
    assert 'revenue' in data and data['revenue'] > 0
    assert 'active_workshops' in data
    assert isinstance(data.get('top_products'), list)
    assert isinstance(data.get('recent_activity'), list)
    assert 'orders_this_month' in data
    assert 'monthly_growth' in data


def test_google_login_creates_user():
    import base64, json
    token = base64.b64encode(json.dumps({
        'email': 'googleuser@example.com',
        'name': 'Google User'
    }).encode()).decode()
    resp = client.post('/api/auth/google', json={'token': token})
    assert resp.status_code == 200
    assert resp.json()['user']['email'] == 'googleuser@example.com'


def test_create_admin():
    resp = client.post('/api/auth/login', json={'email': 'admin@example.com', 'password': 'password'})
    token = resp.json()['access_token']
    headers = {'Authorization': f'Bearer {token}'}
    resp2 = client.post('/api/admin/create', json={'name': 'New Admin', 'email': 'newadmin@example.com', 'password': 'secret'}, headers=headers)
    assert resp2.status_code == 200
    assert resp2.json()['is_admin'] is True

