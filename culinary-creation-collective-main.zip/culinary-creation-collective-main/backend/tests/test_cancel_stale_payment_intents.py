import os
os.environ.setdefault('STRIPE_SECRET_KEY', 'sk_test')
os.environ.setdefault('PAYMENT_INTENT_STALE_MINUTES', '60')

from datetime import datetime, timedelta, timezone

import stripe

from ..cancel_stale_payment_intents import cancel_stale_payment_intents


def test_cancel_stale_payment_intents(monkeypatch):
    old_time = int((datetime.now(tz=timezone.utc) - timedelta(hours=2)).timestamp())
    recent_time = int(datetime.now(tz=timezone.utc).timestamp())

    old_pi = type('obj', (), {'id': 'pi_old', 'created': old_time})()
    recent_pi = type('obj', (), {'id': 'pi_recent', 'created': recent_time})()

    class ListResponse:
        def __init__(self, data):
            self.data = data
        def auto_paging_iter(self):
            return iter(self.data)

    def mock_list(*, status, created, limit):
        assert created['lt']
        if status == 'requires_payment_method':
            data = [pi for pi in [old_pi, recent_pi] if pi.created < created['lt']]
            return ListResponse(data)
        return ListResponse([])

    cancelled = []
    def mock_cancel(pi_id):
        cancelled.append(pi_id)
        return None

    monkeypatch.setattr(stripe.PaymentIntent, 'list', mock_list)
    monkeypatch.setattr(stripe.PaymentIntent, 'cancel', mock_cancel)

    cancel_stale_payment_intents()

    assert cancelled == ['pi_old']
