import os
from datetime import datetime, timedelta, timezone
from fastapi.testclient import TestClient
from ..main import app
from ..seed import seed
from ..database import SessionLocal
from .. import models
from decimal import Decimal

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def login():
    resp = client.post('/api/auth/login', json={'email': 'user@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def test_products():
    token = login()
    resp = client.get('/api/users/me/products', headers={'Authorization': f'Bearer {token}'})
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)


def test_billing():
    token = login()
    resp = client.get('/api/users/me/billing', headers={'Authorization': f'Bearer {token}'})
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)


def test_billing_timezone():
    token = login()
    user_id = client.get('/api/users/me', headers={'Authorization': f'Bearer {token}'}).json()['id']
    with SessionLocal() as db:
        tx = models.Transaction(
            user_id=user_id,
            type='Workshop',
            description='Timezone Test',
            date=datetime(2024, 1, 1, 12, 0),
            amount=Decimal('10.0'),
            status='Paid',
            method='Card',
            workshop_date=datetime(2024, 1, 2, 9, 0),
        )
        db.add(tx)
        db.commit()
    resp = client.get('/api/users/me/billing', headers={'Authorization': f'Bearer {token}'})
    assert resp.status_code == 200
    data = resp.json()
    inserted = next(t for t in data if t['description'] == 'Timezone Test')
    tx_date = datetime.fromisoformat(inserted['date'])
    ws_date = datetime.fromisoformat(inserted['workshop_date'])
    assert tx_date.tzinfo == timezone.utc
    assert ws_date.tzinfo == timezone.utc


def test_reviews():
    token = login()
    resp = client.get('/api/users/me/reviews', headers={'Authorization': f'Bearer {token}'})
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)
