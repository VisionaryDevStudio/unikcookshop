from fastapi.testclient import TestClient
from ..main import app
from ..seed import seed
import os
from datetime import datetime, timezone

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def test_public_products():
    resp = client.get('/api/public/products')
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)
    if resp.json():
        assert isinstance(resp.json()[0].get('images'), list)


def test_public_product_detail():
    resp = client.get('/api/public/products/1')
    assert resp.status_code == 200
    data = resp.json()
    assert data['id'] == 1
    assert 'name' in data
    assert 'category' in data
    assert isinstance(data.get('features'), list)
    assert isinstance(data.get('images'), list)


def test_public_product_not_found():
    resp = client.get('/api/public/products/9999')
    assert resp.status_code == 404


def test_public_workshops():
    resp = client.get('/api/public/workshops')
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)
    assert all(w['date'].endswith('Z') for w in resp.json())
    if resp.json():
        single = client.get(f"/api/public/workshops/{resp.json()[0]['id']}")
        assert single.status_code == 200
        assert single.json()['id'] == resp.json()[0]['id']
        assert single.json()['date'].endswith('Z')


def test_public_upcoming_workshops():
    resp = client.get('/api/public/workshops/upcoming')
    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)
    assert all(w['date'].endswith('Z') for w in data)
    assert all(
        datetime.fromisoformat(w['date']) >= datetime.now(timezone.utc) for w in data
    )
    now = datetime.now(timezone.utc)
    dates = [datetime.fromisoformat(w['date']) for w in data]
    assert all(d.tzinfo is not None for d in dates)
    assert all(d >= now for d in dates)

def test_create_inquiry():
    data = {
        'name': 'Test User',
        'email': 'test@example.com',
        'phone': '1234567890',
        'workshop_type': 'group',
        'participants': 5,
        'preferred_date': '2030-01-01',
        'message': 'Interested in group session'
    }
    resp = client.post('/api/public/inquiries', json=data)
    assert resp.status_code == 200
    result = resp.json()
    assert result['name'] == 'Test User'
    assert result['participants'] == 5
    assert result['created_at'].endswith('Z')
    assert result['status'] == 'pending'


def test_public_reviews_timezone():
    resp = client.get('/api/public/reviews')
    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)
    assert all(r['date'].endswith('Z') for r in data)

