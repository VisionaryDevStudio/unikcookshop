import pytest
from fastapi import HTTPException
from ..routers.cart import _handle_stripe_error, _mask_user_id


def test_handle_stripe_error_masks_user_id(caplog):
    user_id = 123
    masked = _mask_user_id(user_id)
    with caplog.at_level("ERROR", logger="culinary"):
        with pytest.raises(HTTPException):
            _handle_stripe_error(
                Exception("boom"),
                f"Fail for user {user_id}",
                "fail",
                user_id=user_id,
            )
    assert any(masked in record.message for record in caplog.records)
    assert all(str(user_id) not in record.message for record in caplog.records)
