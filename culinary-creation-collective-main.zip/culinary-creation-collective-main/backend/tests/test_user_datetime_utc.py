import os
from datetime import datetime, timezone
from fastapi.testclient import TestClient

from ..main import app
from ..seed import seed

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def login_user():
    resp = client.post('/api/auth/login', json={'email': 'user@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def assert_utc(dt_str):
    dt = datetime.fromisoformat(dt_str)
    assert dt.tzinfo == timezone.utc


def test_user_endpoints_return_utc():
    token = login_user()
    headers = {'Authorization': f'Bearer {token}'}

    resp_up = client.get('/api/users/me/workshops/upcoming', headers=headers)
    assert resp_up.status_code == 200
    for w in resp_up.json():
        assert_utc(w['date'])

    resp_hist = client.get('/api/users/me/workshops/history', headers=headers)
    assert resp_hist.status_code == 200
    for w in resp_hist.json():
        assert_utc(w['date'])

    resp_prod = client.get('/api/users/me/products', headers=headers)
    assert resp_prod.status_code == 200
    for p in resp_prod.json():
        assert_utc(p['purchase_date'])

    resp_bill = client.get('/api/users/me/billing', headers=headers)
    assert resp_bill.status_code == 200
    for t in resp_bill.json():
        assert_utc(t['date'])
        if t.get('workshop_date') is not None:
            assert_utc(t['workshop_date'])
