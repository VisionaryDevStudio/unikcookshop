import os
from fastapi.testclient import TestClient

from ..main import app
from ..seed import seed

client = TestClient(app)

def setup_module(module):
    seed()

def teardown_module(module):
    if os.path.exists("app.db"):
        os.remove("app.db")

def login(password="password"):
    resp = client.post(
        "/api/auth/login",
        json={"email": "user@example.com", "password": password},
    )
    assert resp.status_code == 200
    return resp.json()["access_token"]

def test_change_password_wrong_current():
    token = login()
    resp = client.post(
        "/api/users/me/password",
        headers={"Authorization": f"Bearer {token}"},
        json={"current_password": "wrong", "new_password": "newpass"},
    )
    assert resp.status_code == 400
    resp_login = client.post(
        "/api/auth/login",
        json={"email": "user@example.com", "password": "password"},
    )
    assert resp_login.status_code == 200

def test_change_password_success():
    token = login()
    resp = client.post(
        "/api/users/me/password",
        headers={"Authorization": f"Bearer {token}"},
        json={"current_password": "password", "new_password": "newpass"},
    )
    assert resp.status_code == 204
    resp_old = client.post(
        "/api/auth/login",
        json={"email": "user@example.com", "password": "password"},
    )
    assert resp_old.status_code == 401
    resp_new = client.post(
        "/api/auth/login",
        json={"email": "user@example.com", "password": "newpass"},
    )
    assert resp_new.status_code == 200
