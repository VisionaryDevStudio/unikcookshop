import os

os.environ.setdefault('SECRET_KEY', 'test_secret_key')
os.environ.setdefault('STRIPE_SECRET_KEY', 'sk_test')
os.environ.setdefault('STRIPE_WEBHOOK_SECRET', 'whsec_test')
os.environ.setdefault('STRIPE_ACCOUNT_ID', 'acct_test')
os.environ.setdefault('STRIPE_LIVE_MODE', 'False')

import stripe
import fastapi.testclient

from ..routers import auth, cart, users
from .. import rate_limiter


def _no_rate_limit(*args, **kwargs):
    return None


auth._check_rate_limit = _no_rate_limit
cart._check_rate_limit = _no_rate_limit
users._check_rate_limit = _no_rate_limit
rate_limiter._check_rate_limit = _no_rate_limit

_orig_init = fastapi.testclient.TestClient.__init__


def _init_with_csrf(self, *args, **kwargs):
    _orig_init(self, *args, **kwargs)
    token = "test_csrf_token"
    self.cookies.set("csrf_token", token)
    self.headers.update({"X-CSRF-Token": token})


fastapi.testclient.TestClient.__init__ = _init_with_csrf

# Avoid outbound calls during tests
stripe.Customer.create = lambda **kw: type('obj', (), {'id': 'cus_test'})()

