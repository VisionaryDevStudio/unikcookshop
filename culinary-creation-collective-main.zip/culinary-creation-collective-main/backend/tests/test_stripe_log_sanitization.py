import pytest
import stripe
from fastapi import HTTPException

from ..routers.cart import _handle_stripe_error


def test_handle_stripe_error_strips_sensitive_fields(caplog):
    exc = stripe.error.InvalidRequestError(
        "bad request",
        param="payment_method",
        json_body={
            "error": {
                "payment_intent": {"client_secret": "pi_123_secret_456"},
                "payment_method": {"card": {"number": "4242424242424242", "cvc": "123"}},
            }
        },
    )
    with caplog.at_level("ERROR", logger="culinary"):
        with pytest.raises(HTTPException):
            _handle_stripe_error(exc, "boom", "fail")
    logged = "\n".join(r.message for r in caplog.records)
    assert "pi_123_secret_456" not in logged
    assert "4242424242424242" not in logged
    assert '"cvc": "123"' not in logged
