import os
from fastapi.testclient import TestClient
from ..main import app
from ..seed import seed

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def login_admin():
    resp = client.post('/api/auth/login', json={'email': 'admin@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def test_list_users():
    token = login_admin()
    resp = client.get('/api/admin/users', headers={'Authorization': f'Bearer {token}'})
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)


def test_promote_user_to_admin():
    token = login_admin()
    # create a regular user
    resp = client.post(
        '/api/auth/signup',
        json={'name': 'Temp', 'email': 'temp@example.com', 'password': 'password'}
    )
    assert resp.status_code == 200
    headers = {'Authorization': f'Bearer {token}'}
    resp_users = client.get('/api/admin/users', headers=headers)
    temp = next(u for u in resp_users.json() if u['email'] == 'temp@example.com')
    resp_update = client.put(
        f"/api/admin/users/{temp['id']}",
        json={'is_admin': True},
        headers=headers,
    )
    assert resp_update.status_code == 200
    assert resp_update.json()['is_admin'] is True


def test_create_product():
    token = login_admin()
    data = {'name': 'Test Prod', 'price': 10.0, 'image': 'url', 'images': ['url']}
    resp = client.post('/api/admin/products', json=data, headers={'Authorization': f'Bearer {token}'})
    assert resp.status_code == 200
    assert resp.json()['images'] == ['url']
    pid = resp.json()['id']
    resp2 = client.get('/api/admin/products', headers={'Authorization': f'Bearer {token}'})
    assert any(p['id'] == pid for p in resp2.json())


def test_update_and_delete_product():
    token = login_admin()
    headers = {'Authorization': f'Bearer {token}'}
    data = {'name': 'Temp Prod', 'price': 5.0, 'image': 'url', 'images': ['url']}
    resp = client.post('/api/admin/products', json=data, headers=headers)
    assert resp.status_code == 200
    pid = resp.json()['id']

    update = {'name': 'Updated Prod', 'price': 7.0, 'image': 'url2', 'images': ['url2']}
    resp_upd = client.put(f'/api/admin/products/{pid}', json=update, headers=headers)
    assert resp_upd.status_code == 200
    assert resp_upd.json()['name'] == 'Updated Prod'
    assert resp_upd.json()['images'] == ['url2']

    resp_del = client.delete(f'/api/admin/products/{pid}', headers=headers)
    assert resp_del.status_code == 204
    resp_list = client.get('/api/admin/products', headers=headers)
    assert not any(p['id'] == pid for p in resp_list.json())


def test_upload_image():
    token = login_admin()
    headers = {'Authorization': f'Bearer {token}'}
    png_bytes = (
        b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde"
        b"\x00\x00\x00\nIDATx\x9cc\x00\x00\x00\x02\x00\x01E\x9c\x9b\x17\x00\x00\x00\x00IEND\xaeB`\x82"
    )
    files = {'file': ('test.png', png_bytes, 'image/png')}
    resp = client.post('/api/admin/upload-image', headers=headers, files=files)
    assert resp.status_code == 200
    path = resp.json()['path']
    assert path.startswith('/lovable-uploads/')
    file_path = os.path.join('public', path.lstrip('/'))
    assert os.path.exists(file_path)
    os.remove(file_path)


def test_create_workshop():
    token = login_admin()
    data = {'title': 'WS', 'date': '2030-01-01T00:00:00', 'instructor': 'Chef', 'location': 'A'}
    resp = client.post('/api/admin/workshops', json=data, headers={'Authorization': f'Bearer {token}'})
    assert resp.status_code == 200
    wid = resp.json()['id']
    resp2 = client.get('/api/admin/workshops', headers={'Authorization': f'Bearer {token}'})
    assert any(w['id'] == wid for w in resp2.json())


def test_orders_and_reviews():
    token = login_admin()
    resp = client.get('/api/admin/orders', headers={'Authorization': f'Bearer {token}'})
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)
    resp2 = client.get('/api/admin/reviews', headers={'Authorization': f'Bearer {token}'})
    assert resp2.status_code == 200
    assert isinstance(resp2.json(), list)


def test_update_order_and_export():
    token = login_admin()
    headers = {'Authorization': f'Bearer {token}'}
    resp = client.get('/api/admin/orders', headers=headers)
    assert resp.status_code == 200
    oid = resp.json()[0]['id']
    resp2 = client.put(f'/api/admin/orders/{oid}/status', json={'status': 'Shipped'}, headers=headers)
    assert resp2.status_code == 200
    assert resp2.json()['status'] == 'Shipped'
    resp3 = client.get(f'/api/admin/orders/{oid}', headers=headers)
    assert resp3.status_code == 200
    assert resp3.json()['status'] == 'Shipped'
    resp4 = client.get('/api/admin/orders/export', headers=headers)
    assert resp4.status_code == 200
    assert 'text/csv' in resp4.headers['content-type']
