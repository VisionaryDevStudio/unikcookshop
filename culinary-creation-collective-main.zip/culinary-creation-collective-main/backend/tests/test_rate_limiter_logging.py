import importlib
import pytest
from fastapi import HTTPException
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from .. import models
from .. import rate_limiter as rl

rl = importlib.reload(rl)


def _setup_session():
    engine = create_engine("sqlite:///:memory:")
    models.Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, autocommit=False, autoflush=False)


def test_rate_limiter_logs_warning(caplog):
    SessionLocal = _setup_session()
    with SessionLocal() as db:
        key = "user@example.com"
        rl._check_rate_limit(db, key, limit=1, period=60)
        with caplog.at_level("WARNING", logger="culinary"):
            with pytest.raises(HTTPException):
                rl._check_rate_limit(db, key, limit=1, period=60)
    assert any("Rate limit exceeded for key" in r.message for r in caplog.records)
    assert any("***@example.com" in r.message for r in caplog.records)
    assert all("user@example.com" not in r.message for r in caplog.records)
