import os
import json
import hashlib
import stripe
from fastapi.testclient import TestClient
from ..main import app
from ..seed import seed
from ..database import SessionLocal
from .. import models
from decimal import Decimal
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session as SASession

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def login():
    resp = client.post('/api/auth/login', json={'email': 'user@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def _create_pending_transactions(monkeypatch, headers, payment_intent_id, expected_amount):
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'search',
        lambda **kwargs: type('obj', (), {'data': []})(),
    )

    def fake_create(**kwargs):
        assert kwargs.get('amount') == expected_amount
        return type(
            'obj',
            (),
            {
                'id': payment_intent_id,
                'client_secret': f'{payment_intent_id}_secret',
                'status': 'requires_payment_method',
                'amount': kwargs.get('amount'),
                'currency': kwargs.get('currency'),
                'metadata': kwargs.get('metadata'),
                'customer': kwargs.get('customer'),
            },
        )()

    monkeypatch.setattr(stripe.PaymentIntent, 'create', fake_create)

    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 200, resp.json()


def test_create_payment_intent_invalid_amount():
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    data = {
        'item_id': 1,
        'name': 'Workshop',
        'price': '$0',
        'category': 'Workshop',
        'image': 'url',
        'quantity': 1,
        'type': 'workshop'
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200
    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Invalid amount'


def test_create_payment_intent_customer_mismatch(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product'
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200

    class SearchResult:
        data = [type('obj', (), {'customer': 'cus_other'})()]

    monkeypatch.setattr(
        stripe.PaymentIntent,
        'search',
        lambda **kwargs: SearchResult(),
    )

    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Payment customer mismatch'


def test_create_payment_intent_currency_mismatch(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product'
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200

    class SearchResult:
        data = [type('obj', (), {'customer': 'cus_test', 'currency': 'eur'})()]

    monkeypatch.setattr(
        stripe.PaymentIntent,
        'search',
        lambda **kwargs: SearchResult(),
    )

    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Payment currency mismatch'


def test_checkout_duplicate_intent():
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    with SessionLocal() as db:
        admin = db.query(models.User).filter(models.User.email == 'admin@example.com').first()
        tx = models.Transaction(
            user_id=admin.id,
            type='Product',
            description='Test',
            amount=Decimal('10.0'),
            status='Paid',
            method='Card',
            payment_intent_id='pi_dup',
        )
        db.add(tx)
        db.commit()
    resp = client.post('/api/cart/checkout', json={'payment_intent_id': 'pi_dup'}, headers=headers)
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Payment already processed'


def test_checkout_invalid_card(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    client.post('/api/cart/sync', json={'items': []}, headers=headers)
    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product'
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200
    user_id = client.get('/api/users/me', headers=headers).json()['id']
    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal("1")))
    line_items = [{"type": "product", "id": 1, "qty": 1, "unit": unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()
    _create_pending_transactions(monkeypatch, headers, 'pi_card', unit)
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'retrieve',
        lambda pid: type('obj', (), {
            'status': 'succeeded',
            'amount_received': unit,
            'currency': 'usd',
            'payment_method': 'pm_test',
            'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
            'customer': 'cus_test',
        })()
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'retrieve',
        lambda pmid: type('obj', (), {})()
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'attach',
        lambda pmid, customer: type('obj', (), {'id': pmid})(),
    )
    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )
    resp = client.post('/api/cart/checkout', json={'payment_intent_id': 'pi_card'}, headers=headers)
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Invalid payment method'


def test_checkout_payment_method_of_another_user(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    client.post('/api/cart/sync', json={'items': []}, headers=headers)
    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product'
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200
    user_id = client.get('/api/users/me', headers=headers).json()['id']
    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal("1")))
    line_items = [{"type": "product", "id": 1, "qty": 1, "unit": unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()
    _create_pending_transactions(monkeypatch, headers, 'pi_card', unit)
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'retrieve',
        lambda pid: type('obj', (), {
            'status': 'succeeded',
            'amount_received': unit,
            'currency': 'usd',
            'payment_method': 'pm_test',
            'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
            'customer': 'cus_test',
        })()
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'retrieve',
        lambda pmid: type('obj', (), {
            'id': pmid,
            'card': type(
                'card',
                (),
                {
                    'brand': 'visa',
                    'last4': '4242',
                    'exp_month': 12,
                    'exp_year': 2027,
                },
            )(),
            'customer': 'cus_other',
        })()
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'attach',
        lambda pmid, customer: type('obj', (), {'id': pmid})(),
    )
    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )
    resp = client.post('/api/cart/checkout', json={'payment_intent_id': 'pi_card'}, headers=headers)
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Payment method belongs to another customer'


def test_checkout_setup_future_usage_mismatch(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    client.post('/api/cart/sync', json={'items': []}, headers=headers)
    initial_pms = client.get('/api/users/me/payment-methods', headers=headers).json()
    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product',
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200
    user_id = client.get('/api/users/me', headers=headers).json()['id']
    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal("1")))
    line_items = [{"type": "product", "id": 1, "qty": 1, "unit": unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()
    _create_pending_transactions(monkeypatch, headers, 'pi_mismatch', unit)
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'retrieve',
        lambda pid: type(
            'obj',
            (),
            {
                'status': 'succeeded',
                'amount_received': unit,
                'currency': 'usd',
                'payment_method': 'pm_card_123',
                'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
                'customer': 'cus_test',
                'setup_future_usage': 'off_session',
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )
    resp = client.post(
        '/api/cart/checkout',
        json={'payment_intent_id': 'pi_mismatch', 'save_payment_method': False},
        headers=headers,
    )
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Payment setup mismatch'
    after_pms = client.get('/api/users/me/payment-methods', headers=headers).json()
    assert after_pms == initial_pms


def test_checkout_detach_on_db_failure(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    client.post('/api/cart/sync', json={'items': []}, headers=headers)
    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product',
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200

    user_id = client.get('/api/users/me', headers=headers).json()['id']
    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal("1")))
    line_items = [{"type": "product", "id": 1, "qty": 1, "unit": unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()

    _create_pending_transactions(monkeypatch, headers, 'pi_dbfail', unit)

    monkeypatch.setattr(
        stripe.PaymentIntent,
        'retrieve',
        lambda pid: type(
            'obj',
            (),
            {
                'status': 'succeeded',
                'amount_received': unit,
                'currency': 'usd',
                'payment_method': 'pm_dbfail',
                'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
                'customer': 'cus_test',
                'setup_future_usage': 'off_session',
            },
        )(),
    )

    def fake_pm(pmid):
        return type(
            'obj',
            (),
            {
                'id': pmid,
                'card': type(
                    'card',
                    (),
                    {
                        'brand': 'visa',
                        'last4': '4242',
                        'exp_month': 12,
                        'exp_year': 2027,
                    },
                )(),
                'customer': None,
            },
        )()

    monkeypatch.setattr(stripe.PaymentMethod, 'retrieve', fake_pm)
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'attach',
        lambda pmid, customer: type(
            'obj',
            (),
            {
                'id': pmid,
                'card': fake_pm(pmid).card,
            },
        )(),
    )

    detached = {}

    def fake_detach(pmid):
        detached['id'] = pmid
        return type('obj', (), {})()

    monkeypatch.setattr(stripe.PaymentMethod, 'detach', fake_detach)
    monkeypatch.setattr(
        stripe.Customer, 'create', lambda **kw: type('obj', (), {'id': 'cus_test'})()
    )

    def failing_add(self, instance, _warn=True):
        raise SQLAlchemyError('db fail')

    monkeypatch.setattr(SASession, 'add', failing_add)

    resp = client.post(
        '/api/cart/checkout',
        json={'payment_intent_id': 'pi_dbfail', 'save_payment_method': True},
        headers=headers,
    )
    assert resp.status_code == 500
    assert resp.json()['detail'] == 'Failed to finalize checkout'
    assert detached.get('id') == 'pm_dbfail'

