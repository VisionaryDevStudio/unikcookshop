import os
from fastapi.testclient import TestClient
from ..main import app
from ..seed import seed

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def login():
    resp = client.post('/api/auth/login', json={'email': 'user@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def test_checkout_invalid_payment_intent_id():
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    resp = client.post('/api/cart/checkout', json={'payment_intent_id': 'invalid'}, headers=headers)
    assert resp.status_code in (400, 422)
