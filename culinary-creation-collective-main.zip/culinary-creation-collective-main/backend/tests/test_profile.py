import os
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from ..main import app
from ..seed import seed

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists("app.db"):
        os.remove("app.db")


def login():
    resp = client.post(
        "/api/auth/login",
        json={"email": "user@example.com", "password": "password"},
    )
    assert resp.status_code == 200
    return resp.json()["access_token"]


def test_get_profile():
    token = login()
    resp = client.get("/api/users/me", headers={"Authorization": f"Bearer {token}"})
    assert resp.status_code == 200
    assert resp.json()["email"] == "user@example.com"


def test_update_profile():
    token = login()
    resp = client.put(
        "/api/users/me",
        headers={"Authorization": f"Bearer {token}"},
        json={"location": "NY"},
    )
    assert resp.status_code == 200
    assert resp.json()["location"] == "NY"


def test_workshops():
    token = login()
    resp_up = client.get(
        "/api/users/me/workshops/upcoming",
        headers={"Authorization": f"Bearer {token}"},
    )
    resp_hist = client.get(
        "/api/users/me/workshops/history",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp_up.status_code == 200
    assert resp_hist.status_code == 200
    data_up = resp_up.json()
    data_hist = resp_hist.json()
    assert isinstance(data_up, list)
    assert isinstance(data_hist, list)
    now = datetime.now(timezone.utc)
    up_dates = [datetime.fromisoformat(w["date"]) for w in data_up]
    hist_dates = [datetime.fromisoformat(w["date"]) for w in data_hist]
    assert all(d.tzinfo is not None for d in up_dates + hist_dates)
    assert all(d >= now for d in up_dates)
    assert all(d < now for d in hist_dates)
