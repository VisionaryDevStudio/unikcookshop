import os
import json
import hashlib
import stripe
import pytest
from decimal import Decimal
from datetime import datetime, timedelta, timezone
from fastapi.testclient import TestClient
from ..main import app
from ..seed import seed
from ..database import SessionLocal
from .. import models
from sqlalchemy.orm import Session as SASession
from sqlalchemy.exc import SQLAlchemyError

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def login():
    resp = client.post('/api/auth/login', json={'email': 'user@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def _create_pending_transactions(monkeypatch, headers, payment_intent_id, expected_amount):
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'search',
        lambda **kwargs: type('obj', (), {'data': []})(),
    )

    def fake_create(**kwargs):
        assert kwargs.get('amount') == expected_amount
        return type(
            'obj',
            (),
            {
                'id': payment_intent_id,
                'client_secret': f'{payment_intent_id}_secret',
                'status': 'requires_payment_method',
                'amount': kwargs.get('amount'),
                'currency': kwargs.get('currency'),
                'metadata': kwargs.get('metadata'),
                'customer': kwargs.get('customer'),
            },
        )()

    monkeypatch.setattr(stripe.PaymentIntent, 'create', fake_create)

    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 200, resp.json()


def test_cart_crud_and_checkout(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    # initially empty
    resp = client.get('/api/cart', headers=headers)
    assert resp.status_code == 200
    assert resp.json() == []

    # add item
    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product'
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200
    assert resp.json()['quantity'] == 1

    # add same again
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200
    assert resp.json()['quantity'] == 2

    item_id = resp.json()['id']

    # update quantity
    data['quantity'] = 5
    resp = client.put(f'/api/cart/items/{item_id}', json=data, headers=headers)
    assert resp.status_code == 200
    assert resp.json()['quantity'] == 5

    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal("1")))
    expected_total = unit * 5

    resp = client.get('/api/cart/summary', headers=headers)
    assert resp.status_code == 200
    summary = resp.json()
    assert summary['subtotal'] == expected_total / 100

    resp = client.get('/api/cart/total', headers=headers)
    assert resp.status_code == 200
    total_resp = resp.json()
    assert total_resp['total'] == expected_total

    captured = {}
    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'search',
        lambda **kwargs: type('obj', (), {'data': []})(),
    )

    def fake_create(**kwargs):
        captured['amount'] = kwargs.get('amount')
        return type('obj', (), {'id': 'pi_test', 'client_secret': 'cs_test'})()

    monkeypatch.setattr(stripe.PaymentIntent, 'create', fake_create)

    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 200
    assert captured['amount'] == expected_total
    assert resp.json()['client_secret'] == 'cs_test'

    # prepare payment intent metadata
    user_id = client.get('/api/users/me', headers=headers).json()['id']
    line_items = [{"type": "product", "id": 1, "qty": 5, "unit": unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()

    # checkout
    client.get('/api/users/me', headers=headers)
    line_items = [{
        'type': 'product',
        'id': 1,
        'qty': 5,
        'unit': unit,
    }]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'retrieve',
        lambda pid: type(
            'obj',
            (),
            {
                'status': 'succeeded',
                'amount_received': expected_total,
                'currency': 'usd',
                'payment_method': 'pm_test',
                'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
                'customer': 'cus_test',
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'retrieve',
        lambda pmid: type(
            'obj',
            (),
            {
                'id': pmid,
                'card': type(
                    'card',
                    (),
                    {
                        'brand': 'visa',
                        'last4': '4242',
                        'exp_month': 12,
                        'exp_year': 2027,
                    },
                )(),
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'attach',
        lambda pmid, customer: type('obj', (), {'id': pmid})(),
    )
    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )

    resp = client.post('/api/cart/checkout', json={'payment_intent_id': 'pi_test'}, headers=headers)
    assert resp.status_code == 200
    first_checkout = resp.json()
    assert isinstance(first_checkout, list) and len(first_checkout) > 0

    # calling checkout again with same payment intent should return existing
    resp = client.post('/api/cart/checkout', json={'payment_intent_id': 'pi_test'}, headers=headers)
    assert resp.status_code == 200
    assert resp.json() == first_checkout

    # cart should be empty now
    resp = client.get('/api/cart', headers=headers)
    assert resp.status_code == 200
    assert resp.json() == []

    # purchased products should include the item
    resp = client.get('/api/users/me/products', headers=headers)
    assert any(p['id'] == 1 for p in resp.json())

    with SessionLocal() as db:
        assert db.query(models.Product).get(1).stock_count == 8 - 5


def test_checkout_saves_payment_method_once(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    # ensure starting payment methods count
    resp = client.get('/api/users/me/payment-methods', headers=headers)
    assert resp.status_code == 200
    initial_pms = resp.json()
    initial_count = len(initial_pms)

    # add item to cart
    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product'
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200
    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )

    # compute metadata
    user_id = client.get('/api/users/me', headers=headers).json()['id']
    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal("1")))
    line_items = [{"type": "product", "id": 1, "qty": 1, "unit": unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()

    _create_pending_transactions(monkeypatch, headers, 'pi_one', unit)

    def fake_intent(pid):
        return type(
            'obj',
            (),
            {
                'status': 'succeeded',
                'amount_received': unit,
                'currency': 'usd',
                'payment_method': 'pm_card_123',
                'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
                'customer': 'cus_test',
                'setup_future_usage': 'off_session',
            },
        )()

    def fake_pm(pmid):
        return type(
            'obj',
            (),
            {
                'id': pmid,
                'card': type(
                    'card',
                    (),
                    {
                        'brand': 'visa',
                        'last4': '4242',
                        'exp_month': 12,
                        'exp_year': 2027,
                    },
                )(),
            },
        )()

    monkeypatch.setattr(stripe.PaymentIntent, 'retrieve', fake_intent)
    monkeypatch.setattr(stripe.PaymentMethod, 'retrieve', fake_pm)
    monkeypatch.setattr(
        stripe.PaymentMethod, 'attach', lambda pmid, customer: type('obj', (), {'id': pmid})()
    )

    # first checkout
    resp = client.post(
        '/api/cart/checkout',
        json={'payment_intent_id': 'pi_one', 'save_payment_method': True},
        headers=headers,
    )
    assert resp.status_code == 200

    # ensure payment method saved
    resp = client.get('/api/users/me/payment-methods', headers=headers)
    assert resp.status_code == 200
    pms_after_first = resp.json()
    assert len(pms_after_first) == initial_count + 1
    assert any(pm['stripe_pm_id'] == 'pm_card_123' for pm in pms_after_first)

    # add item again for second checkout
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200

    _create_pending_transactions(monkeypatch, headers, 'pi_two', unit)

    # second checkout with different payment intent but same payment method
    resp = client.post(
        '/api/cart/checkout',
        json={'payment_intent_id': 'pi_two', 'save_payment_method': True},
        headers=headers,
    )
    assert resp.status_code == 200

    # payment methods should not increase
    resp = client.get('/api/users/me/payment-methods', headers=headers)
    assert resp.status_code == 200
    pms_after_second = resp.json()
    assert len(pms_after_second) == initial_count + 1
    assert [pm for pm in pms_after_second if pm['stripe_pm_id'] == 'pm_card_123']


def test_checkout_does_not_save_payment_method_when_false(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    resp = client.get('/api/users/me/payment-methods', headers=headers)
    assert resp.status_code == 200
    initial_count = len(resp.json())

    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product'
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200

    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )

    user_id = client.get('/api/users/me', headers=headers).json()['id']
    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal('1')))
    line_items = [{"type": "product", "id": 1, "qty": 1, "unit": unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()

    _create_pending_transactions(monkeypatch, headers, 'pi_nosave', unit)

    def fake_intent(pid):
        return type(
            'obj',
            (),
            {
                'status': 'succeeded',
                'amount_received': unit,
                'currency': 'usd',
                'payment_method': 'pm_card_nosave',
                'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
                'customer': 'cus_test',
                'setup_future_usage': None,
            },
        )()

    def fake_pm(pmid):
        return type(
            'obj',
            (),
            {
                'id': pmid,
                'card': type(
                    'card',
                    (),
                    {
                        'brand': 'visa',
                        'last4': '4242',
                        'exp_month': 12,
                        'exp_year': 2027,
                    },
                )(),
                'customer': None,
            },
        )()

    detached = {}

    def fake_detach(pmid):
        detached['id'] = pmid
        return type('obj', (), {'id': pmid})()

    monkeypatch.setattr(stripe.PaymentIntent, 'retrieve', fake_intent)
    monkeypatch.setattr(stripe.PaymentMethod, 'retrieve', fake_pm)
    monkeypatch.setattr(
        stripe.PaymentMethod, 'attach', lambda pmid, customer: type('obj', (), {'id': pmid})()
    )
    monkeypatch.setattr(stripe.PaymentMethod, 'detach', fake_detach)

    resp = client.post(
        '/api/cart/checkout',
        json={'payment_intent_id': 'pi_nosave', 'save_payment_method': False},
        headers=headers,
    )
    assert resp.status_code == 200

    resp = client.get('/api/users/me/payment-methods', headers=headers)
    assert resp.status_code == 200
    assert len(resp.json()) == initial_count
    assert detached['id'] == 'pm_card_nosave'


def test_checkout_customer_mismatch(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product'
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200

    user_id = client.get('/api/users/me', headers=headers).json()['id']
    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal("1")))
    line_items = [{"type": "product", "id": 1, "qty": 1, "unit": unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()

    with SessionLocal() as db:
        prod = db.query(models.Product).get(1)
        if prod:
            prod.stock_count = 10
            db.commit()

    _create_pending_transactions(monkeypatch, headers, 'pi_bad', unit)

    monkeypatch.setattr(
        stripe.PaymentIntent,
        'retrieve',
        lambda pid: type(
            'obj',
            (),
            {
                'status': 'succeeded',
                'amount_received': unit,
                'currency': 'usd',
                'payment_method': 'pm_test',
                'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
                'customer': 'cus_other',
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )

    resp = client.post('/api/cart/checkout', json={'payment_intent_id': 'pi_bad'}, headers=headers)
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Payment customer mismatch'


def test_create_payment_intent_updates_on_cart_change(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    # ensure empty cart
    client.post('/api/cart/sync', json={'items': []}, headers=headers)

    with SessionLocal() as db:
        prod = db.query(models.Product).get(1)
        prod.stock_count = 10
        db.commit()

    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )

    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product',
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200
    item_id = resp.json()['id']

    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal("1")))
    initial_total = unit

    # initial payment intent creation
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'search',
        lambda **kwargs: type('obj', (), {'data': []})(),
    )
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'create',
        lambda **kwargs: type('obj', (), {'id': 'pi_test', 'client_secret': 'cs_test'})(),
    )
    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 200

    # change cart quantity
    data['quantity'] = 2
    resp = client.put(f'/api/cart/items/{item_id}', json=data, headers=headers)
    assert resp.status_code == 200
    updated_total = unit * 2

    # second call should modify existing intent
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'search',
        lambda **kwargs: type(
            'obj',
            (),
            {
                'data': [
                    type(
                        'obj',
                        (),
                        {
                            'id': 'pi_test',
                            'client_secret': 'cs_test',
                            'amount': initial_total,
                            'customer': 'cus_test',
                            'currency': 'usd',
                        },
                    )()
                ]
            },
        )(),
    )
    captured = {}

    def fake_modify(pid, **kwargs):
        captured['amount'] = kwargs.get('amount')
        return type('obj', (), {'id': pid, 'client_secret': 'cs_test'})()

    monkeypatch.setattr(stripe.PaymentIntent, 'modify', fake_modify)
    monkeypatch.setattr(
        stripe.PaymentIntent,
        'create',
        lambda **kwargs: (_ for _ in ()).throw(AssertionError('should not create')),
    )

    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 200
    assert captured['amount'] == updated_total


@pytest.mark.parametrize("status", ["succeeded", "canceled"])
def test_create_payment_intent_new_when_finalized(monkeypatch, status):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    # reset cart and inventory
    client.post('/api/cart/sync', json={'items': []}, headers=headers)
    with SessionLocal() as db:
        prod = db.query(models.Product).get(1)
        prod.stock_count = 10
        db.commit()

    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product',
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200

    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal("1")))
    expected_total = unit

    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )

    def fake_search(**kwargs):
        return type(
            'obj',
            (),
            {
                'data': [
                    type(
                        'obj',
                        (),
                        {
                            'id': 'pi_old',
                            'client_secret': 'cs_old',
                            'amount': expected_total,
                            'status': status,
                            'customer': 'cus_test',
                            'currency': 'usd',
                        },
                    )()
                ]
            },
        )()

    monkeypatch.setattr(stripe.PaymentIntent, 'search', fake_search)

    captured = {}

    def fake_create(**kwargs):
        captured['amount'] = kwargs.get('amount')
        return type('obj', (), {'id': 'pi_new', 'client_secret': 'cs_new'})()

    monkeypatch.setattr(stripe.PaymentIntent, 'create', fake_create)

    def fake_modify(pid, **kwargs):
        raise AssertionError('should not modify finalized intent')

    monkeypatch.setattr(stripe.PaymentIntent, 'modify', fake_modify)

    resp = client.post('/api/cart/create-payment-intent', headers=headers)
    assert resp.status_code == 200
    assert captured['amount'] == expected_total

@pytest.mark.xfail(reason="rollback test flaky with inventory updates")
def test_checkout_db_error_rolls_back(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    client.post('/api/cart/sync', json={'items': []}, headers=headers)
    with SessionLocal() as db:
        prod = db.query(models.Product).get(1)
        prod.stock_count = 10
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        user.stripe_customer_id = 'cus_existing'
        db.commit()

    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product'
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200

    user_id = client.get('/api/users/me', headers=headers).json()['id']

    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal("1")))
        initial_tr = db.query(models.Transaction).count()
        initial_up = db.query(models.UserProduct).count()
        initial_cart = db.query(models.CartItem).filter(models.CartItem.user_id == user_id).count()
    line_items = [{"type": "product", "id": 1, "qty": 1, "unit": unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()

    _create_pending_transactions(monkeypatch, headers, 'pi_test', unit)

    monkeypatch.setattr(
        stripe.PaymentIntent,
        'retrieve',
        lambda pid: type(
            'obj',
            (),
            {
                'status': 'succeeded',
                'amount_received': unit,
                'currency': 'usd',
                'payment_method': 'pm_test',
                'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
                'customer': 'cus_existing',
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'retrieve',
        lambda pmid: type(
            'obj',
            (),
            {
                'id': pmid,
                'card': type(
                    'card',
                    (),
                    {
                        'brand': 'visa',
                        'last4': '4242',
                        'exp_month': 12,
                        'exp_year': 2030,
                    },
                )(),
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'attach',
        lambda pmid, customer: type('obj', (), {'id': pmid})(),
    )
    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )

    SessionCls = SessionLocal().__class__
    original_add = SessionCls.add

    def faulty_add(self, instance, *args, **kwargs):
        if isinstance(instance, models.Transaction):
            raise SQLAlchemyError('boom')
        return original_add(self, instance, *args, **kwargs)

    monkeypatch.setattr(SessionCls, 'add', faulty_add)

    resp = client.post('/api/cart/checkout', json={'payment_intent_id': 'pi_test'}, headers=headers)
    assert resp.status_code == 500

    with SessionLocal() as db:
        assert db.query(models.Transaction).count() == initial_tr
        assert db.query(models.UserProduct).count() == initial_up
        assert db.query(models.CartItem).filter(models.CartItem.user_id == user_id).count() == initial_cart


def test_item_unavailable_product():
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    client.post('/api/cart/sync', json={'items': []}, headers=headers)
    data = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 100,
        'type': 'product',
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200
    resp = client.get('/api/cart/total', headers=headers)
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Item unavailable'


def test_item_unavailable_workshop():
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    client.post('/api/cart/sync', json={'items': []}, headers=headers)
    data = {
        'item_id': 1,
        'name': 'Italian Pasta Mastery',
        'price': '$100',
        'category': 'Workshop',
        'image': 'url',
        'quantity': 13,
        'type': 'workshop',
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200
    resp = client.get('/api/cart/total', headers=headers)
    assert resp.status_code == 400
    assert resp.json()['detail'] == 'Item unavailable'


def test_checkout_reduces_workshop_spots(monkeypatch):
    token = login()
    headers = {'Authorization': f'Bearer {token}'}
    client.post('/api/cart/sync', json={'items': []}, headers=headers)
    with SessionLocal() as db:
        user = db.query(models.User).filter(models.User.email == 'user@example.com').first()
        user.stripe_customer_id = 'cus_ws'
        ws = models.Workshop(
            title='Temp',
            date=datetime.now(timezone.utc) + timedelta(days=1),
            instructor='Chef',
            location='Kitchen',
            spots=5,
            price=50.0,
        )
        db.add(ws)
        db.commit()
        db.refresh(ws)
        ws_id = ws.id
        unit = int((Decimal(ws.price) * Decimal(100)).quantize(Decimal('1')))
    data = {
        'item_id': ws_id,
        'name': 'Temp',
        'price': '$50',
        'category': 'Workshop',
        'image': 'url',
        'quantity': 2,
        'type': 'workshop',
    }
    resp = client.post('/api/cart/items', json=data, headers=headers)
    assert resp.status_code == 200
    user_id = client.get('/api/users/me', headers=headers).json()['id']
    line_items = [{"type": "workshop", "id": ws_id, "qty": 2, "unit": unit}]
    cart_fp = hashlib.sha256(json.dumps(line_items, sort_keys=True).encode()).hexdigest()

    _create_pending_transactions(monkeypatch, headers, 'pi_ws', unit * 2)

    monkeypatch.setattr(
        stripe.PaymentIntent,
        'retrieve',
        lambda pid: type(
            'obj',
            (),
            {
                'status': 'succeeded',
                'amount_received': unit * 2,
                'currency': 'usd',
                'payment_method': 'pm_test',
                'metadata': {'user_id': str(user_id), 'cart_fp': cart_fp},
                'customer': 'cus_ws',
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'retrieve',
        lambda pmid: type(
            'obj',
            (),
            {
                'id': pmid,
                'card': type(
                    'card',
                    (),
                    {
                        'brand': 'visa',
                        'last4': '4242',
                        'exp_month': 12,
                        'exp_year': 2027,
                    },
                )(),
            },
        )(),
    )
    monkeypatch.setattr(
        stripe.PaymentMethod,
        'attach',
        lambda pmid, customer: type('obj', (), {'id': pmid})(),
    )
    monkeypatch.setattr(
        stripe.Customer,
        'create',
        lambda **kw: type('obj', (), {'id': 'cus_test'})(),
    )

    resp = client.post(
        '/api/cart/checkout',
        json={'payment_intent_id': 'pi_ws'},
        headers=headers,
    )
    assert resp.status_code == 200
    with SessionLocal() as db:
        assert db.query(models.Workshop).get(ws_id).spots == 3
