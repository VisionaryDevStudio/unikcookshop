import os
from decimal import Decimal
import logging

import pytest
from fastapi import HTTPException

# Ensure the webhook secret is set before importing the module
os.environ.setdefault("STRIPE_WEBHOOK_SECRET", "whsec_test")
os.environ.setdefault("STRIPE_ACCOUNT_ID", "acct_test")
os.environ.setdefault("STRIPE_LIVE_MODE", "false")

from .. import models
from ..services import payments


@pytest.fixture
def transactions():
    """Return a set of transactions sharing a payment_intent_id."""
    return [
        models.Transaction(
            user_id=1,
            type="Product",
            description="Item 1",
            amount=Decimal("10.00"),
            status="Pending",
            method="Card",
            payment_intent_id="pi_test",
        ),
        models.Transaction(
            user_id=1,
            type="Product",
            description="Item 2",
            amount=Decimal("5.00"),
            status="Pending",
            method="Card",
            payment_intent_id="pi_test",
        ),
    ]


def test_amount_mismatch_raises(transactions):
    with pytest.raises(HTTPException) as excinfo:
        payments.verify_amount_currency(transactions, 2000, "usd", "evt_test", {})
    assert excinfo.value.status_code == 400
    assert excinfo.value.detail == "Amount mismatch"


def test_currency_mismatch_raises(transactions):
    total_cents = int(round(sum(tx.amount for tx in transactions) * 100))
    with pytest.raises(HTTPException) as excinfo:
        payments.verify_amount_currency(transactions, total_cents, "eur", "evt_test", {})
    assert excinfo.value.status_code == 400
    assert excinfo.value.detail == "Currency mismatch"


def test_amount_currency_match(transactions):
    total_cents = int(round(sum(tx.amount for tx in transactions) * 100))
    # Should not raise an exception when both amount and currency match
    payments.verify_amount_currency(transactions, total_cents, "usd", "evt_test", {})


def test_warning_log_emitted_on_amount_mismatch(transactions, caplog):
    event_id = "evt_test"
    payload = {"id": "pi_test", "amount": 2000, "currency": "usd"}
    with caplog.at_level(logging.WARNING, logger="culinary"):
        with pytest.raises(HTTPException):
            payments.verify_amount_currency(transactions, 2000, "usd", event_id, payload)
    assert any("amount mismatch" in record.getMessage() for record in caplog.records)
    # Ensure event id and payment intent id appear in the log
    assert event_id in caplog.text
    assert "pi_test" in caplog.text
