import os
from decimal import Decimal
from fastapi.testclient import TestClient

from ..main import app
from ..seed import seed
from ..database import SessionLocal
from .. import models

client = TestClient(app)


def setup_module(module):
    """Seed the database for cart total tests."""
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def login():
    resp = client.post('/api/auth/login', json={'email': 'user@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def test_summary_and_total_values():
    token = login()
    headers = {'Authorization': f'Bearer {token}'}

    # ensure cart has an item
    item = {
        'item_id': 1,
        'name': 'Knife Set',
        'price': '$10',
        'category': 'Tools',
        'image': 'url',
        'quantity': 1,
        'type': 'product',
    }
    resp = client.post('/api/cart/items', json=item, headers=headers)
    assert resp.status_code == 200

    with SessionLocal() as db:
        unit = int((db.query(models.Product).get(1).price * Decimal(100)).quantize(Decimal("1")))

    resp = client.get('/api/cart/summary', headers=headers)
    assert resp.status_code == 200
    assert resp.json()['subtotal'] == unit / 100

    resp = client.get('/api/cart/total', headers=headers)
    assert resp.status_code == 200
    assert resp.json()['total'] == unit

