import os
from datetime import datetime, timezone
from fastapi.testclient import TestClient
from ..main import app
from ..seed import seed

client = TestClient(app)


def setup_module(module):
    seed()


def teardown_module(module):
    if os.path.exists('app.db'):
        os.remove('app.db')


def login_admin():
    resp = client.post('/api/auth/login', json={'email': 'admin@example.com', 'password': 'password'})
    assert resp.status_code == 200
    return resp.json()['access_token']


def test_create_workshop_normalizes_to_utc():
    token = login_admin()
    data = {
        'title': 'TZ WS',
        'date': '2030-01-01T10:00:00+05:00',
        'instructor': 'Chef',
        'location': 'A'
    }
    resp = client.post('/api/admin/workshops', json=data, headers={'Authorization': f'Bearer {token}'})
    assert resp.status_code == 200
    stored = datetime.fromisoformat(resp.json()['date'])
    assert stored.tzinfo == timezone.utc
    assert stored == datetime(2030, 1, 1, 5, 0, tzinfo=timezone.utc)


def test_update_workshop_normalizes_to_utc():
    token = login_admin()
    create_data = {
        'title': 'Init',
        'date': '2030-06-01T00:00:00+00:00',
        'instructor': 'Chef',
        'location': 'A'
    }
    resp_create = client.post('/api/admin/workshops', json=create_data, headers={'Authorization': f'Bearer {token}'})
    assert resp_create.status_code == 200
    wid = resp_create.json()['id']
    update_data = {
        'title': 'Init',
        'date': '2030-06-01T10:00:00-04:00',
        'instructor': 'Chef',
        'location': 'A'
    }
    resp_update = client.put(f'/api/admin/workshops/{wid}', json=update_data, headers={'Authorization': f'Bearer {token}'})
    assert resp_update.status_code == 200
    stored = datetime.fromisoformat(resp_update.json()['date'])
    assert stored.tzinfo == timezone.utc
    assert stored == datetime(2030, 6, 1, 14, 0, tzinfo=timezone.utc)
