import pytest
from urllib.parse import quote
from ..routers.cart import build_pi_search_query


@pytest.mark.parametrize(
    "user_id, cart_fp",
    [
        ("user 123", "hash+value"),
        ("1\" OR status:\"succeeded", "cart/123?foo=bar"),
    ],
)
def test_build_pi_search_query_encodes(user_id, cart_fp):
    query = build_pi_search_query(user_id, cart_fp)
    assert user_id not in query
    assert cart_fp not in query
    expected = (
        f'metadata["user_id"]:"{quote(str(user_id), safe="")}" '
        f'AND metadata["cart_fp"]:"{quote(str(cart_fp), safe="")}"'
    )
    assert query == expected
