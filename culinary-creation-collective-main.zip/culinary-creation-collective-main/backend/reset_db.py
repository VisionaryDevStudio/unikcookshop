from .database import Base, engine, SessionLocal
from .models import User, SiteSetting
from .auth import get_password_hash
import os
import json


def reset_database():
    """Reset the database leaving only the admin user and default site settings."""
    engine.dispose()
    if os.path.exists('app.db'):
        os.remove('app.db')
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    admin = User(
        name='Admin',
        email='admin@example.com',
        password_hash=get_password_hash('password'),
        is_admin=True,
    )
    db.add(admin)

    default_homepage = {
        'hero_title': 'Welcome to Unikcookshop',
        'hero_subtitle': 'Join our culinary workshops and unleash your creativity in the kitchen.',
        'hero_image': 'https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=2070&q=80',
        'inquiry_title': 'Custom Booking Request',
        'inquiry_description': 'Planning a special event or looking for a customized cooking experience? Fill out our inquiry form and our team will help create the perfect culinary adventure for you.',
        'expert_title': 'Expert Chefs at Your Service',
        'expert_description': 'Our professional chefs bring years of culinary expertise to each lesson, ensuring a high-quality learning experience.',
        'workshop_types': [
            {'id': 1, 'title': 'Group Lessons', 'description': 'Learn in a social environment with other cooking enthusiasts', 'icon': 'Users', 'link': '/workshops?type=group'},
            {'id': 2, 'title': 'Kids Workshops', 'description': 'Fun cooking classes designed specifically for young chefs', 'icon': 'UserPlus', 'link': '/workshops?type=kids'},
            {'id': 3, 'title': 'Date Night', 'description': 'Cook a romantic meal together and enjoy a memorable evening', 'icon': 'Heart', 'link': '/workshops?type=date-night'},
            {'id': 4, 'title': 'Private Sessions', 'description': 'Personalized one-on-one instruction with our skilled chefs', 'icon': 'Calendar', 'link': '/workshops?type=private'},
            {'id': 5, 'title': 'Team Building', 'description': 'Strengthen workplace bonds through collaborative cooking', 'icon': 'Building2', 'link': '/workshops?type=team-building'},
            {'id': 6, 'title': 'Cooking Crash Course', 'description': 'Intensive sessions to quickly boost your culinary skills', 'icon': 'Rocket', 'link': '/workshops?type=crash-course'},
        ],
    }
    db.add(SiteSetting(key='homepage', value=json.dumps(default_homepage)))

    db.commit()
    db.close()


if __name__ == '__main__':
    reset_database()
