"""Stripe payment reconciliation helpers."""

from __future__ import annotations

import asyncio
import json
from decimal import Decimal
from typing import Any, Optional

import stripe
from fastapi import HTTPException
from sqlalchemy.orm import Session

from .. import models
from ..database import SessionLocal
from ..logger import logger


def verify_amount_currency(
    txs: list[models.Transaction],
    amount_cents: Optional[int],
    currency: Optional[str],
    event_id: Optional[str] = None,
    payload: Optional[dict[str, Any]] = None,
) -> None:
    """Ensure Stripe event amount and currency match our records."""

    total_cents = int(round(sum(tx.amount for tx in txs) * 100)) if txs else None
    payment_intent_id = txs[0].payment_intent_id if txs else None
    if amount_cents is not None and total_cents is not None and total_cents != int(amount_cents):
        logger.warning(
            "Stripe event %s payment %s amount mismatch: expected %s but received %s. Payload: %s",
            event_id,
            payment_intent_id,
            total_cents,
            amount_cents,
            payload,
        )
        raise HTTPException(status_code=400, detail="Amount mismatch")
    if currency is not None and currency.lower() != "usd":
        logger.warning(
            "Stripe event %s payment %s currency mismatch: expected usd with amount %s but received %s with amount %s. Payload: %s",
            event_id,
            payment_intent_id,
            total_cents,
            currency,
            amount_cents,
            payload,
        )
        raise HTTPException(status_code=400, detail="Currency mismatch")


def verify_user(
    txs: list[models.Transaction],
    customer_id: Optional[str],
    metadata_user_id: Optional[str],
) -> None:
    """Ensure Stripe event user information matches our records."""

    if not txs:
        return
    user = txs[0].user
    payment_intent_id = txs[0].payment_intent_id

    if metadata_user_id is not None and metadata_user_id != str(user.id):
        logger.warning(
            "Payment %s user mismatch: expected %s but received %s",
            payment_intent_id,
            user.id,
            metadata_user_id,
        )
        raise HTTPException(status_code=400, detail="Customer mismatch")

    if customer_id is not None and user.stripe_customer_id and customer_id != user.stripe_customer_id:
        logger.warning(
            "Payment %s customer mismatch: expected %s but received %s",
            payment_intent_id,
            user.stripe_customer_id,
            customer_id,
        )
        raise HTTPException(status_code=400, detail="Customer mismatch")


def persist_unmatched_payment_intent_event(db: Session, event: dict[str, Any]) -> None:
    """Persist payment_intent webhook payload for later reconciliation."""

    intent = event.get("data", {}).get("object", {})
    payment_intent_id = intent.get("id")
    if not payment_intent_id:
        logger.warning(
            "Skipping pending queue write for event %s without payment intent",
            event.get("id"),
        )
        return

    existing = (
        db.query(models.PendingStripeEvent)
        .filter(models.PendingStripeEvent.event_id == event["id"])
        .first()
    )
    if existing:
        return

    payload = json.dumps(event)
    pending = models.PendingStripeEvent(
        event_id=event["id"],
        payment_intent_id=payment_intent_id,
        event_type=event.get("type", ""),
        payload=payload,
    )
    db.add(pending)


_STATUS_FROM_EVENT = {
    "payment_intent.succeeded": "Paid",
    "payment_intent.processing": "Processing",
    "payment_intent.payment_failed": "Failed",
    "payment_intent.canceled": "Canceled",
}


def _status_for_event(event_type: str) -> Optional[str]:
    return _STATUS_FROM_EVENT.get(event_type)


def _attr(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _ensure_processed_payment_intent(db: Session, user_id: int, payment_intent_id: str) -> None:
    processed = (
        db.query(models.ProcessedPaymentIntent)
        .filter(models.ProcessedPaymentIntent.payment_intent_id == payment_intent_id)
        .first()
    )
    if processed:
        if processed.user_id != user_id:
            raise ValueError("Payment intent already processed for another user")
        return
    db.add(
        models.ProcessedPaymentIntent(
            user_id=user_id,
            payment_intent_id=payment_intent_id,
        )
    )


def _backfill_transactions(
    db: Session,
    user: models.User,
    payment_intent_id: str,
    amount_cents: int,
    status: str,
) -> None:
    if amount_cents <= 0:
        raise ValueError("Invalid payment amount")
    amount = (Decimal(amount_cents) / Decimal("100")).quantize(Decimal("0.01"))
    transaction = models.Transaction(
        user_id=user.id,
        type="Payment",
        description=f"Stripe payment {payment_intent_id}",
        amount=amount,
        status=status,
        method="Card",
        payment_intent_id=payment_intent_id,
    )
    db.add(transaction)


def reconcile_pending_payment_events(db: Optional[Session] = None) -> int:
    """Process queued webhook events that lacked matching transactions."""

    own_session = False
    if db is None:
        db = SessionLocal()
        own_session = True

    processed = 0
    try:
        pending_events = (
            db.query(models.PendingStripeEvent)
            .order_by(models.PendingStripeEvent.created_at)
            .all()
        )
        for pending in pending_events:
            try:
                _process_pending_event(db, pending)
            except Exception as exc:  # pragma: no cover - logged for visibility
                logger.exception(
                    "Failed to reconcile Stripe event %s", pending.event_id
                )
                pending.attempts += 1
                pending.last_error = str(exc)
                db.add(pending)
                db.commit()
            else:
                db.delete(pending)
                db.commit()
                processed += 1
    finally:
        if own_session:
            db.close()
    return processed


def _process_pending_event(db: Session, pending: models.PendingStripeEvent) -> None:
    status = _status_for_event(pending.event_type)
    if not status:
        raise ValueError(f"Unsupported pending event type {pending.event_type}")

    intent = stripe.PaymentIntent.retrieve(pending.payment_intent_id)
    metadata = _attr(intent, "metadata", {}) or {}
    metadata_user_id = metadata.get("user_id")
    if not metadata_user_id:
        raise ValueError("Payment intent missing user metadata")
    try:
        user_id = int(metadata_user_id)
    except ValueError as exc:  # pragma: no cover - defensive
        raise ValueError("Invalid user metadata") from exc

    user = db.get(models.User, user_id)
    if not user:
        raise ValueError("User not found for payment intent")

    customer_id = _attr(intent, "customer")
    if customer_id and user.stripe_customer_id and customer_id != user.stripe_customer_id:
        raise ValueError("Customer mismatch during reconciliation")

    txs = (
        db.query(models.Transaction)
        .filter(models.Transaction.payment_intent_id == pending.payment_intent_id)
        .all()
    )

    amount_field = "amount_received" if pending.event_type == "payment_intent.succeeded" else "amount"
    amount_cents = _attr(intent, amount_field)
    currency = (_attr(intent, "currency") or "").lower() or None

    if txs:
        try:
            verify_user(txs, customer_id, metadata_user_id)
            verify_amount_currency(
                txs,
                amount_cents,
                currency,
                pending.event_id,
                pending_payload(pending),
            )
        except HTTPException as exc:
            raise ValueError(exc.detail) from exc
        for tx in txs:
            tx.status = status
        _ensure_processed_payment_intent(db, user.id, pending.payment_intent_id)
        db.flush()
        return

    if amount_cents is None:
        raise ValueError("Payment intent missing amount information")
    if currency and currency != "usd":
        raise ValueError("Currency mismatch during reconciliation")

    _ensure_processed_payment_intent(db, user.id, pending.payment_intent_id)
    _backfill_transactions(db, user, pending.payment_intent_id, int(amount_cents), status)
    db.flush()


def pending_payload(pending: models.PendingStripeEvent) -> dict[str, Any]:
    try:
        return json.loads(pending.payload)
    except json.JSONDecodeError:  # pragma: no cover - defensive
        return {}


_reconciliation_task: Optional[asyncio.Task] = None


def schedule_reconciliation() -> None:
    """Schedule reconciliation in the background."""

    global _reconciliation_task
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        reconcile_pending_payment_events()
        return

    if _reconciliation_task and not _reconciliation_task.done():
        return

    async def _runner() -> None:
        try:
            await asyncio.to_thread(reconcile_pending_payment_events)
        except Exception:  # pragma: no cover - defensive
            logger.exception("Stripe reconciliation task failed")

    _reconciliation_task = loop.create_task(_runner())

