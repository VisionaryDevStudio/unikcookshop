from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

from dotenv import load_dotenv


def _ensure_environment() -> None:
    """Load environment variables required for seeding."""

    backend_dir = Path(__file__).resolve().parent

    # Load backend/.env first so that SECRET_KEY and other sensitive values are
    # available when the auth module initializes. Fall back to the project root
    # .env if present.
    load_dotenv(backend_dir / ".env", override=False)
    load_dotenv(backend_dir.parent / ".env", override=False)

    # Provide a deterministic default so that local development can run the
    # seeding script without manually exporting SECRET_KEY. Production
    # deployments should still supply their own strong secret via the
    # environment.
    os.environ.setdefault("SECRET_KEY", "dev-secret-key-change-me")


_ensure_environment()

from .database import Base, engine, SessionLocal
from .models import (
    User,
    Workshop,
    UserWorkshop,
    Product,
    UserProduct,
    PaymentMethod,
    Transaction,
    Review,
    SiteSetting,
)
from .auth import get_password_hash


def _reset_sqlite_database() -> None:
    """Remove any existing SQLite database file before reseeding."""

    db_url = engine.url
    if db_url.get_backend_name() != "sqlite":
        return

    database = db_url.database
    if not database or database == ":memory:":
        return

    db_path = Path(database)
    if not db_path.is_absolute():
        db_path = (Path.cwd() / db_path).resolve()

    try:
        if db_path.exists():
            db_path.unlink()
    except OSError as exc:  # pragma: no cover - defensive programming
        raise RuntimeError(f"Unable to remove existing SQLite database at {db_path}: {exc}") from exc


def seed():
    engine.dispose()
    _reset_sqlite_database()
    Base.metadata.create_all(bind=engine)

    with SessionLocal() as db:
        if not db.query(User).filter(User.email == 'admin@example.com').first():
            admin = User(
                name='Admin',
                email='admin@example.com',
                password_hash=get_password_hash('password'),
                is_admin=True,
            )
            db.add(admin)

        user = db.query(User).filter(User.email == 'user@example.com').first()
        if not user:
            user = User(
                name='User',
                email='user@example.com',
                password_hash=get_password_hash('password'),
                is_admin=False,
            )
            db.add(user)
            db.commit()
            db.refresh(user)

        # create sample workshops
        if db.query(Workshop).count() == 0:
            ws1 = Workshop(
                title='Italian Pasta Mastery',
                date=datetime.now(timezone.utc) + timedelta(days=10),
                instructor='Chef Marco',
                location='Culinary Studio A',
                spots=12,
                image='https://images.unsplash.com/photo-1556909114-f6e7ad7d3136',
            )
            ws2 = Workshop(
                title='French Pastry Basics',
                date=datetime.now(timezone.utc) - timedelta(days=30),
                instructor='Chef Sophie',
                location='Culinary Studio B',
                spots=15,
                image='https://images.unsplash.com/photo-1504754524776-8f4f37790ca0',
            )
            db.add_all([ws1, ws2])
            db.commit()
            db.refresh(ws1)
            db.refresh(ws2)
            db.add_all([
                UserWorkshop(user_id=user.id, workshop_id=ws1.id),
                UserWorkshop(user_id=user.id, workshop_id=ws2.id),
            ])

        if db.query(Product).count() == 0:
            p1 = Product(
                name='Professional Chef Knife Set',
                price=299.99,
                image='https://images.unsplash.com/photo-1593618998160-e34014e67546',
                images=json.dumps(['https://images.unsplash.com/photo-1593618998160-e34014e67546']),
                category='Tools',
                description='High-carbon stainless steel chef knife set with ergonomic handles.',
                features=json.dumps([
                    'High-carbon German stainless steel',
                    'Ergonomic handles',
                    'Full tang construction',
                    'Hand-sharpened edge',
                    'Professional grade quality',
                ]),
                specifications=json.dumps({
                    'Blade Length': '8 inches',
                    'Total Length': '13 inches',
                    'Weight': '7.2 oz',
                    'Material': 'High-carbon stainless steel',
                    'Handle': 'Pakkawood',
                }),
                stock_count=8,
            )
            p2 = Product(
                name='Organic Spice Collection',
                price=49.99,
                image='https://images.unsplash.com/photo-1596040033229-a9821ebd058d',
                images=json.dumps(['https://images.unsplash.com/photo-1596040033229-a9821ebd058d']),
                category='Spices',
                description='A curated set of premium organic spices sourced from around the world.',
                features=json.dumps([
                    '12 premium organic spices',
                    'Sourced from local farmers',
                    'No artificial additives',
                    'Elegant glass containers',
                    'Includes recipe booklet',
                ]),
                specifications=json.dumps({
                    'Package Weight': '2.1 lbs',
                    'Dimensions': '12" x 8" x 3"',
                    'Shelf Life': '24 months',
                    'Storage': 'Cool, dry place',
                    'Origin': 'Multiple countries',
                }),
                stock_count=15,
            )
            p3 = Product(
                name='Artisan Pasta Making Kit',
                price=79.99,
                image='https://images.unsplash.com/photo-1621996346565-e3dbc353d2e5',
                images=json.dumps(['https://images.unsplash.com/photo-1621996346565-e3dbc353d2e5']),
                category='Accessories',
                description='Everything you need to craft authentic homemade pasta in one kit.',
                features=json.dumps([
                    'Durable stainless tools',
                    'Wooden pasta board',
                    'Drying rack included',
                    'Recipe booklet',
                    'Storage pouch',
                ]),
                specifications=json.dumps({
                    'Weight': '3 lbs',
                    'Material': 'Wood & steel',
                    'Care': 'Hand wash',
                    'Dimensions': '18" x 12"',
                }),
                stock_count=23,
            )
            db.add_all([p1, p2, p3])
            db.commit()
            db.refresh(p1)
            db.refresh(p2)
            db.refresh(p3)
            db.add_all([
                UserProduct(user_id=user.id, product_id=p1.id),
                UserProduct(user_id=user.id, product_id=p2.id),
                UserProduct(user_id=user.id, product_id=p3.id),
            ])

        if db.query(PaymentMethod).count() == 0:
            pm1 = PaymentMethod(user_id=user.id, brand='Visa', last4='4242', expiry='12/27', is_primary=True, stripe_pm_id='pm_mock_visa')
            pm2 = PaymentMethod(user_id=user.id, brand='Mastercard', last4='1111', expiry='11/26', is_primary=False, stripe_pm_id='pm_mock_mc')
            db.add_all([pm1, pm2])

        if db.query(Transaction).count() == 0:
            db.add_all([
                Transaction(user_id=user.id, type='Workshop', description='Italian Pasta Masterclass', date=datetime.now(timezone.utc) - timedelta(days=5), amount=89.0, status='Paid', method='Credit Card ending in 4242'),
                Transaction(user_id=user.id, type='Product', description='Professional Chef Knife Set', date=datetime.now(timezone.utc) - timedelta(days=20), amount=299.99, status='Paid', method='Credit Card ending in 4242'),
                Transaction(user_id=user.id, type='Workshop', description='French Desserts Workshop', date=datetime.now(timezone.utc) - timedelta(days=25), amount=95.0, status='Pending', method='Credit Card ending in 4242'),
                Transaction(user_id=user.id, type='Product', description='Organic Spice Collection', date=datetime.now(timezone.utc) - timedelta(days=25), amount=49.99, status='Paid', method='PayPal'),
            ])

        if db.query(Review).count() == 0:
            db.add_all([
                Review(user_id=user.id, item_type='Workshop', item_title='Basic Knife Skills Workshop', rating=5, review='Excellent workshop! Chef Marco was very patient and taught us proper knife techniques.', helpful=12, status='approved'),
                Review(user_id=user.id, item_type='Product', item_title='Organic Spice Collection', rating=4, review='Great quality spices with amazing aromas.', helpful=8, status='approved'),
                Review(user_id=user.id, item_type='Workshop', item_title='Pastry Techniques Workshop', rating=5, review='Amazing hands-on experience!', helpful=15, status='approved'),
            ])

        if not db.query(SiteSetting).filter_by(key='homepage').first():
            default_homepage = {
                'hero_title': 'Welcome to Unikcookshop',
                'hero_subtitle': 'Join our culinary workshops and unleash your creativity in the kitchen.',
                'hero_image': 'https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=2070&q=80',
                'inquiry_title': 'Custom Booking Request',
                'inquiry_description': 'Planning a special event or looking for a customized cooking experience? Fill out our inquiry form and our team will help create the perfect culinary adventure for you.',
                'expert_title': 'Expert Chefs at Your Service',
                'expert_description': 'Our professional chefs bring years of culinary expertise to each lesson, ensuring a high-quality learning experience.',
                'workshop_types': [
                    {'id': 1, 'title': 'Group Lessons', 'description': 'Learn in a social environment with other cooking enthusiasts', 'icon': 'Users', 'link': '/workshops?type=group'},
                    {'id': 2, 'title': 'Kids Workshops', 'description': 'Fun cooking classes designed specifically for young chefs', 'icon': 'UserPlus', 'link': '/workshops?type=kids'},
                    {'id': 3, 'title': 'Date Night', 'description': 'Cook a romantic meal together and enjoy a memorable evening', 'icon': 'Heart', 'link': '/workshops?type=date-night'},
                    {'id': 4, 'title': 'Private Sessions', 'description': 'Personalized one-on-one instruction with our skilled chefs', 'icon': 'Calendar', 'link': '/workshops?type=private'},
                    {'id': 5, 'title': 'Team Building', 'description': 'Strengthen workplace bonds through collaborative cooking', 'icon': 'Building2', 'link': '/workshops?type=team-building'},
                    {'id': 6, 'title': 'Cooking Crash Course', 'description': 'Intensive sessions to quickly boost your culinary skills', 'icon': 'Rocket', 'link': '/workshops?type=crash-course'}
                ]
            }
            db.add(SiteSetting(key='homepage', value=json.dumps(default_homepage)))

        db.commit()

if __name__ == '__main__':
    seed()
