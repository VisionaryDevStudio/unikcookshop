"""Helpers for validating Stripe configuration values."""

from __future__ import annotations

import os
import re

_VALID_KEY_RE = re.compile(r"^sk_(test|live)_[A-Za-z0-9]{16,}$")
_PLACEHOLDER_KEYS = {"sk_test", "sk_live"}


def load_stripe_secret_key(env_var: str = "STRIPE_SECRET_KEY") -> str:
    """Return a sanitized Stripe secret key or raise a configuration error.

    The production application should never attempt to talk to Stripe with a
    redacted value (for example ``sk_test_*****``). When the environment
    variable contains masked characters we raise a ``RuntimeError`` with a
    descriptive message so the operator can fix their configuration instead of
    encountering a late ``stripe.error.AuthenticationError`` during checkout.

    The test-suite still relies on the bare ``sk_test`` placeholder to avoid
    real network calls, so we explicitly allow that value.
    """

    raw = os.getenv(env_var)
    if raw is None:
        raise RuntimeError(f"{env_var} environment variable not set")

    key = raw.strip()
    if not key:
        raise RuntimeError(f"{env_var} environment variable not set")

    if key in _PLACEHOLDER_KEYS:
        return key

    if "*" in key or "…" in key or "..." in key:
        raise RuntimeError(
            f"{env_var} appears to be masked. Provide the full Stripe secret key."
        )

    if not _VALID_KEY_RE.match(key):
        raise RuntimeError(
            f"{env_var} value '{key}' does not look like a Stripe secret key."
        )

    return key

