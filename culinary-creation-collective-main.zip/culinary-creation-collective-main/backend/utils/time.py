from datetime import datetime, timezone


def to_utc(dt: datetime) -> datetime:
    """Return ``dt`` converted to UTC.

    If ``dt`` is naive, it is assumed to already be UTC and tzinfo is set
    accordingly. A timezone-aware ``dt`` is converted to UTC.
    """
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)
