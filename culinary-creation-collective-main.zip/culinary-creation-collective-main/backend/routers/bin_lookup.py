from fastapi import APIRouter, HTTPException, Request, Depends
from sqlalchemy.orm import Session
import httpx

from ..database import get_db
from ..rate_limiter import _check_rate_limit

router = APIRouter(prefix="/bin", tags=["bin"])


@router.get("/{bin_prefix}")
async def lookup_bin(
    bin_prefix: str,
    request: Request,
    db: Session = Depends(get_db),
):
    _check_rate_limit(db, f"bin:{request.client.host}", limit=10)
    if not bin_prefix.isdigit() or len(bin_prefix) not in (6, 7, 8):
        raise HTTPException(status_code=400, detail="Invalid BIN")
    url = f"https://lookup.binlist.net/{bin_prefix}"
    async with httpx.AsyncClient(timeout=5.0) as client:
        resp = await client.get(url)
    if resp.status_code != 200:
        raise HTTPException(status_code=502, detail="BIN lookup failed")
    data = resp.json()
    return {
        "scheme": data.get("scheme"),
        "brand": data.get("brand"),
        "issuer": data.get("bank", {}).get("name"),
        "country": data.get("country", {}).get("alpha2"),
    }
