import os
import stripe
from fastapi import APIRouter, Request, HTTPException, Depends
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import get_db
from .. import models
from ..logger import logger
from ..services import payments

STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET")
if not STRIPE_WEBHOOK_SECRET:
    raise RuntimeError("STRIPE_WEBHOOK_SECRET not set")

STRIPE_ACCOUNT_ID = os.getenv("STRIPE_ACCOUNT_ID")
if not STRIPE_ACCOUNT_ID:
    raise RuntimeError("STRIPE_ACCOUNT_ID not set")

STRIPE_LIVE_MODE = os.getenv("STRIPE_LIVE_MODE")
if STRIPE_LIVE_MODE is None:
    raise RuntimeError("STRIPE_LIVE_MODE not set")
EXPECTED_LIVE_MODE = STRIPE_LIVE_MODE.lower() in ("1", "true", "t", "yes")

router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])




@router.post("/stripe", status_code=200)
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    """Receive and handle Stripe webhook events.

    Verifies the event using the STRIPE_WEBHOOK_SECRET and updates transaction
    statuses when payments succeed.
    """
    payload = await request.body()
    sig_header = request.headers.get("Stripe-Signature")

    try:
        event = stripe.Webhook.construct_event(
            payload=payload.decode(),
            sig_header=sig_header,
            secret=STRIPE_WEBHOOK_SECRET,
        )
    except (ValueError, stripe.error.SignatureVerificationError):
        raise HTTPException(status_code=400, detail="Invalid payload or signature")

    event_id = event["id"]
    if event["livemode"] != EXPECTED_LIVE_MODE or event.get("account") != STRIPE_ACCOUNT_ID:
        logger.warning(
            "Rejecting Stripe event %s: livemode/account mismatch (%s/%s vs %s/%s)",
            event_id,
            event.get("livemode"),
            event.get("account"),
            EXPECTED_LIVE_MODE,
            STRIPE_ACCOUNT_ID,
        )
        raise HTTPException(status_code=400, detail="Account mismatch")

    if db.query(models.ProcessedEvent).filter(models.ProcessedEvent.id == event_id).first():
        return {"status": "ok"}

    queued_for_reconciliation = False

    try:
        if event["type"] == "payment_intent.succeeded":
            intent = event["data"]["object"]
            payment_intent_id = intent.get("id")
            customer_id = intent.get("customer")
            metadata_user_id = (intent.get("metadata") or {}).get("user_id")
            txs = (
                db.query(models.Transaction)
                .filter(models.Transaction.payment_intent_id == payment_intent_id)
                .all()
            )
            if not txs:
                logger.warning(
                    "No transactions found for payment intent %s", payment_intent_id
                )
                payments.persist_unmatched_payment_intent_event(db, event)
                queued_for_reconciliation = True
            else:
                payments.verify_user(txs, customer_id, metadata_user_id)
                payments.verify_amount_currency(
                    txs,
                    intent.get("amount_received"),
                    intent.get("currency"),
                    event_id,
                    intent,
                )
                for tx in txs:
                    tx.status = "Paid"
        elif event["type"] == "payment_intent.processing":
            intent = event["data"]["object"]
            payment_intent_id = intent.get("id")
            customer_id = intent.get("customer")
            metadata_user_id = (intent.get("metadata") or {}).get("user_id")
            txs = (
                db.query(models.Transaction)
                .filter(models.Transaction.payment_intent_id == payment_intent_id)
                .all()
            )
            if not txs:
                logger.warning(
                    "No transactions found for payment intent %s", payment_intent_id
                )
                payments.persist_unmatched_payment_intent_event(db, event)
                queued_for_reconciliation = True
            else:
                payments.verify_user(txs, customer_id, metadata_user_id)
                payments.verify_amount_currency(
                    txs,
                    intent.get("amount"),
                    intent.get("currency"),
                    event_id,
                    intent,
                )
                for tx in txs:
                    tx.status = "Processing"
        elif event["type"] == "payment_intent.payment_failed":
            intent = event["data"]["object"]
            payment_intent_id = intent.get("id")
            customer_id = intent.get("customer")
            metadata_user_id = (intent.get("metadata") or {}).get("user_id")
            txs = (
                db.query(models.Transaction)
                .filter(models.Transaction.payment_intent_id == payment_intent_id)
                .all()
            )
            if not txs:
                logger.warning(
                    "No transactions found for payment intent %s", payment_intent_id
                )
                payments.persist_unmatched_payment_intent_event(db, event)
                queued_for_reconciliation = True
            else:
                payments.verify_user(txs, customer_id, metadata_user_id)
                payments.verify_amount_currency(
                    txs,
                    intent.get("amount"),
                    intent.get("currency"),
                    event_id,
                    intent,
                )
                for tx in txs:
                    tx.status = "Failed"
        elif event["type"] == "charge.refunded":
            charge = event["data"]["object"]
            payment_intent_id = charge.get("payment_intent")
            customer_id = charge.get("customer")
            metadata_user_id = (charge.get("metadata") or {}).get("user_id")
            txs = (
                db.query(models.Transaction)
                .filter(models.Transaction.payment_intent_id == payment_intent_id)
                .all()
            )
            if not txs:
                logger.warning(
                    "No transactions found for payment intent %s", payment_intent_id
                )
                return {"status": "ok"}
            payments.verify_user(txs, customer_id, metadata_user_id)
            payments.verify_amount_currency(
                txs,
                charge.get("amount"),
                charge.get("currency"),
                event_id,
                charge,
            )
            for tx in txs:
                tx.status = "Refunded"
        elif event["type"] == "payment_intent.canceled":
            intent = event["data"]["object"]
            payment_intent_id = intent.get("id")
            customer_id = intent.get("customer")
            metadata_user_id = (intent.get("metadata") or {}).get("user_id")
            txs = (
                db.query(models.Transaction)
                .filter(models.Transaction.payment_intent_id == payment_intent_id)
                .all()
            )
            if not txs:
                logger.warning(
                    "No transactions found for payment intent %s", payment_intent_id
                )
                return {"status": "ok"}
            payments.verify_user(txs, customer_id, metadata_user_id)
            payments.verify_amount_currency(
                txs,
                intent.get("amount"),
                intent.get("currency"),
                event_id,
                intent,
            )
            for tx in txs:
                tx.status = "Canceled"
        elif event["type"].startswith("charge.dispute"):
            dispute = event["data"]["object"]
            payment_intent_id = dispute.get("payment_intent")
            customer_id = dispute.get("customer")
            metadata_user_id = (dispute.get("metadata") or {}).get("user_id")
            txs = (
                db.query(models.Transaction)
                .filter(models.Transaction.payment_intent_id == payment_intent_id)
                .all()
            )
            if not txs:
                logger.warning(
                    "No transactions found for payment intent %s", payment_intent_id
                )
                return {"status": "ok"}
            payments.verify_user(txs, customer_id, metadata_user_id)
            payments.verify_amount_currency(
                txs,
                dispute.get("amount"),
                dispute.get("currency"),
                event_id,
                dispute,
            )
            if event["type"] == "charge.dispute.closed":
                status = "Paid" if dispute.get("status") == "won" else "Dispute Lost"
            elif event["type"] == "charge.dispute.funds_reinstated":
                status = "Paid"
            else:
                status = "Disputed"
            for tx in txs:
                tx.status = status
        else:
            logger.warning("Unhandled Stripe event type %s", event["type"])

        db.add(models.ProcessedEvent(id=event_id))
        db.commit()
    except IntegrityError:
        db.rollback()
        return {"status": "ok"}
    except HTTPException:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        logger.exception("Failed to process Stripe event %s", event["type"])
        raise HTTPException(status_code=400, detail="Webhook handling failed")

    if queued_for_reconciliation:
        payments.schedule_reconciliation()

    return {"status": "ok"}
