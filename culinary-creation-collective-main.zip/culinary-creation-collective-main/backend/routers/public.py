from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, timezone

from ..utils.time import to_utc
import json

from .. import models, schemas
from ..database import get_db

router = APIRouter(prefix="/api/public", tags=["public"])

@router.get("/products", response_model=list[schemas.ProductOut])
def list_products(db: Session = Depends(get_db)):
    products = db.query(models.Product).all()
    result = []
    for p in products:
        reviews = (
            db.query(models.Review)
            .filter(
                models.Review.item_type == "Product",
                models.Review.item_title == p.name,
                models.Review.status == "approved",
            )
            .all()
        )
        if reviews:
            rating = sum(r.rating for r in reviews) / len(reviews)
        else:
            rating = None
        result.append(
            schemas.ProductOut(
                id=p.id,
                name=p.name,
                price=p.price,
                image=p.image,
                images=json.loads(p.images) if p.images else [],
                category=p.category,
                description=p.description,
                features=json.loads(p.features) if p.features else [],
                specifications=json.loads(p.specifications) if p.specifications else {},
                stock_count=p.stock_count,
                rating=rating,
                review_count=len(reviews),
            )
        )
    return result


@router.get("/products/{product_id}", response_model=schemas.ProductOut)
def get_product(product_id: int, db: Session = Depends(get_db)):
    product = db.get(models.Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    reviews = (
        db.query(models.Review)
        .filter(
            models.Review.item_type == "Product",
            models.Review.item_title == product.name,
            models.Review.status == "approved",
        )
        .all()
    )
    rating = sum(r.rating for r in reviews) / len(reviews) if reviews else None
    return schemas.ProductOut(
        id=product.id,
        name=product.name,
        price=product.price,
        image=product.image,
        images=json.loads(product.images) if product.images else [],
        category=product.category,
        description=product.description,
        features=json.loads(product.features) if product.features else [],
        specifications=json.loads(product.specifications) if product.specifications else {},
        stock_count=product.stock_count,
        rating=rating,
        review_count=len(reviews),
    )


@router.get("/products/{product_id}/reviews", response_model=list[schemas.ReviewOut])
def product_reviews(product_id: int, db: Session = Depends(get_db)):
    product = db.get(models.Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    reviews = (
        db.query(models.Review)
        .filter(
            models.Review.item_type == "Product",
            models.Review.item_title == product.name,
            models.Review.status == "approved",
        )
        .all()
    )
    for r in reviews:
        r.date = to_utc(r.date)
    return reviews


@router.get("/reviews", response_model=list[schemas.ReviewOut])
def list_reviews(db: Session = Depends(get_db)):
    reviews = db.query(models.Review).filter(models.Review.status == "approved").all()
    for r in reviews:
        r.date = to_utc(r.date)
    return reviews

@router.get("/workshops", response_model=list[schemas.WorkshopOut])
def list_workshops(db: Session = Depends(get_db)):
    workshops = db.query(models.Workshop).all()
    for w in workshops:
        if w.seasonal_ingredients:
            w.seasonal_ingredients = json.loads(w.seasonal_ingredients)
        if w.learning_outcomes:
            w.learning_outcomes = json.loads(w.learning_outcomes)
        w.date = to_utc(w.date)
    return workshops


@router.get("/workshops/upcoming", response_model=list[schemas.WorkshopOut])
def list_upcoming_workshops(db: Session = Depends(get_db)):
    workshops = (
        db.query(models.Workshop)
        .filter(models.Workshop.date >= datetime.now(timezone.utc))
        .order_by(models.Workshop.date.asc())
        .all()
    )
    for w in workshops:
        w.date = to_utc(w.date)
        if w.seasonal_ingredients:
            w.seasonal_ingredients = json.loads(w.seasonal_ingredients)
        if w.learning_outcomes:
            w.learning_outcomes = json.loads(w.learning_outcomes)
    return workshops


@router.get("/workshops/{workshop_id}", response_model=schemas.WorkshopOut)
def get_workshop(workshop_id: int, db: Session = Depends(get_db)):
    workshop = db.get(models.Workshop, workshop_id)
    if not workshop:
        raise HTTPException(status_code=404, detail="Workshop not found")
    if workshop.seasonal_ingredients:
        workshop.seasonal_ingredients = json.loads(workshop.seasonal_ingredients)
    if workshop.learning_outcomes:
        workshop.learning_outcomes = json.loads(workshop.learning_outcomes)
    workshop.date = to_utc(workshop.date)
    return workshop

@router.post("/inquiries", response_model=schemas.InquiryOut)
def create_inquiry(inquiry: schemas.InquiryCreate, db: Session = Depends(get_db)):
    new_inquiry = models.Inquiry(status="pending", **inquiry.model_dump())
    db.add(new_inquiry)
    db.commit()
    db.refresh(new_inquiry)
    new_inquiry.created_at = to_utc(new_inquiry.created_at)
    return new_inquiry


@router.get("/site-settings", response_model=dict[str, str])
def site_settings(db: Session = Depends(get_db)):
    settings = db.query(models.SiteSetting).all()
    return {s.key: s.value for s in settings}

