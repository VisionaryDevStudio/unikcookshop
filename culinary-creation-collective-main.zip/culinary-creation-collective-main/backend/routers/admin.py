from fastapi import APIRouter, Depends, HTTPException, Response, UploadFile, File
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime, timezone, timedelta
import shutil
import uuid
import os
import json
from pathlib import Path

from ..auth import admin_required, get_password_hash
from .. import schemas, models
from ..database import get_db
from ..utils.time import to_utc

router = APIRouter(prefix="/api/admin", tags=["admin"])

@router.get("/stats", response_model=schemas.StatsOut)
def get_stats(
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    users_count = db.query(models.User).count()
    orders_count = db.query(models.Transaction).count()
    revenue = db.query(func.sum(models.Transaction.amount)).scalar() or 0.0
    now = datetime.now(timezone.utc)
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    if now.month == 12:
        next_month = month_start.replace(year=now.year + 1, month=1)
    else:
        next_month = month_start.replace(month=now.month + 1)
    orders_this_month = (
        db.query(models.Transaction)
        .filter(models.Transaction.date >= month_start)
        .filter(models.Transaction.date < next_month)
        .count()
    )
    revenue_this_month = (
        db.query(func.sum(models.Transaction.amount))
        .filter(models.Transaction.date >= month_start)
        .filter(models.Transaction.date < next_month)
        .scalar()
        or 0.0
    )
    prev_month_start = (month_start - timedelta(days=1)).replace(day=1)
    revenue_prev_month = (
        db.query(func.sum(models.Transaction.amount))
        .filter(models.Transaction.date >= prev_month_start)
        .filter(models.Transaction.date < month_start)
        .scalar()
        or 0.0
    )
    monthly_growth = (
        ((revenue_this_month - revenue_prev_month) / revenue_prev_month) * 100
        if revenue_prev_month
        else 0.0
    )
    active_workshops = (
        db.query(models.Workshop)
        .filter(models.Workshop.date > datetime.now(timezone.utc))
        .count()
    )

    tp_query = (
        db.query(models.Product, func.count(models.UserProduct.id).label("sales"))
        .outerjoin(models.UserProduct, models.Product.id == models.UserProduct.product_id)
        .group_by(models.Product.id)
        .order_by(func.count(models.UserProduct.id).desc())
        .limit(3)
        .all()
    )
    top_products = [
        {
            "name": prod.name,
            "sales": int(sales),
            "revenue": float(prod.price * sales),
        }
        for prod, sales in tp_query
    ]

    def human_delta(dt: datetime) -> str:
        dt = to_utc(dt)
        delta = datetime.now(timezone.utc) - dt
        if delta.days > 0:
            return f"{delta.days}d ago"
        hours = delta.seconds // 3600
        if hours:
            return f"{hours}h ago"
        minutes = delta.seconds // 60
        return f"{minutes}m ago"

    recent = (
        db.query(models.Transaction)
        .order_by(models.Transaction.date.desc())
        .limit(5)
        .all()
    )
    recent_activity = [
        {"description": t.description, "time": human_delta(t.date)} for t in recent
    ]

    return {
        "users": users_count,
        "orders": orders_count,
        "revenue": revenue,
        "active_workshops": active_workshops,
        "top_products": top_products,
        "recent_activity": recent_activity,
        "orders_this_month": orders_this_month,
        "monthly_growth": monthly_growth,
    }


@router.post("/create", response_model=schemas.UserOut)
def create_admin(
    new_admin: schemas.AdminCreate,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    existing = db.query(models.User).filter(models.User.email == new_admin.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed = get_password_hash(new_admin.password)
    user = models.User(
        name=new_admin.name,
        email=new_admin.email,
        password_hash=hashed,
        is_admin=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.get("/users", response_model=list[schemas.UserOut])
def list_users(
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    users = db.query(models.User).all()
    result = []
    for u in users:
        total_spent = sum(t.amount for t in u.transactions)
        workshops_attended = len(u.workshops)
        user_out = schemas.UserOut.model_validate(u)
        user_out.total_spent = float(total_spent)
        user_out.workshops_attended = workshops_attended
        user_out.status = "active"
        result.append(user_out)
    return result


@router.get("/users/{user_id}", response_model=schemas.UserOut)
def get_user(
    user_id: int,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    user = db.get(models.User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.put("/users/{user_id}", response_model=schemas.UserOut)
def update_user(
    user_id: int,
    update: schemas.UserUpdate,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    user = db.get(models.User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    data = update.model_dump(exclude_unset=True)
    for key, value in data.items():
        setattr(user, key, value)
    db.commit()
    db.refresh(user)
    return user


@router.get("/products", response_model=list[schemas.ProductAdminOut])
def list_products(
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    products = db.query(models.Product).all()
    sales_counts = dict(
        db.query(models.UserProduct.product_id, func.count(models.UserProduct.id))
        .group_by(models.UserProduct.product_id)
        .all()
    )
    result = []
    for p in products:
        sold = sales_counts.get(p.id, 0)
        result.append(
            schemas.ProductAdminOut(
                id=p.id,
                name=p.name,
                price=p.price,
                image=p.image,
                images=json.loads(p.images) if p.images else [],
                category=p.category,
                description=p.description,
                features=json.loads(p.features) if p.features else [],
                specifications=json.loads(p.specifications) if p.specifications else {},
                stock=p.stock_count,
                sold=sold,
                rating=None,
                review_count=0,
            )
        )
    return result


@router.post("/products", response_model=schemas.ProductOut)
def create_product(
    product: schemas.ProductCreate,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    data = product.model_dump(exclude_unset=True)
    if data.get('features') is not None:
        data['features'] = json.dumps(data['features'])
    if data.get('specifications') is not None:
        data['specifications'] = json.dumps(data['specifications'])
    if data.get('images') is not None:
        data['images'] = json.dumps(data['images'])
    p = models.Product(**data)
    db.add(p)
    db.commit()
    db.refresh(p)
    return schemas.ProductOut(
        id=p.id,
        name=p.name,
        price=p.price,
        image=p.image,
        images=json.loads(p.images) if p.images else [],
        category=p.category,
        description=p.description,
        features=json.loads(p.features) if p.features else [],
        specifications=json.loads(p.specifications) if p.specifications else {},
        stock_count=p.stock_count,
        rating=None,
        review_count=0,
    )


@router.post("/upload-image", response_model=schemas.ImageUploadOut)
def upload_image(
    file: UploadFile = File(...),
    current_user=Depends(admin_required),
):
    data = file.file.read(16)
    file.file.seek(0)
    ext = os.path.splitext(file.filename)[1].lower()
    allowed_exts = {".jpg", ".jpeg", ".png", ".webp"}

    def is_valid(data: bytes, ext: str) -> bool:
        if ext in {".jpg", ".jpeg"}:
            return data.startswith(b"\xff\xd8\xff")
        if ext == ".png":
            return data.startswith(b"\x89PNG\r\n\x1a\n")
        if ext == ".webp":
            return len(data) >= 12 and data.startswith(b"RIFF") and data[8:12] == b"WEBP"
        return False

    if ext not in allowed_exts or not is_valid(data, ext):
        raise HTTPException(status_code=400, detail="Invalid file type")
    uploads_dir = Path(__file__).resolve().parents[2] / "public" / "lovable-uploads"
    uploads_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{uuid.uuid4()}{ext}"
    file_path = uploads_dir / filename
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return {"path": f"/lovable-uploads/{filename}"}


@router.put("/products/{product_id}", response_model=schemas.ProductOut)
def update_product(
    product_id: int,
    update: schemas.ProductCreate,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    product = db.get(models.Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    data = update.model_dump(exclude_unset=True)
    if data.get('features') is not None:
        data['features'] = json.dumps(data['features'])
    if data.get('specifications') is not None:
        data['specifications'] = json.dumps(data['specifications'])
    if data.get('images') is not None:
        data['images'] = json.dumps(data['images'])
    for key, value in data.items():
        setattr(product, key, value)
    db.commit()
    db.refresh(product)
    return schemas.ProductOut(
        id=product.id,
        name=product.name,
        price=product.price,
        image=product.image,
        images=json.loads(product.images) if product.images else [],
        category=product.category,
        description=product.description,
        features=json.loads(product.features) if product.features else [],
        specifications=json.loads(product.specifications) if product.specifications else {},
        stock_count=product.stock_count,
        rating=None,
        review_count=0,
    )


@router.delete("/products/{product_id}", status_code=204)
def delete_product(
    product_id: int,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    product = db.get(models.Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    db.query(models.UserProduct).filter_by(product_id=product_id).delete()
    db.delete(product)
    db.commit()
    return Response(status_code=204)


@router.get("/workshops", response_model=list[schemas.WorkshopOut])
def list_workshops(
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    workshops = db.query(models.Workshop).all()
    for w in workshops:
        w.date = to_utc(w.date)
        if w.seasonal_ingredients:
            w.seasonal_ingredients = json.loads(w.seasonal_ingredients)
        if w.learning_outcomes:
            w.learning_outcomes = json.loads(w.learning_outcomes)
        w.capacity = w.spots
        w.enrolled = len(w.attendees)
        w.status = "upcoming" if w.date > datetime.now(timezone.utc) else "completed"
    return workshops


@router.post("/workshops", response_model=schemas.WorkshopOut)
def create_workshop(
    workshop: schemas.WorkshopCreate,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    data = workshop.model_dump(exclude_unset=True)
    if data.get('date') is not None:
        raw_date = data['date']
        parsed = datetime.fromisoformat(
            raw_date if isinstance(raw_date, str) else raw_date.isoformat()
        )
        parsed = to_utc(parsed)
        data['date'] = parsed
    if data.get('seasonal_ingredients') is not None:
        data['seasonal_ingredients'] = json.dumps(data['seasonal_ingredients'])
    if data.get('learning_outcomes') is not None:
        data['learning_outcomes'] = json.dumps(data['learning_outcomes'])
    w = models.Workshop(**data)
    db.add(w)
    db.commit()
    db.refresh(w)
    w.date = to_utc(w.date)
    if w.seasonal_ingredients:
        w.seasonal_ingredients = json.loads(w.seasonal_ingredients)
    if w.learning_outcomes:
        w.learning_outcomes = json.loads(w.learning_outcomes)
    w.capacity = w.spots
    w.enrolled = len(w.attendees)
    w.status = "upcoming" if w.date > datetime.now(timezone.utc) else "completed"
    return w


@router.put("/workshops/{workshop_id}", response_model=schemas.WorkshopOut)
def update_workshop(
    workshop_id: int,
    update: schemas.WorkshopCreate,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    workshop = db.get(models.Workshop, workshop_id)
    if not workshop:
        raise HTTPException(status_code=404, detail="Workshop not found")
    data = update.model_dump(exclude_unset=True)
    if data.get('date') is not None:
        raw_date = data['date']
        parsed = datetime.fromisoformat(
            raw_date if isinstance(raw_date, str) else raw_date.isoformat()
        )
        parsed = to_utc(parsed)
        data['date'] = parsed
    if data.get('seasonal_ingredients') is not None:
        data['seasonal_ingredients'] = json.dumps(data['seasonal_ingredients'])
    if data.get('learning_outcomes') is not None:
        data['learning_outcomes'] = json.dumps(data['learning_outcomes'])
    for key, value in data.items():
        setattr(workshop, key, value)
    db.commit()
    db.refresh(workshop)
    workshop.date = to_utc(workshop.date)
    if workshop.seasonal_ingredients:
        workshop.seasonal_ingredients = json.loads(workshop.seasonal_ingredients)
    if workshop.learning_outcomes:
        workshop.learning_outcomes = json.loads(workshop.learning_outcomes)
    workshop.capacity = workshop.spots
    workshop.enrolled = len(workshop.attendees)
    workshop.status = (
        "upcoming" if workshop.date > datetime.now(timezone.utc) else "completed"
    )
    return workshop


@router.delete("/workshops/{workshop_id}", status_code=204)
def delete_workshop(
    workshop_id: int,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    workshop = db.get(models.Workshop, workshop_id)
    if not workshop:
        raise HTTPException(status_code=404, detail="Workshop not found")
    db.query(models.UserWorkshop).filter_by(workshop_id=workshop_id).delete()
    db.delete(workshop)
    db.commit()
    return Response(status_code=204)


@router.get("/orders", response_model=list[schemas.TransactionOut])
def list_orders(
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    orders = db.query(models.Transaction).all()
    result: list[schemas.TransactionOut] = []
    for o in orders:
        result.append(
            schemas.TransactionOut(
                id=o.id,
                type=o.type.lower(),
                description=o.description,
                date=o.date,
                amount=o.amount,
                status=o.status,
                method=o.method,
                workshop_date=o.workshop_date,
            )
        )
    return result


@router.get("/orders/export")
def export_orders(
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    orders = db.query(models.Transaction).all()
    import csv
    import io

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id", "user_id", "type", "description", "date", "amount", "status", "method"])
    for o in orders:
        writer.writerow([
            o.id,
            o.user_id,
            o.type,
            o.description,
            o.date.isoformat(),
            o.amount,
            o.status,
            o.method,
        ])
    return Response(
        content=output.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=orders.csv"},
    )


@router.get("/orders/{order_id}", response_model=schemas.TransactionOut)
def get_order(
    order_id: int,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    order = db.get(models.Transaction, order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


@router.put("/orders/{order_id}/status", response_model=schemas.TransactionOut)
def update_order_status(
    order_id: int,
    update: schemas.OrderStatusUpdate,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    order = db.get(models.Transaction, order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    order.status = update.status
    db.commit()
    db.refresh(order)
    return order


@router.get("/reviews", response_model=list[schemas.ReviewOut])
def list_reviews(
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    reviews = db.query(models.Review).all()
    for r in reviews:
        if r.item_type == "Product":
            purchased = (
                db.query(models.UserProduct)
                .join(models.Product, models.UserProduct.product_id == models.Product.id)
                .filter(models.UserProduct.user_id == r.user_id)
                .filter(models.Product.name == r.item_title)
                .first()
            )
            is_verified = purchased is not None
        elif r.item_type == "Workshop":
            attended = (
                db.query(models.UserWorkshop)
                .join(models.Workshop, models.UserWorkshop.workshop_id == models.Workshop.id)
                .filter(models.UserWorkshop.user_id == r.user_id)
                .filter(models.Workshop.title == r.item_title)
                .first()
            )
            is_verified = attended is not None
        else:
            is_verified = False
        r.verified_purchase = is_verified
        r.verified = is_verified
    return reviews


@router.put("/reviews/{review_id}/status", response_model=schemas.ReviewOut)
def update_review_status(
    review_id: int,
    update: schemas.ReviewStatusUpdate,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    review = db.get(models.Review, review_id)
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    review.status = update.status
    db.commit()
    db.refresh(review)
    return review


@router.get("/inquiries", response_model=list[schemas.InquiryOut])
def list_inquiries(
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    return db.query(models.Inquiry).order_by(models.Inquiry.created_at.desc()).all()


@router.put("/inquiries/{inquiry_id}/status", response_model=schemas.InquiryOut)
def update_inquiry_status(
    inquiry_id: int,
    update: schemas.InquiryStatusUpdate,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    inquiry = db.get(models.Inquiry, inquiry_id)
    if not inquiry:
        raise HTTPException(status_code=404, detail="Inquiry not found")
    inquiry.status = update.status
    db.commit()
    db.refresh(inquiry)
    inquiry.created_at = to_utc(inquiry.created_at)
    return inquiry


@router.get("/site-settings", response_model=dict[str, str])
def get_site_settings(
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    settings = db.query(models.SiteSetting).all()
    return {s.key: s.value for s in settings}


@router.put("/site-settings/{key}", response_model=schemas.SiteSettingOut)
def update_site_setting(
    key: str,
    update: schemas.SiteSettingUpdate,
    current_user=Depends(admin_required),
    db: Session = Depends(get_db),
):
    setting = db.query(models.SiteSetting).filter_by(key=key).first()
    if not setting:
        setting = models.SiteSetting(key=key, value=update.value)
        db.add(setting)
    else:
        setting.value = update.value
    db.commit()
    db.refresh(setting)
    return setting

