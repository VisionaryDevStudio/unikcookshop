from fastapi import APIRouter, Depends, HTTPException, status, Body, Request
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from sqlalchemy import select
from datetime import datetime, timezone
from decimal import Decimal
import stripe
import hashlib
import json
import re
import traceback
from urllib.parse import quote

from typing import Any, Optional, Annotated

from ..database import get_db
from ..auth import get_current_user
from .. import models, schemas
from ..logger import logger
from ..rate_limiter import _check_rate_limit
from ..csrf import validate_csrf_token
from ..utils.time import to_utc

from ..utils.stripe_config import load_stripe_secret_key

stripe.api_key = load_stripe_secret_key()

router = APIRouter(
    prefix="/api/cart", tags=["cart"], dependencies=[Depends(validate_csrf_token)]
)


_CARD_RE = re.compile(r"\b(\d{4})\d{8,11}(\d{4})\b")
_CLIENT_SECRET_RE = re.compile(r"""(client_secret['"=:\s]*)([^'"\s]+)""")


def _sanitize_stripe_exception(exc: Exception) -> str:
    """Return a stack trace string with sensitive fields stripped."""
    text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    text = _CLIENT_SECRET_RE.sub(r"\1***", text)
    text = re.sub(r'("number"\s*:\s*)"[^"]+"', r'\1"***"', text)
    text = re.sub(r'("cvc"\s*:\s*)"[^"]+"', r'\1"***"', text)
    text = _CARD_RE.sub(lambda m: f"{m.group(1)}****{m.group(2)}", text)
    return text


def _handle_stripe_error(
    exc: Exception, log_message: str, default_detail: str, *, user_id: int | None = None
) -> None:
    """Translate Stripe errors into HTTP exceptions with user messages."""
    if user_id is not None:
        log_message = log_message.replace(str(user_id), _mask_user_id(user_id))
    logger.error("%s\n%s", log_message, _sanitize_stripe_exception(exc))
    if isinstance(exc, stripe.error.CardError):
        detail = getattr(exc, "user_message", None) or "Your card was declined"
        status_code = status.HTTP_402_PAYMENT_REQUIRED
    elif isinstance(exc, stripe.error.RateLimitError):
        detail = "Too many requests to payment processor. Please try again later."
        status_code = status.HTTP_429_TOO_MANY_REQUESTS
    elif isinstance(exc, stripe.error.InvalidRequestError):
        detail = "Invalid payment information."
        status_code = status.HTTP_400_BAD_REQUEST
    elif isinstance(exc, stripe.error.AuthenticationError):
        detail = "Payment processor authentication failed."
        status_code = status.HTTP_502_BAD_GATEWAY
    elif isinstance(exc, stripe.error.APIConnectionError):
        detail = "Network communication with payment processor failed."
        status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    elif isinstance(exc, stripe.error.StripeError):
        detail = "Payment processor error."
        status_code = status.HTTP_502_BAD_GATEWAY
    else:
        detail = default_detail
        status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    raise HTTPException(status_code=status_code, detail=detail)

def _mask_user_id(user_id: int) -> str:
    """Return a hashed representation of a user id for safe logging."""
    return hashlib.sha256(str(user_id).encode()).hexdigest()[:8]


def build_pi_search_query(user_id: Any, cart_fp: str) -> str:
    """Percent-encode identifiers for a Stripe PaymentIntent search query."""
    encoded_user_id = quote(str(user_id), safe="")
    encoded_cart_fp = quote(str(cart_fp), safe="")
    return (
        f'metadata["user_id"]:"{encoded_user_id}" '
        f'AND metadata["cart_fp"]:"{encoded_cart_fp}"'
    )


def _get_or_create_customer(db: Session, user: models.User) -> str:
    """Return the user's Stripe customer id, creating one if needed."""
    if user.stripe_customer_id:
        return user.stripe_customer_id
    try:
        # Lock the user row to prevent concurrent customer creation
        db.execute(
            select(models.User).where(models.User.id == user.id).with_for_update()
        )
        db.refresh(user)
        if user.stripe_customer_id:
            return user.stripe_customer_id

        customer_params = {"email": user.email}
        if user.name:
            customer_params["name"] = user.name

        try:
            customer = stripe.Customer.create(**customer_params)
        except stripe.error.StripeError as e:
            _handle_stripe_error(
                e,
                f"Failed to create Stripe customer for user {user.id}",
                "Unable to create customer",
                user_id=user.id,
            )

        user.stripe_customer_id = customer.id
        db.add(user)
        db.commit()
        db.refresh(user)
        return user.stripe_customer_id
    except IntegrityError:
        db.rollback()
        existing = (
            db.query(models.User)
            .filter(models.User.id == user.id)
            .first()
        )
        if existing and existing.stripe_customer_id:
            return existing.stripe_customer_id
        logger.exception(
            "Failed to create Stripe customer for user %s", _mask_user_id(user.id)
        )
        raise HTTPException(status_code=400, detail="Unable to create customer")
    except Exception as e:
        if isinstance(e, HTTPException):
            raise
        db.rollback()
        logger.exception(
            "Failed to create Stripe customer for user %s", _mask_user_id(user.id)
        )
        raise HTTPException(status_code=400, detail="Unable to create customer")


def _normalize_scheduled_at(raw: datetime | str | None) -> datetime | None:
    if raw is None:
        return None
    parsed = datetime.fromisoformat(raw if isinstance(raw, str) else raw.isoformat())
    return to_utc(parsed)


def _item_out(item: models.CartItem) -> schemas.CartItemOut:
    scheduled = item.scheduled_at
    if scheduled:
        scheduled_str = to_utc(scheduled).isoformat()
    else:
        scheduled_str = None
    return schemas.CartItemOut(
        id=item.id,
        item_id=item.item_id,
        name=item.name,
        price=item.price,
        category=item.category,
        image=item.image,
        quantity=item.quantity,
        type=item.type,
        scheduled_at=scheduled_str,
    )


@router.get("", response_model=list[schemas.CartItemOut])
def get_cart(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    items = (
        db.query(models.CartItem)
        .filter(models.CartItem.user_id == current_user.id)
        .all()
    )
    return [_item_out(i) for i in items]


@router.post("/items", response_model=schemas.CartItemOut)
def add_item(
    data: schemas.CartItemCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    scheduled_at = _normalize_scheduled_at(data.scheduled_at)
    item = (
        db.query(models.CartItem)
        .filter(
            models.CartItem.user_id == current_user.id,
            models.CartItem.item_id == data.item_id,
            models.CartItem.type == data.type,
            models.CartItem.scheduled_at == scheduled_at,
        )
        .first()
    )
    if item:
        item.quantity += data.quantity
    else:
        payload = data.model_dump(exclude={"scheduled_at"})
        item = models.CartItem(
            user_id=current_user.id, scheduled_at=scheduled_at, **payload
        )
        db.add(item)
    db.commit()
    db.refresh(item)
    return _item_out(item)


@router.put("/items/{item_id}", response_model=schemas.CartItemOut)
def update_item(
    item_id: int,
    data: schemas.CartItemCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    item = (
        db.query(models.CartItem)
        .filter(
            models.CartItem.id == item_id, models.CartItem.user_id == current_user.id
        )
        .first()
    )
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    scheduled_at = _normalize_scheduled_at(data.scheduled_at)
    for key, value in data.model_dump(exclude={"scheduled_at"}).items():
        setattr(item, key, value)
    item.scheduled_at = scheduled_at
    db.commit()
    db.refresh(item)
    return _item_out(item)


@router.delete("/items/{item_id}", status_code=204)
def delete_item(
    item_id: int, db: Session = Depends(get_db), current_user=Depends(get_current_user)
):
    item = (
        db.query(models.CartItem)
        .filter(
            models.CartItem.id == item_id, models.CartItem.user_id == current_user.id
        )
        .first()
    )
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    db.delete(item)
    db.commit()
    return


@router.post("/sync", response_model=list[schemas.CartItemOut])
def sync_cart(
    sync: schemas.CartSync,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    db.query(models.CartItem).filter(
        models.CartItem.user_id == current_user.id
    ).delete()
    for item in sync.items:
        payload = item.model_dump()
        payload["scheduled_at"] = _normalize_scheduled_at(payload.get("scheduled_at"))
        db.add(models.CartItem(user_id=current_user.id, **payload))
    db.commit()
    items = (
        db.query(models.CartItem)
        .filter(models.CartItem.user_id == current_user.id)
        .all()
    )
    return [_item_out(i) for i in items]


def _calc_amount_from_db(db: Session, user_id: int) -> tuple[int, list[dict]]:
    items = (
        db.query(models.CartItem)
        .filter(models.CartItem.user_id == user_id)
        .order_by(models.CartItem.id)
        .all()
    )
    if not items:
        raise HTTPException(status_code=400, detail="Cart is empty")
    total_cents = Decimal("0")
    line_items: list[dict] = []
    for it in items:
        if it.type == "product":
            prod = db.get(models.Product, it.item_id)
            if not prod:
                raise HTTPException(status_code=400, detail="Invalid item")
            if prod.stock_count is not None and prod.stock_count < it.quantity:
                raise HTTPException(status_code=400, detail="Item unavailable")
            unit = (prod.price * Decimal(100)).quantize(Decimal("1"))
            total_cents += unit * it.quantity
            line_items.append(
                {"type": "product", "id": prod.id, "qty": it.quantity, "unit": int(unit)}
            )
        else:
            wk = db.get(models.Workshop, it.item_id)
            if not wk:
                raise HTTPException(status_code=400, detail="Invalid item")
            if wk.spots is not None and wk.spots < it.quantity:
                raise HTTPException(status_code=400, detail="Item unavailable")
            price = Decimal(wk.price or 0)
            unit = (price * Decimal(100)).quantize(Decimal("1"))
            total_cents += unit * it.quantity
            line_items.append(
                {"type": "workshop", "id": wk.id, "qty": it.quantity, "unit": int(unit)}
            )
    if total_cents <= 0:
        raise HTTPException(status_code=400, detail="Invalid amount")
    return int(total_cents), line_items


def _sync_pending_transactions(
    db: Session,
    user: models.User,
    payment_intent_id: str,
    cart_fp: str,
    line_items: list[dict[str, Any]],
) -> list[models.Transaction]:
    """Persist pending transaction records for the current cart state."""

    cart_items = (
        db.query(models.CartItem)
        .filter(models.CartItem.user_id == user.id)
        .order_by(models.CartItem.id)
        .all()
    )
    if len(cart_items) != len(line_items):
        raise HTTPException(status_code=400, detail="Cart mismatch")

    db.query(models.Transaction).filter(
        models.Transaction.payment_intent_id == payment_intent_id,
        models.Transaction.user_id == user.id,
    ).delete(synchronize_session=False)
    db.flush()

    created: list[models.Transaction] = []
    for cart_item, data in zip(cart_items, line_items):
        cents = Decimal(data["unit"]) * cart_item.quantity
        amount = (cents / Decimal("100")).quantize(Decimal("0.01"))
        scheduled = cart_item.scheduled_at
        if scheduled:
            scheduled = to_utc(scheduled)
        transaction = models.Transaction(
            user_id=user.id,
            type="Product" if cart_item.type == "product" else "Workshop",
            description=cart_item.name,
            amount=amount,
            status="Pending",
            method="Card",
            payment_intent_id=payment_intent_id,
            cart_fingerprint=cart_fp,
            workshop_date=scheduled,
        )
        db.add(transaction)
        created.append(transaction)

    db.flush()
    return created


@router.get("/summary", response_model=dict)
def get_cart_summary(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Return cart subtotal in dollars."""
    try:
        amount_cents, _ = _calc_amount_from_db(db, current_user.id)
        subtotal = amount_cents / 100
    except HTTPException as e:
        if e.status_code == 400 and e.detail == "Cart is empty":
            subtotal = 0
        else:
            raise

    return {"subtotal": round(subtotal, 2)}


@router.get("/total", response_model=dict)
def get_cart_total(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Return the cart total in cents."""
    try:
        amount, _ = _calc_amount_from_db(db, current_user.id)
    except HTTPException as e:
        if e.status_code == 400 and e.detail == "Cart is empty":
            return {"total": 0}
        raise
    return {"total": amount}


@router.post("/create-payment-intent", response_model=dict)
def create_payment_intent(
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    _check_rate_limit(db, f"create_pi:{request.client.host}")
    amount, line_items = _calc_amount_from_db(db, current_user.id)
    cart_fp = hashlib.sha256(
        json.dumps(line_items, sort_keys=True).encode()
    ).hexdigest()
    idempotency_key = f"{current_user.id}:{cart_fp}"
    customer_id = _get_or_create_customer(db, current_user)
    try:
        query = build_pi_search_query(current_user.id, cart_fp)
        search = stripe.PaymentIntent.search(query=query, limit=1)
        if search.data:
            intent = search.data[0]
            intent_customer = getattr(intent, "customer", None)
            if not intent_customer or intent_customer != customer_id:
                raise HTTPException(
                    status_code=400, detail="Payment customer mismatch"
                )
            intent_currency = getattr(intent, "currency", "usd")
            if intent_currency != "usd":
                raise HTTPException(
                    status_code=400, detail="Payment currency mismatch"
                )
            status = getattr(intent, "status", None)
            if status in ("succeeded", "canceled"):
                intent = stripe.PaymentIntent.create(
                    amount=amount,
                    currency="usd",
                    metadata={"user_id": str(current_user.id), "cart_fp": cart_fp},
                    idempotency_key=idempotency_key,
                    customer=customer_id,
                )
            elif intent.amount != amount:
                intent = stripe.PaymentIntent.modify(intent.id, amount=amount)
        else:
            intent = stripe.PaymentIntent.create(
                amount=amount,
                currency="usd",
                metadata={"user_id": str(current_user.id), "cart_fp": cart_fp},
                idempotency_key=idempotency_key,
                customer=customer_id,
            )
    except Exception as e:
        if isinstance(e, HTTPException):
            raise
        _handle_stripe_error(
            e,
            f"Failed to create payment intent for user {current_user.id}",
            "Unable to create payment intent",
            user_id=current_user.id,
        )

    try:
        intent_id = getattr(intent, "id", None)
        if intent_id:
            _sync_pending_transactions(
                db,
                current_user,
                intent_id,
                cart_fp,
                line_items,
            )
            db.commit()
        else:
            logger.warning(
                "Skipping pending transaction sync for user %s: intent id missing",
                _mask_user_id(current_user.id),
            )
    except HTTPException:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        logger.exception(
            "Failed to record pending transactions for user %s",
            _mask_user_id(current_user.id),
        )
        raise HTTPException(
            status_code=500, detail="Unable to prepare checkout"
        )

    return {"client_secret": intent.client_secret, "amount": amount}


@router.post("/checkout", response_model=list[schemas.TransactionOut])
def checkout(
    request: Request,
    payment_intent_id: Annotated[
        str, Body(..., embed=True, pattern=r"^pi_[A-Za-z0-9]+$")
    ],
    save_payment_method: bool = Body(False, embed=True),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Finalize checkout after a successful payment intent.

    Verifies the payment intent with Stripe, creates the appropriate user
    purchases and transaction records, clears the user's cart and returns the
    created transactions so the frontend can display order information.

    If the same ``payment_intent_id`` is submitted again for the current user,
    the previously created transactions are returned and no new records are
    written. Using a payment intent that has already been processed for another
    user results in a ``400`` error.
    """
    _check_rate_limit(db, f"checkout:{request.client.host}:{current_user.id}")

    # Return early if this payment intent was already processed.
    processed = (
        db.query(models.ProcessedPaymentIntent)
        .filter(models.ProcessedPaymentIntent.payment_intent_id == payment_intent_id)
        .first()
    )
    if processed:
        if processed.user_id == current_user.id:
            return (
                db.query(models.Transaction)
                .filter(models.Transaction.payment_intent_id == payment_intent_id)
                .all()
            )
        raise HTTPException(status_code=400, detail="Payment already processed")

    existing_tx = (
        db.query(models.Transaction)
        .filter(models.Transaction.payment_intent_id == payment_intent_id)
        .first()
    )
    if existing_tx and existing_tx.user_id != current_user.id:
        raise HTTPException(status_code=400, detail="Payment already processed")

    customer_id = _get_or_create_customer(db, current_user)
    try:
        intent = stripe.PaymentIntent.retrieve(payment_intent_id)
    except Exception as e:
        _handle_stripe_error(
            e,
            f"Payment intent verification failed for user {current_user.id}",
            "Unable to verify payment",
            user_id=current_user.id,
        )


    intent_customer = getattr(intent, "customer", None)
    if not intent_customer or intent_customer != current_user.stripe_customer_id:
        raise HTTPException(status_code=400, detail="Payment customer mismatch")

    intent_metadata = getattr(intent, "metadata", {})
    if intent_metadata.get("user_id") != str(current_user.id):
        raise HTTPException(status_code=400, detail="Payment not completed")

    amount_expected, line_items = _calc_amount_from_db(db, current_user.id)
    cart_fp = hashlib.sha256(
        json.dumps(line_items, sort_keys=True).encode()
    ).hexdigest()
    if intent_metadata.get("cart_fp") != cart_fp:
        raise HTTPException(status_code=400, detail="Cart mismatch")
    if (
        intent.status != "succeeded"
        or intent.amount_received != amount_expected
        or intent.currency != "usd"
    ):
        raise HTTPException(status_code=400, detail="Payment not completed")
    setup_usage = getattr(intent, "setup_future_usage", None)
    if save_payment_method and setup_usage not in ("off_session", None):
        raise HTTPException(status_code=400, detail="Payment setup mismatch")
    if not save_payment_method and setup_usage == "off_session":
        raise HTTPException(status_code=400, detail="Payment setup mismatch")

    payment_method_id = getattr(intent, "payment_method", None)
    if not payment_method_id:
        raise HTTPException(status_code=400, detail="Payment method not found")
    try:
        pm_info = stripe.PaymentMethod.retrieve(payment_method_id)
    except Exception as e:
        _handle_stripe_error(
            e,
            f"Payment method retrieval failed for user {current_user.id}",
            "Unable to retrieve payment method",
            user_id=current_user.id,
        )
    pm_customer = getattr(pm_info, "customer", None)
    if pm_customer and pm_customer != current_user.stripe_customer_id:
        raise HTTPException(
            status_code=400,
            detail="Payment method belongs to another customer",
        )
    attached_pm: Optional[Any] = None
    attached_pm_id: Optional[str] = None
    if not pm_customer:
        try:
            attached_pm = stripe.PaymentMethod.attach(
                payment_method_id, customer=customer_id
            )
            attached_pm_id = attached_pm.id
        except stripe.error.InvalidRequestError as e:
            if getattr(e, "code", None) != "resource_already_attached":
                _handle_stripe_error(
                    e,
                    f"Payment method attach failed for user {current_user.id}",
                    "Unable to attach payment method",
                    user_id=current_user.id,
                )
        except Exception as e:
            _handle_stripe_error(
                e,
                f"Payment method attach failed for user {current_user.id}",
                "Unable to attach payment method",
                user_id=current_user.id,
            )
    pm_source = (
        attached_pm if attached_pm and getattr(attached_pm, "card", None) else pm_info
    )
    card = getattr(pm_source, "card", None)
    if not card:
        raise HTTPException(status_code=400, detail="Invalid payment method")
    stripe_pm_id = pm_source.id

    db.rollback()
    transactions: list[models.Transaction] = []
    try:
        with db.begin():
            try:
                db.add(
                    models.ProcessedPaymentIntent(
                        user_id=current_user.id,
                        payment_intent_id=payment_intent_id,
                    )
                )
                db.flush()
            except IntegrityError:
                raise HTTPException(status_code=400, detail="Payment already processed")

            pm = (
                db.query(models.PaymentMethod)
                .filter(
                    models.PaymentMethod.user_id == current_user.id,
                    models.PaymentMethod.stripe_pm_id == stripe_pm_id,
                )
                .first()
            )
            if save_payment_method and not pm:
                brand = card.brand.title()
                last4 = card.last4
                expiry = f"{int(card.exp_month):02}/{str(card.exp_year)[-2:]}"
                is_primary = (
                    db.query(models.PaymentMethod)
                    .filter(models.PaymentMethod.user_id == current_user.id)
                    .count()
                    == 0
                )
                pm = models.PaymentMethod(
                    user_id=current_user.id,
                    brand=brand,
                    last4=last4,
                    expiry=expiry,
                    stripe_pm_id=stripe_pm_id,
                    is_primary=is_primary,
                )
                db.add(pm)
                db.flush()

            txs = (
                db.query(models.Transaction)
                .filter(
                    models.Transaction.payment_intent_id == payment_intent_id,
                    models.Transaction.user_id == current_user.id,
                )
                .with_for_update()
                .all()
            )
            if not txs:
                raise HTTPException(status_code=400, detail="Pending transaction not found")

            for tx in txs:
                tx.status = "Paid"
                tx.payment_method_id = pm.id if pm else None
                tx.method = "Card"

            items = (
                db.query(models.CartItem)
                .filter(models.CartItem.user_id == current_user.id)
                .all()
            )
            for item in items:
                if item.type == "product":
                    prod = db.get(models.Product, item.item_id)
                    if prod.stock_count is not None:
                        if prod.stock_count < item.quantity:
                            raise HTTPException(status_code=400, detail="Item unavailable")
                        prod.stock_count -= item.quantity
                    db.add(
                        models.UserProduct(
                            user_id=current_user.id, product_id=item.item_id
                        )
                    )
                else:
                    wk = db.get(models.Workshop, item.item_id)
                    if wk.spots is not None:
                        if wk.spots < item.quantity:
                            raise HTTPException(status_code=400, detail="Item unavailable")
                        wk.spots -= item.quantity
                    db.add(
                        models.UserWorkshop(
                            user_id=current_user.id, workshop_id=item.item_id
                        )
                    )
                db.delete(item)
            transactions = txs
    except HTTPException:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        if attached_pm_id:
            try:
                stripe.PaymentMethod.detach(attached_pm_id)
            except Exception:
                logger.exception(
                    "Failed to detach payment method %s", attached_pm_id
                )
        logger.exception(
            "Failed to finalize checkout for user %s",
            _mask_user_id(current_user.id),
        )
        raise HTTPException(
            status_code=500, detail="Failed to finalize checkout"
        ) from None

    if attached_pm_id and not save_payment_method:
        try:
            stripe.PaymentMethod.detach(attached_pm_id)
        except Exception:
            logger.exception(
                "Failed to detach payment method %s", attached_pm_id
            )

    for tr in transactions:
        db.refresh(tr)
        if tr.workshop_date:
            tr.workshop_date = to_utc(tr.workshop_date)

    return transactions


@router.post("/cancel-payment-intent", response_model=dict)
def cancel_payment_intent(
    request: Request,
    payment_intent_id: Annotated[
        str, Body(..., embed=True, pattern=r"^pi_[A-Za-z0-9]+$")
    ],
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Cancel an existing Stripe payment intent for the current user."""

    _check_rate_limit(db, f"cancel_pi:{request.client.host}:{current_user.id}")
    try:
        intent = stripe.PaymentIntent.retrieve(payment_intent_id)
    except Exception as e:
        _handle_stripe_error(
            e,
            f"Payment intent retrieval failed for user {current_user.id}",
            "Unable to cancel payment intent",
            user_id=current_user.id,
        )

    intent_metadata = getattr(intent, "metadata", {})
    if intent_metadata.get("user_id") != str(current_user.id):
        logger.warning(
            "User %s attempted to cancel payment intent %s not belonging to them",
            _mask_user_id(current_user.id),
            payment_intent_id,
        )
        raise HTTPException(status_code=404, detail="Payment intent not found")

    try:
        stripe.PaymentIntent.cancel(payment_intent_id)
        logger.info(
            "Canceled payment intent %s for user %s",
            payment_intent_id,
            _mask_user_id(current_user.id),
        )
        return {"status": "canceled"}
    except Exception as e:
        _handle_stripe_error(
            e,
            f"Failed to cancel payment intent {payment_intent_id} for user {current_user.id}",
            "Unable to cancel payment intent",
            user_id=current_user.id,
        )
