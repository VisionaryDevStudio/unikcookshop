from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlalchemy.orm import Session
import base64
import json
import os
from google.oauth2 import id_token
from google.auth.transport import requests

from .. import models, schemas, auth
from ..database import get_db
from ..rate_limiter import _check_rate_limit


router = APIRouter(prefix="/api/auth", tags=["auth"])
COOKIE_DOMAIN = os.getenv("COOKIE_DOMAIN")


@router.get("/csrf-token")
def issue_csrf_token(response: Response):
    token = auth.set_csrf_cookie(response)
    return {"csrf_token": token}


@router.post("/signup", response_model=schemas.Token)
def signup(
    user: schemas.UserCreate,
    request: Request,
    response: Response,
    db: Session = Depends(get_db),
):
    _check_rate_limit(db, f"signup:{request.client.host}")
    existing = db.query(models.User).filter(models.User.email == user.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed = auth.get_password_hash(user.password)
    db_user = models.User(name=user.name, email=user.email, password_hash=hashed)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    access = auth.create_access_token(db_user.id)
    refresh = auth.create_refresh_token(db_user.id)
    auth.set_csrf_cookie(response, request)
    response.set_cookie(
        "access_token",
        access,
        httponly=True,
        secure=True,
        samesite="none",
        domain=COOKIE_DOMAIN,
        max_age=auth.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )
    response.set_cookie(
        "refresh_token",
        refresh,
        httponly=True,
        secure=True,
        samesite="none",
        domain=COOKIE_DOMAIN,
        max_age=auth.REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60,
    )
    return {
        "access_token": access,
        "refresh_token": refresh,
        "token_type": "bearer",
        "user": schemas.UserOut.from_orm(db_user),
    }


@router.post("/login", response_model=schemas.Token)
def login(
    credentials: schemas.UserLogin,
    request: Request,
    response: Response,
    db: Session = Depends(get_db),
):
    _check_rate_limit(db, f"login:{request.client.host}")
    user = db.query(models.User).filter(models.User.email == credentials.email).first()
    if not user or not auth.verify_password(credentials.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    access = auth.create_access_token(user.id)
    refresh = auth.create_refresh_token(user.id)
    auth.set_csrf_cookie(response, request)
    response.set_cookie(
        "access_token",
        access,
        httponly=True,
        secure=True,
        samesite="none",
        domain=COOKIE_DOMAIN,
        max_age=auth.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )
    response.set_cookie(
        "refresh_token",
        refresh,
        httponly=True,
        secure=True,
        samesite="none",
        domain=COOKIE_DOMAIN,
        max_age=auth.REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60,
    )
    return {
        "access_token": access,
        "refresh_token": refresh,
        "token_type": "bearer",
        "user": schemas.UserOut.from_orm(user),
    }


@router.post("/refresh", response_model=schemas.Token)
def refresh(
    request: Request,
    response: Response,
    token: dict | None = None,
    db: Session = Depends(get_db),
):
    _check_rate_limit(db, f"refresh:{request.client.host}")
    refresh_token = None
    if token:
        refresh_token = token.get("refresh_token")
    if not refresh_token:
        refresh_token = request.cookies.get("refresh_token")
    if not refresh_token:
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    payload = auth.decode_token(refresh_token)
    user_id = int(payload.get("sub"))
    user = db.get(models.User, user_id)
    if not user:
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    access = auth.create_access_token(user.id)
    refresh_new = auth.create_refresh_token(user.id)
    auth.set_csrf_cookie(response, request)
    response.set_cookie(
        "access_token",
        access,
        httponly=True,
        secure=True,
        samesite="none",
        domain=COOKIE_DOMAIN,
        max_age=auth.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )
    response.set_cookie(
        "refresh_token",
        refresh_new,
        httponly=True,
        secure=True,
        samesite="none",
        domain=COOKIE_DOMAIN,
        max_age=auth.REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60,
    )
    return {
        "access_token": access,
        "refresh_token": refresh_new,
        "token_type": "bearer",
        "user": schemas.UserOut.from_orm(user),
    }


@router.post("/google", response_model=schemas.Token)
def google_login(
    data: schemas.GoogleAuth,
    request: Request,
    response: Response,
    db: Session = Depends(get_db),
):
    _check_rate_limit(db, f"google:{request.client.host}")
    email = name = None
    # Allow base64-encoded payloads only in development/testing
    if os.getenv("ENV", "development") == "development":
        try:
            decoded = json.loads(base64.b64decode(data.token).decode())
            email = decoded["email"]
            name = decoded.get("name", "Google User")
        except Exception:
            email = None

    if not email:
        # Treat the token as a Google ID token issued by OAuth
        try:
            client_id = os.getenv("GOOGLE_CLIENT_ID")
            info = id_token.verify_oauth2_token(data.token, requests.Request(), client_id)
            email = info["email"]
            name = info.get("name", "Google User")
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid token")

    user = db.query(models.User).filter(models.User.email == email).first()
    if not user:
        pwd = auth.get_password_hash("google")
        user = models.User(name=name, email=email, password_hash=pwd)
        db.add(user)
        db.commit()
        db.refresh(user)

    access = auth.create_access_token(user.id)
    refresh = auth.create_refresh_token(user.id)
    response.set_cookie(
        "access_token",
        access,
        httponly=True,
        secure=True,
        samesite="none",
        domain=COOKIE_DOMAIN,
    )
    response.set_cookie(
        "refresh_token",
        refresh,
        httponly=True,
        secure=True,
        samesite="none",
        domain=COOKIE_DOMAIN,
    )
    return {
        "access_token": access,
        "refresh_token": refresh,
        "token_type": "bearer",
        "user": schemas.UserOut.from_orm(user),
    }


@router.post("/logout")
def logout(response: Response):
    response.delete_cookie("access_token", domain=COOKIE_DOMAIN)
    response.delete_cookie("refresh_token", domain=COOKIE_DOMAIN)
    return {"message": "logged out"}

