from datetime import datetime, timezone
from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException, Path, Request

from sqlalchemy.orm import Session
import json
import stripe

from .. import schemas
from ..database import get_db
from ..auth import get_current_user, verify_password, get_password_hash
from .. import models
from ..logger import logger
from ..rate_limiter import _check_rate_limit
from ..csrf import validate_csrf_token
from ..utils.time import to_utc

LOCATION_COORDS = {
    "Culinary Studio A": "40.7128,-74.0060",
    "Culinary Studio B": "34.0522,-118.2437",
}

router = APIRouter(
    prefix="/api/users", tags=["users"], dependencies=[Depends(validate_csrf_token)]
)


@router.get("/me", response_model=schemas.UserOut)
def get_me(current_user=Depends(get_current_user)):
    return current_user


@router.put("/me", response_model=schemas.UserOut)
def update_me(
    update: schemas.UserUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    data = update.model_dump(exclude_unset=True)
    for key, value in data.items():
        setattr(current_user, key, value)
    db.commit()
    db.refresh(current_user)
    return current_user


@router.post("/me/password", status_code=204)
def change_password(
    data: schemas.PasswordChange,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    if not verify_password(data.current_password, current_user.password_hash):
        raise HTTPException(status_code=400, detail="Incorrect password")
    current_user.password_hash = get_password_hash(data.new_password)
    db.commit()
    return

@router.get("/me/workshops/upcoming", response_model=list[schemas.WorkshopOut])
def upcoming_workshops(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    now = datetime.now(timezone.utc)
    workshops = (
        db.query(models.Workshop)
        .join(models.UserWorkshop)
        .filter(models.UserWorkshop.user_id == current_user.id)
        .filter(models.Workshop.date >= now)
        .all()
    )
    for w in workshops:
        w.date = to_utc(w.date)
        if w.seasonal_ingredients:
            w.seasonal_ingredients = json.loads(w.seasonal_ingredients)
        if w.learning_outcomes:
            w.learning_outcomes = json.loads(w.learning_outcomes)
        w.attendees_count = len(w.attendees)
        w.location_coords = LOCATION_COORDS.get(w.location, "0,0")
    return workshops


@router.get("/me/workshops/history", response_model=list[schemas.WorkshopOut])
def history_workshops(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    now = datetime.now(timezone.utc)
    workshops = (
        db.query(models.Workshop)
        .join(models.UserWorkshop)
        .filter(models.UserWorkshop.user_id == current_user.id)
        .filter(models.Workshop.date < now)
        .all()
    )
    for w in workshops:
        w.date = to_utc(w.date)
        if w.seasonal_ingredients:
            w.seasonal_ingredients = json.loads(w.seasonal_ingredients)
        if w.learning_outcomes:
            w.learning_outcomes = json.loads(w.learning_outcomes)
        w.attendees_count = len(w.attendees)
        w.location_coords = LOCATION_COORDS.get(w.location, "0,0")
    return workshops


@router.get("/me/products", response_model=list[schemas.PurchasedProductOut])
def purchased_products(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    purchases = (
        db.query(models.UserProduct, models.Product)
        .join(models.Product, models.UserProduct.product_id == models.Product.id)
        .filter(models.UserProduct.user_id == current_user.id)
        .all()
    )
    result = []
    for up, prod in purchases:
        purchase_date = to_utc(up.purchase_date)
        result.append(
            schemas.PurchasedProductOut(
                id=prod.id,
                name=prod.name,
                price=prod.price,
                image=prod.image,
                purchase_date=purchase_date,
            )
        )
    return result


@router.get("/me/billing", response_model=list[schemas.TransactionOut])
def billing_history(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):

    txs = (
        db.query(models.Transaction)
        .filter(models.Transaction.user_id == current_user.id)
        .all()
    )
    for tx in txs:
        tx.date = to_utc(tx.date)
        if tx.workshop_date is not None:
            tx.workshop_date = to_utc(tx.workshop_date)
    return txs


@router.get("/me/transactions/{payment_intent_id}", response_model=list[schemas.TransactionOut])
def transactions_by_payment_intent(
    payment_intent_id: Annotated[str, Path(pattern=r"^pi_[A-Za-z0-9]+$")],
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    txs = (
        db.query(models.Transaction)
        .filter(
            models.Transaction.user_id == current_user.id,
            models.Transaction.payment_intent_id == payment_intent_id,
        )
        .all()
    )
    for tx in txs:
        tx.date = to_utc(tx.date)
        if tx.workshop_date is not None:
            tx.workshop_date = to_utc(tx.workshop_date)
    return txs


@router.get("/me/payment-methods", response_model=list[schemas.PaymentMethodOut])
def payment_methods(
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    _check_rate_limit(
        db,
        f"payment_methods:{request.client.host}:{current_user.id}",
        limit=10,
    )
    return (
        db.query(models.PaymentMethod)
        .filter(models.PaymentMethod.user_id == current_user.id)
        .all()
    )


@router.delete("/me/payment-methods/{pm_id}", status_code=204)
def delete_payment_method(
    pm_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    _check_rate_limit(
        db,
        f"delete_payment_method:{request.client.host}:{current_user.id}",
        limit=5,
    )
    pm = (
        db.query(models.PaymentMethod)
        .filter(
            models.PaymentMethod.id == pm_id,
            models.PaymentMethod.user_id == current_user.id,
        )
        .first()
    )
    if not pm:
        raise HTTPException(status_code=404, detail="Payment method not found")
    try:
        stripe.PaymentMethod.detach(pm.stripe_pm_id)
    except stripe.error.StripeError:
        logger.exception(
            "Failed to detach payment method %s for user %s",
            pm.stripe_pm_id,
            current_user.id,
        )
        raise HTTPException(status_code=400, detail="Unable to detach payment method")
    db.delete(pm)
    db.commit()
    return


@router.post("/me/payment-methods/{pm_id}/primary", response_model=schemas.PaymentMethodOut)
def set_primary_payment_method(
    pm_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    _check_rate_limit(
        db,
        f"set_primary_payment_method:{request.client.host}:{current_user.id}",
        limit=5,
    )
    pm = (
        db.query(models.PaymentMethod)
        .filter(
            models.PaymentMethod.id == pm_id,
            models.PaymentMethod.user_id == current_user.id,
        )
        .first()
    )
    if not pm:
        raise HTTPException(status_code=404, detail="Payment method not found")
    db.query(models.PaymentMethod).filter(
        models.PaymentMethod.user_id == current_user.id
    ).update({models.PaymentMethod.is_primary: False})
    pm.is_primary = True
    db.commit()
    db.refresh(pm)
    return pm


@router.get("/me/reviews", response_model=list[schemas.ReviewOut])
def my_reviews(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    return db.query(models.Review).filter(models.Review.user_id == current_user.id, models.Review.status == 'approved').all()


@router.get("/me/reviews/pending", response_model=list[schemas.ReviewOut])
def pending_reviews(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    return db.query(models.Review).filter(models.Review.user_id == current_user.id, models.Review.status == 'pending').all()


@router.post("/reviews", response_model=schemas.ReviewOut)
def create_review(
    review: schemas.ReviewCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    new_review = models.Review(
        user_id=current_user.id,
        item_type=review.item_type,
        item_title=review.item_title,
        rating=review.rating,
        review=review.review,
        status="pending",
    )
    db.add(new_review)
    db.commit()
    db.refresh(new_review)
    return new_review

