"""Container healthcheck script.

This module pings the FastAPI application's health endpoint and exits with
status 0 when the service responds successfully. Docker executes this module
via ``python -m backend.healthcheck`` inside the container.
"""

from __future__ import annotations

import socket
import sys
import urllib.error
import urllib.request

HEALTH_URL = "http://127.0.0.1:8000/api/health"


def main() -> int:
    try:
        with urllib.request.urlopen(HEALTH_URL, timeout=5) as response:  # noqa: S310
            if 200 <= response.status < 400:
                return 0
            return 1
    except (urllib.error.URLError, urllib.error.HTTPError, socket.timeout):
        return 1


if __name__ == "__main__":
    sys.exit(main())
