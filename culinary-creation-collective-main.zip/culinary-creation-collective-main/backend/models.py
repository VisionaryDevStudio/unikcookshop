from sqlalchemy import (
    Boolean,
    Column,
    Integer,
    String,
    DateTime,
    ForeignKey,
    Float,
    Numeric,
    Text,
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from .database import Base

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    is_admin = Column(Boolean, default=False)
    phone = Column(String, nullable=True)
    location = Column(String, nullable=True)
    bio = Column(String, nullable=True)
    dietary_restrictions = Column(String, nullable=True)
    cooking_experience = Column(String, nullable=True)
    favorite_cuisines = Column(String, nullable=True)
    cooking_goals = Column(String, nullable=True)
    equipment_available = Column(String, nullable=True)
    stripe_customer_id = Column(String, nullable=True, unique=True, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    workshops = relationship('UserWorkshop', back_populates='user')
    products = relationship('UserProduct', back_populates='user')
    payment_methods = relationship('PaymentMethod', back_populates='user')
    transactions = relationship('Transaction', back_populates='user')
    reviews = relationship('Review', back_populates='user')


class Workshop(Base):
    __tablename__ = 'workshops'
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    date = Column(DateTime(timezone=True), nullable=False)  # stored in UTC
    instructor = Column(String, nullable=False)
    location = Column(String, nullable=False)
    image = Column(String, nullable=True)
    description = Column(String, default='')
    type = Column(String, nullable=True)
    cuisine = Column(String, nullable=True)
    level = Column(String, nullable=True)
    duration = Column(String, nullable=True)
    price = Column(Float, nullable=True)
    spots = Column(Integer, nullable=True)
    full_description = Column(String, default='')
    what_youll_make = Column(String, default='')
    seasonal_ingredients = Column(String, default='[]')  # JSON array stored as string
    learning_outcomes = Column(String, default='[]')  # JSON array stored as string

    attendees = relationship('UserWorkshop', back_populates='workshop')


class UserWorkshop(Base):
    __tablename__ = 'user_workshops'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    workshop_id = Column(Integer, ForeignKey('workshops.id'), nullable=False)

    user = relationship('User', back_populates='workshops')
    workshop = relationship('Workshop', back_populates='attendees')


class Product(Base):
    __tablename__ = 'products'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    price = Column(Numeric(10, 2), nullable=False)
    image = Column(String, nullable=False)
    images = Column(String, default='[]')  # JSON array stored as string
    category = Column(String, default='Product')
    description = Column(String, default='')
    features = Column(String, default='[]')  # JSON array stored as string
    specifications = Column(String, default='{}')  # JSON object stored as string
    stock_count = Column(Integer, default=0)

    purchases = relationship('UserProduct', back_populates='product')


class UserProduct(Base):
    __tablename__ = 'user_products'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    product_id = Column(Integer, ForeignKey('products.id'), nullable=False)
    purchase_date = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship('User', back_populates='products')
    product = relationship('Product', back_populates='purchases')


class PaymentMethod(Base):
    __tablename__ = 'payment_methods'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    brand = Column(String, nullable=False)
    last4 = Column(String, nullable=False)
    expiry = Column(String, nullable=False)
    stripe_pm_id = Column(String, nullable=False, unique=True)
    is_primary = Column(Boolean, default=False)

    user = relationship('User', back_populates='payment_methods')
    transactions = relationship('Transaction', back_populates='payment_method')


class Transaction(Base):
    __tablename__ = 'transactions'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    type = Column(String, nullable=False)
    description = Column(String, nullable=False)
    date = Column(DateTime(timezone=True), server_default=func.now())
    amount = Column(Numeric(10, 2), nullable=False)
    status = Column(String, nullable=False)
    method = Column(String, nullable=False)
    # Stripe PaymentIntent identifier for idempotency when recording
    # transactions. Indexed to allow quick lookups when validating
    # repeated checkout requests.
    payment_intent_id = Column(String, nullable=True, index=True)
    cart_fingerprint = Column(String, nullable=True, index=True)
    payment_method_id = Column(Integer, ForeignKey('payment_methods.id'), nullable=True)
    workshop_date = Column(DateTime(timezone=True), nullable=True)

    user = relationship('User', back_populates='transactions')
    payment_method = relationship('PaymentMethod', back_populates='transactions')


class Review(Base):
    __tablename__ = 'reviews'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    item_type = Column(String, nullable=False)
    item_title = Column(String, nullable=False)
    rating = Column(Integer, nullable=False)
    review = Column(String, nullable=False)
    helpful = Column(Integer, default=0)
    status = Column(String, default='approved')
    date = Column(DateTime(timezone=True), server_default=func.now())
    verified_purchase = Column(Boolean, default=False)
    verified = Column(Boolean, default=False)

    user = relationship('User', back_populates='reviews')


class CartItem(Base):
    __tablename__ = 'cart_items'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    item_id = Column(Integer, nullable=False)
    name = Column(String, nullable=False)
    price = Column(String, nullable=False)
    category = Column(String, nullable=False)
    image = Column(String, nullable=False)
    quantity = Column(Integer, default=1)
    type = Column(String, nullable=False)
    scheduled_at = Column(DateTime(timezone=True), nullable=True)

    user = relationship('User')


class Inquiry(Base):
    __tablename__ = 'inquiries'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    workshop_type = Column(String, nullable=False)
    participants = Column(Integer, nullable=False)
    preferred_date = Column(String, nullable=False)
    message = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    status = Column(String, nullable=False, server_default="pending")


class SiteSetting(Base):
    __tablename__ = 'site_settings'
    key = Column(String, primary_key=True, index=True)
    value = Column(String, nullable=False)


class RateLimit(Base):
    __tablename__ = 'rate_limits'
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String, nullable=False, index=True)
    timestamp = Column(Float, nullable=False, index=True)


class ProcessedPaymentIntent(Base):
    __tablename__ = 'processed_payment_intents'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    payment_intent_id = Column(String, nullable=False, unique=True, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship('User')


class ProcessedEvent(Base):
    __tablename__ = 'processed_events'
    # ``id`` comes from Stripe event identifiers. Marked as unique and indexed to
    # guarantee idempotent processing even under concurrent requests.
    id = Column(String, primary_key=True, index=True, unique=True)


class PendingStripeEvent(Base):
    __tablename__ = 'pending_stripe_events'
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(String, nullable=False, unique=True, index=True)
    payment_intent_id = Column(String, nullable=False, index=True)
    event_type = Column(String, nullable=False)
    payload = Column(Text, nullable=False)
    attempts = Column(Integer, nullable=False, default=0)
    last_error = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    processed_at = Column(DateTime(timezone=True), server_default=func.now())

