"""Utilities for cancelling stale Stripe ``PaymentIntent`` objects.

This module exposes :func:`cancel_stale_payment_intents` which performs a
single cleanup pass. A small command line interface is also provided so the
cleanup can be executed manually or run in a simple long‑running service.
"""

import argparse
import os
import time
from datetime import datetime, timedelta, timezone

import stripe

from .logger import logger
from .utils.stripe_config import load_stripe_secret_key

# Environment variable for Stripe secret key must be set externally
stripe.api_key = load_stripe_secret_key()

# Age threshold (in minutes) before a non-final PaymentIntent is cancelled
STALE_MINUTES = int(os.getenv("PAYMENT_INTENT_STALE_MINUTES", "60"))

# Stripe PaymentIntent statuses that mean the intent is still open
_NON_FINAL_STATUSES = [
    "requires_payment_method",
    "requires_confirmation",
    "requires_action",
    "processing",
]


def cancel_stale_payment_intents() -> None:
    """Cancel outdated PaymentIntents via the Stripe API.

    Any PaymentIntent that is older than ``STALE_MINUTES`` and not in a
    terminal state is cancelled. All actions and errors are logged so the
    process is auditable when run via cron or another background scheduler.
    """

    cutoff = int(
        (datetime.now(tz=timezone.utc) - timedelta(minutes=STALE_MINUTES)).timestamp()
    )
    for status in _NON_FINAL_STATUSES:
        try:
            payment_intents = stripe.PaymentIntent.list(
                status=status, created={"lt": cutoff}, limit=100
            )
        except Exception:
            logger.exception(
                "Failed to list PaymentIntents with status %s", status
            )
            continue

        for pi in payment_intents.auto_paging_iter():
            try:
                stripe.PaymentIntent.cancel(pi.id)
                logger.info("Canceled stale PaymentIntent %s", pi.id)
            except Exception:
                logger.exception(
                    "Error cancelling PaymentIntent %s with status %s", pi.id, status
                )

def main() -> None:
    """Command line entry point.

    By default the script performs a single cleanup pass. Passing ``--loop``
    keeps the process alive and reruns the cleanup every ``STALE_MINUTES``
    minutes, providing a minimal cron-like service.
    """

    global STALE_MINUTES

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--minutes",
        type=int,
        default=STALE_MINUTES,
        help="Override age threshold in minutes before cancelling",
    )
    parser.add_argument(
        "--loop",
        action="store_true",
        help="Continuously run, sleeping for the threshold between runs",
    )
    args = parser.parse_args()

    STALE_MINUTES = args.minutes

    if args.loop:
        while True:  # pragma: no branch - simple service loop
            cancel_stale_payment_intents()
            time.sleep(STALE_MINUTES * 60)
    else:
        cancel_stale_payment_intents()


if __name__ == "__main__":  # pragma: no cover - manual execution only
    main()
