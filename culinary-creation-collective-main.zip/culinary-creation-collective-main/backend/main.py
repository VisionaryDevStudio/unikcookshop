from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os
from dotenv import load_dotenv
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

load_dotenv()

from .database import Base, engine
from .routers import auth, users, admin, cart, public, bin_lookup, webhooks

Base.metadata.create_all(bind=engine)

app = FastAPI()

# Build list of allowed origins. Default to allowing the Vite dev server so
# that the frontend can communicate with this API during development.
origins = [
    o.strip()
    for o in os.getenv("ALLOWED_ORIGINS", "http://localhost:8080").split(",")
    if o.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class SecurityHeaders(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response: Response = await call_next(request)
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault(
            "Permissions-Policy", "camera=(), microphone=()"
        )
        response.headers.setdefault(
            "Strict-Transport-Security", "max-age=31536000; includeSubDomains"
        )
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; script-src 'self'; style-src 'self' 'unsafe-inline'",
        )
        return response


app.add_middleware(SecurityHeaders)

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(admin.router)
app.include_router(cart.router)
app.include_router(public.router)
app.include_router(bin_lookup.router)
app.include_router(webhooks.router)


@app.get("/api/health", tags=["health"])
def health_check():
    return {"status": "ok"}

