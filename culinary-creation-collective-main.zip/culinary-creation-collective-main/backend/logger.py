"""Central logging configuration with PCI-compliant filtering.

This module exposes a configured ``logger`` instance used throughout the
backend.  The logger applies a filter that masks potentially sensitive data
such as credit card numbers and email addresses before anything is written to
the log.  It also writes payment related logs to a rotating file handler so
that old logs are automatically removed after a retention period, helping the
project stay aligned with PCI DSS requirements.
"""

import logging
import os
import re
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path


class _PciSanitizingFilter(logging.Filter):
    """Mask card numbers and email addresses in log records."""

    _email_re = re.compile(r"([A-Za-z0-9._%+-]+)@([A-Za-z0-9.-]+)")
    _card_re = re.compile(r"\b(\d{4})\d{8,11}(\d{4})\b")
    _client_secret_re = re.compile(r"""(client_secret['"=:\s]*)([^'"\s]+)""")

    @classmethod
    def _sanitize(cls, value: str) -> str:
        value = cls._email_re.sub(r"***@\2", value)
        value = cls._card_re.sub(lambda m: f"{m.group(1)}****{m.group(2)}", value)
        value = cls._client_secret_re.sub(r"\1***", value)
        return value

    def filter(self, record: logging.LogRecord) -> bool:  # pragma: no cover - simple
        record.msg = self._sanitize(str(record.msg))
        if record.args:
            if isinstance(record.args, tuple):
                record.args = tuple(self._sanitize(str(a)) for a in record.args)
            elif isinstance(record.args, dict):
                record.args = {
                    k: self._sanitize(str(v)) for k, v in record.args.items()
                }
        return True


logger = logging.getLogger("culinary")
if not logger.handlers:
    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    stream_handler.addFilter(_PciSanitizingFilter())
    logger.addHandler(stream_handler)

    log_dir = Path(os.getenv("PAYMENT_LOG_DIR", "/var/log/culinary-payments"))
    log_dir.mkdir(parents=True, exist_ok=True)
    os.chmod(log_dir, 0o700)
    log_file = log_dir / "payments.log"
    log_file.touch(mode=0o600, exist_ok=True)
    os.chmod(log_file, 0o600)
    file_handler = TimedRotatingFileHandler(
        str(log_file),
        when="D",
        interval=1,
        backupCount=30,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    file_handler.addFilter(_PciSanitizingFilter())
    logger.addHandler(file_handler)

    logger.setLevel(logging.INFO)
