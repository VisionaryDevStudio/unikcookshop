from fastapi import Request, HTTPException, status
import secrets


def validate_csrf_token(request: Request) -> None:
    """Ensure the request contains a valid CSRF token."""
    header_token = request.headers.get("X-CSRF-Token")
    cookie_token = request.cookies.get("csrf_token")
    if not header_token or not cookie_token or not secrets.compare_digest(header_token, cookie_token):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid or missing CSRF token",
        )

