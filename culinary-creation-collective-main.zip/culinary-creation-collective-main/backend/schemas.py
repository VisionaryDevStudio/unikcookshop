from pydantic import BaseModel, EmailStr, ConfigDict, field_validator
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional, List, Any

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    is_admin: bool
    created_at: datetime
    phone: Optional[str] = None
    location: Optional[str] = None
    bio: Optional[str] = None
    dietary_restrictions: Optional[str] = None
    cooking_experience: Optional[str] = None
    favorite_cuisines: Optional[str] = None
    cooking_goals: Optional[str] = None
    equipment_available: Optional[str] = None
    stripe_customer_id: Optional[str] = None
    total_spent: float = 0
    workshops_attended: int = 0
    status: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = 'bearer'
    user: UserOut

class GoogleAuth(BaseModel):
    token: str

class AdminCreate(UserCreate):
    pass


class UserUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    location: Optional[str] = None
    bio: Optional[str] = None
    dietary_restrictions: Optional[str] = None
    cooking_experience: Optional[str] = None
    favorite_cuisines: Optional[str] = None
    cooking_goals: Optional[str] = None
    equipment_available: Optional[str] = None
    email: Optional[EmailStr] = None
    is_admin: Optional[bool] = None

class PasswordChange(BaseModel):
    current_password: str
    new_password: str


class WorkshopOut(BaseModel):
    id: int
    title: str
    date: datetime
    instructor: str
    location: str
    image: str | None = None
    description: str | None = None
    type: str | None = None
    cuisine: str | None = None
    level: str | None = None
    duration: str | None = None
    price: float | None = None
    capacity: int | None = None
    enrolled: int | None = None
    location_coords: str | None = None
    full_description: str | None = None
    what_youll_make: str | None = None
    seasonal_ingredients: list[str] | None = None
    learning_outcomes: list[str] | None = None
    status: str | None = None

    model_config = ConfigDict(from_attributes=True, json_encoders={datetime: lambda v: v.astimezone(timezone.utc).isoformat().replace("+00:00","Z")})


class PurchasedProductOut(BaseModel):
    id: int
    name: str
    price: float
    image: str
    purchase_date: datetime

    model_config = ConfigDict(from_attributes=True, json_encoders={datetime: lambda v: v.astimezone(timezone.utc).isoformat().replace("+00:00","Z")})


class TransactionOut(BaseModel):
    id: int
    type: str
    description: str
    date: datetime
    amount: float
    status: str
    method: str
    workshop_date: datetime | None = None
    payment_intent_id: str | None = None
    payment_method_id: int | None = None

    model_config = ConfigDict(from_attributes=True, json_encoders={datetime: lambda v: v.astimezone(timezone.utc).isoformat().replace("+00:00","Z")})


class PaymentMethodOut(BaseModel):
    id: int
    brand: str
    last4: str
    expiry: str
    is_primary: bool
    stripe_pm_id: str

    model_config = ConfigDict(from_attributes=True)


class ReviewOut(BaseModel):
    id: int
    item_type: str
    item_title: str
    rating: int
    review: str
    helpful: int
    status: str
    date: datetime
    verified_purchase: bool
    verified: bool

    model_config = ConfigDict(from_attributes=True)


class ReviewCreate(BaseModel):
    item_type: str
    item_title: str
    rating: int
    review: str


class ReviewStatusUpdate(BaseModel):
    status: str


class OrderStatusUpdate(BaseModel):
    status: str


class ProductOut(BaseModel):
    id: int
    name: str
    price: float
    image: str
    images: list[str] | None = None
    category: str | None = None
    description: str | None = None
    features: list[str] | None = None
    specifications: dict[str, str] | None = None
    stock_count: int = 0
    rating: float | None = None
    review_count: int = 0

    model_config = ConfigDict(from_attributes=True)


class ProductAdminOut(BaseModel):
    id: int
    name: str
    price: float
    image: str
    images: list[str] | None = None
    category: str | None = None
    description: str | None = None
    features: list[str] | None = None
    specifications: dict[str, str] | None = None
    stock: int = 0
    sold: int = 0
    rating: float | None = None
    review_count: int = 0

    model_config = ConfigDict(from_attributes=True)


class ProductCreate(BaseModel):
    name: str
    price: float
    image: str
    images: list[str] | None = None
    category: str | None = None
    description: str | None = None
    features: list[str] | None = None
    specifications: dict[str, str] | None = None
    stock_count: int | None = None


class ImageUploadOut(BaseModel):
    path: str


class WorkshopCreate(BaseModel):
    title: str
    date: datetime
    instructor: str
    location: str
    image: str | None = None
    description: str | None = None
    type: str | None = None
    cuisine: str | None = None
    level: str | None = None
    duration: str | None = None
    price: float | None = None
    spots: int | None = None
    full_description: str | None = None
    what_youll_make: str | None = None
    seasonal_ingredients: list[str] | None = None
    learning_outcomes: list[str] | None = None


class CartItemBase(BaseModel):
    item_id: int
    name: str
    price: str
    category: str
    image: str
    quantity: int = 1
    type: str
    scheduled_at: datetime | None = None

    @field_validator("price", mode="before")
    @classmethod
    def _coerce_price(cls, value: Any) -> str:
        """Accept numeric inputs for price and normalize to a string."""
        if isinstance(value, str):
            return value
        try:
            return format(Decimal(str(value)), "f")
        except Exception as exc:  # pragma: no cover - defensive guard
            raise ValueError("Invalid price") from exc


class CartItemCreate(CartItemBase):
    pass


class CartItemOut(CartItemBase):
    id: int

    model_config = ConfigDict(from_attributes=True)


class CartSync(BaseModel):
    items: list[CartItemCreate]


class TopProduct(BaseModel):
    name: str
    sales: int
    revenue: float


class RecentActivity(BaseModel):
    description: str
    time: str


class StatsOut(BaseModel):
    users: int
    orders: int
    revenue: float
    active_workshops: int
    top_products: list[TopProduct]
    recent_activity: list[RecentActivity]
    orders_this_month: int
    monthly_growth: float


class InquiryCreate(BaseModel):
    name: str
    email: EmailStr
    phone: str
    workshop_type: str
    participants: int
    preferred_date: str
    message: Optional[str] = None


class InquiryOut(InquiryCreate):
    id: int
    created_at: datetime
    status: str

    model_config = ConfigDict(from_attributes=True)


class InquiryStatusUpdate(BaseModel):
    status: str


class SiteSettingOut(BaseModel):
    key: str
    value: str


class SiteSettingUpdate(BaseModel):
    value: str
