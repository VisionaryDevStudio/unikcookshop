import os
import time
from fastapi import HTTPException
from sqlalchemy.orm import Session

from . import models
from .logger import logger

RATE_LIMIT = int(os.getenv("RATE_LIMIT_LIMIT", "20"))
RATE_PERIOD = int(os.getenv("RATE_LIMIT_PERIOD", "60"))


def _check_rate_limit(
    db: Session,
    key: str,
    limit: int = RATE_LIMIT,
    period: int = RATE_PERIOD,
) -> None:
    """Track requests by key in the database and raise if exceeded."""
    now = time.time()
    window_start = now - period
    db.query(models.RateLimit).filter(models.RateLimit.timestamp < window_start).delete()
    db.commit()
    count = (
        db.query(models.RateLimit)
        .filter(models.RateLimit.key == key, models.RateLimit.timestamp > window_start)
        .count()
    )
    if count >= limit:
        logger.warning("Rate limit exceeded for key %s at %s", key, now)
        raise HTTPException(status_code=429, detail="Too many requests")
    db.add(models.RateLimit(key=key, timestamp=now))
    db.commit()
