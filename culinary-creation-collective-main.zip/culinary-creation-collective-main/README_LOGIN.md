# Local Development

```sh
# Start backend (from repository root)
python -m venv venv && source venv/bin/activate
pip install -r backend/requirements.txt

# (Re)create the SQLite database
python backend/seed.py

uvicorn backend.main:app --reload

# Set Google OAuth client ID for the front-end
export VITE_GOOGLE_CLIENT_ID=<your-client-id>
# Optional: set the same value for backend verification
export GOOGLE_CLIENT_ID=$VITE_GOOGLE_CLIENT_ID
# Stripe publishable key for the front-end
export VITE_STRIPE_PUBLISHABLE_KEY=<your-publishable-key>
# Stripe secret key for payment processing
export STRIPE_SECRET_KEY=<your-stripe-secret>

# Start front-end
npm i
npm run dev
```

The `seed.py` step creates `app.db` with all required tables and sample data. If
you change the models later or encounter an error like `no such column`, remove
`app.db` and rerun `python backend/seed.py` to rebuild the database.
