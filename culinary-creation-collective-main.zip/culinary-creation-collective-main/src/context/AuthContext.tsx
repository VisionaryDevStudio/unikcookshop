import React, { createContext, useContext, useState, ReactNode, useEffect, useRef } from 'react';
import { useGoogleLogin } from '@react-oauth/google';
import api from '@/utils/api';

interface User {
  id: number;
  name: string;
  email: string;
  is_admin: boolean;
  created_at: string;
  image?: string;
  role?: string;
  phone?: string;
  location?: string;
  bio?: string;
  dietary_restrictions?: string;
  cooking_experience?: string;
  favorite_cuisines?: string;
  cooking_goals?: string;
  equipment_available?: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  signup: (name: string, email: string, password: string) => Promise<void>;
  googleLogin: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  changePassword: (current: string, newPassword: string) => Promise<void>;
  isAuthenticated: boolean;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  const logout = () => {
    api.post('/api/auth/logout').finally(() => setUser(null));
  };

  useEffect(() => {
    api
      .post('/api/auth/refresh')
      .then(r => setUser(r.data.user))
      .catch(() => setUser(null));
  }, []);

  const login = async (email: string, password: string) => {
    const res = await api.post('/api/auth/login', { email, password });
    setUser(res.data.user);
  };

  const signup = async (name: string, email: string, password: string) => {
    const res = await api.post('/api/auth/signup', { name, email, password });
    setUser(res.data.user);
  };

  const updateProfile = async (data: Partial<User>) => {
    const res = await api.put('/api/users/me', data);
    setUser(res.data);
  };

  const changePassword = async (current: string, newPassword: string) => {
    await api.post('/api/users/me/password', {
      current_password: current,
      new_password: newPassword,
    });
  };

  const resolveRef = useRef<(() => void) | null>(null);
  const rejectRef = useRef<((err?: unknown) => void) | null>(null);

  const googleLoginHook = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      try {
        const res = await api.post('/api/auth/google', {
          token: tokenResponse.credential ?? (tokenResponse as any).access_token
        });
        setUser(res.data.user);
        resolveRef.current?.();
      } catch (e) {
        rejectRef.current?.(e);
      }
    },
    onError: () => {
      rejectRef.current?.(new Error('Google login failed'));
    }
  });

  const googleLogin = async () => {
    return new Promise<void>((resolve, reject) => {
      resolveRef.current = resolve;
      rejectRef.current = reject;
      googleLoginHook();
    });
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      logout,
      signup,
      googleLogin,
      updateProfile,
      changePassword,
      isAuthenticated: !!user,
      isAdmin: user?.is_admin || false
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
