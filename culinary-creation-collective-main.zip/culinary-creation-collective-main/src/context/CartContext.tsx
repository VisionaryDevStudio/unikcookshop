import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import api from '@/utils/api';
import { toast } from 'sonner';
import { useAuth } from './AuthContext';

export interface CartItem {
  id: number; // product or workshop id
  name: string;
  price: number;
  category: string;
  image: string;
  quantity: number;
  type: 'product' | 'workshop';
  scheduled_at?: string;
  cart_id?: number; // server record id
}

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (item: Omit<CartItem, 'quantity'>) => void;
  removeFromCart: (id: number, type: 'product' | 'workshop', scheduled_at?: string) => void;
  updateQuantity: (id: number, type: 'product' | 'workshop', quantity: number, scheduled_at?: string) => void;
  clearCart: () => void;
  getCartTotal: () => number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartTotal, setCartTotal] = useState<number>(0);
  // API instance with credentials is imported

  useEffect(() => {
    const syncCart = async () => {
      if (user) {
        const items = cartItems.map(i => ({
          item_id: i.id,
          name: i.name,
          price: i.price,
          category: i.category,
          image: i.image,
          quantity: i.quantity,
          type: i.type,
          scheduled_at: i.scheduled_at,
        }));
        try {
          await api.post('/api/cart/sync', { items });
        } catch (err) {
          toast.error('Failed to sync cart', {
            action: {
              label: 'Retry',
              onClick: syncCart
            }
          });
        }
      } else {
        localStorage.setItem('cart', JSON.stringify(cartItems));
      }
    };
    syncCart();
  }, [cartItems, user]);

  useEffect(() => {
    const fetchTotal = async () => {
      if (user) {
        try {
          const r = await api.get('/api/cart/total');
          setCartTotal(r.data.total / 100);
        } catch (err) {
          setCartTotal(0);
          toast.error('Failed to fetch cart total', {
            action: {
              label: 'Retry',
              onClick: fetchTotal
            }
          });
        }
      } else {
        const total = cartItems.reduce(
          (sum, item) => sum + item.price * item.quantity,
          0
        );
        setCartTotal(total);
      }
    };
    fetchTotal();
  }, [cartItems, user]);

  useEffect(() => {
    const fetchCart = async () => {
      if (user) {
        try {
          const r = await api.get('/api/cart');
          const serverItems: CartItem[] = r.data.map((serverItem: any) => ({
            id: serverItem.item_id,
            name: serverItem.name,
            price: serverItem.price,
            category: serverItem.category,
            image: serverItem.image,
            quantity: serverItem.quantity,
            type: serverItem.type,
            scheduled_at: serverItem.scheduled_at,
            cart_id: serverItem.id
          }));
          setCartItems(serverItems);
          localStorage.removeItem('cart');
        } catch (err) {
          toast.error('Failed to load cart', {
            action: {
              label: 'Retry',
              onClick: fetchCart
            }
          });
        }
      } else {
        const stored = localStorage.getItem('cart');
        setCartItems(stored ? JSON.parse(stored) : []);
      }
    };
    fetchCart();
  }, [user]);

  const addToCart = (item: Omit<CartItem, 'quantity'>) => {
    if (user) {
      const payload = {
        item_id: item.id,
        name: item.name,
        price: item.price,
        category: item.category,
        image: item.image,
        quantity: 1,
        type: item.type,
        scheduled_at: item.scheduled_at
      };
      api
        .post('/api/cart/items', payload)
        .then(r => {
          const serverItem = r.data;
          setCartItems(prev => {
            const existingItem = prev.find(
              cartItem =>
                cartItem.id === item.id &&
                cartItem.type === item.type &&
                cartItem.scheduled_at === item.scheduled_at
            );
            if (existingItem) {
              return prev.map(cartItem =>
                cartItem.id === item.id &&
                cartItem.type === item.type &&
                cartItem.scheduled_at === item.scheduled_at
                  ? { ...cartItem, quantity: serverItem.quantity, cart_id: serverItem.id }
                  : cartItem
              );
            }
            return [
              ...prev,
              { ...item, quantity: serverItem.quantity, cart_id: serverItem.id }
            ];
          });
        })
        .catch(() => {
          toast.error('Failed to add item to cart');
        });
    } else {
      setCartItems(prev => {
        const existingItem = prev.find(
          cartItem =>
            cartItem.id === item.id &&
            cartItem.type === item.type &&
            cartItem.scheduled_at === item.scheduled_at
        );
        if (existingItem) {
          return prev.map(cartItem =>
            cartItem.id === item.id &&
            cartItem.type === item.type &&
            cartItem.scheduled_at === item.scheduled_at
              ? { ...cartItem, quantity: cartItem.quantity + 1 }
              : cartItem
          );
        }
        return [...prev, { ...item, quantity: 1 }];
      });
    }
  };

  const removeFromCart = (
    id: number,
    type: 'product' | 'workshop',
    scheduled_at?: string
  ) => {
    if (user) {
      const item = cartItems.find(
        i => i.id === id && i.type === type && i.scheduled_at === scheduled_at
      );
      if (!item || !item.cart_id) return;
      api
        .delete(`/api/cart/items/${item.cart_id}`)
        .then(() => {
          setCartItems(prev =>
            prev.filter(
              cartItem =>
                !(
                  cartItem.id === id &&
                  cartItem.type === type &&
                  cartItem.scheduled_at === scheduled_at
                )
            )
          );
        })
        .catch(() => {
          toast.error('Failed to remove item from cart');
        });
    } else {
      setCartItems(prev =>
        prev.filter(
          item => !(item.id === id && item.type === type && item.scheduled_at === scheduled_at)
        )
      );
    }
  };

  const updateQuantity = (
    id: number,
    type: 'product' | 'workshop',
    quantity: number,
    scheduled_at?: string
  ) => {
    if (quantity <= 0) {
      removeFromCart(id, type, scheduled_at);
      return;
    }
    if (user) {
      const item = cartItems.find(
        i => i.id === id && i.type === type && i.scheduled_at === scheduled_at
      );
      if (!item || !item.cart_id) return;
      const payload = {
        item_id: item.id,
        name: item.name,
        price: item.price,
        category: item.category,
        image: item.image,
        quantity,
        type: item.type,
        scheduled_at: item.scheduled_at
      };
      api
        .put(`/api/cart/items/${item.cart_id}`, payload)
        .then(r => {
          const serverItem = r.data;
          setCartItems(prev =>
            prev.map(cartItem =>
              cartItem.id === id &&
              cartItem.type === type &&
              cartItem.scheduled_at === scheduled_at
                ? {
                    ...cartItem,
                    quantity: serverItem.quantity,
                    cart_id: serverItem.id
                  }
                : cartItem
            )
          );
        })
        .catch(() => {
          toast.error('Failed to update cart item');
        });
    } else {
      setCartItems(prev =>
        prev.map(item =>
          item.id === id && item.type === type && item.scheduled_at === scheduled_at
            ? { ...item, quantity }
            : item
        )
      );
    }
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const getCartTotal = () => cartTotal;

  return (
    <CartContext.Provider value={{
      cartItems,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      getCartTotal
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};