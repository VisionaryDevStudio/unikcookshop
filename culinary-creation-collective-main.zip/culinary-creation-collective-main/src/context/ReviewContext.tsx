import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import api from '@/utils/api';
import { useAuth } from '@/context/AuthContext';

export interface Review {
  id: number;
  item_type: string;
  item_title: string;
  rating: number;
  review: string;
  helpful: number;
  status: 'pending' | 'approved' | 'declined';
  date: string;
  verified_purchase?: boolean;
  verified?: boolean;
}

interface ReviewContextType {
  reviews: Review[];
  addReview: (review: Omit<Review, 'id' | 'date' | 'helpful' | 'status' | 'verified_purchase' | 'verified'>) => void;
  approveReview: (reviewId: number) => void;
  declineReview: (reviewId: number) => void;
  getReviewsForProduct: (title: string) => Review[];
  getPendingReviews: () => Review[];
  markHelpful: (reviewId: number) => void;
}

const ReviewContext = createContext<ReviewContextType | undefined>(undefined);

export const ReviewProvider = ({ children }: { children: ReactNode }) => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const { isAdmin } = useAuth();

  useEffect(() => {
    let isMounted = true;

    const fetchReviews = async () => {
      try {
        const publicRes = await api.get('/api/public/reviews');
        let data: Review[] = publicRes.data;

        if (isAdmin) {
          try {
            const adminRes = await api.get('/api/admin/reviews');
            const merged = new Map<number, Review>();
            data.forEach(r => merged.set(r.id, r));
            adminRes.data.forEach((r: Review) => merged.set(r.id, r));
            data = Array.from(merged.values());
          } catch {
            // ignore admin errors, keep public data
          }
        }

        if (isMounted) {
          setReviews(data);
        }
      } catch {
        // ignore public errors
      }
    };

    fetchReviews();

    return () => {
      isMounted = false;
    };
  }, [isAdmin]);

  const addReview = (
    reviewData: Omit<Review, 'id' | 'date' | 'helpful' | 'status' | 'verified_purchase' | 'verified'>
  ) => {
    const tempId = Date.now();
    const newReview: Review = {
      ...reviewData,
      id: tempId,
      date: new Date().toISOString(),
      helpful: 0,
      status: 'pending',
      verified_purchase: false,
      verified: false
    };
    setReviews(prev => [...prev, newReview]);
    api
      .post('/api/users/reviews', reviewData)
      .then(res => {
        setReviews(prev =>
          prev.map(review =>
            review.id === tempId ? { ...review, id: res.data.id } : review
          )
        );
      })
      .catch(() => {});
  };

  const approveReview = (reviewId: number) => {
    setReviews(prev =>
      prev.map(review =>
        review.id === reviewId ? { ...review, status: 'approved' as const } : review
      )
    );
    api
      .put(`/api/admin/reviews/${reviewId}/status`, { status: 'approved' })
      .catch(() => {});
  };

  const declineReview = (reviewId: number) => {
    setReviews(prev =>
      prev.map(review =>
        review.id === reviewId ? { ...review, status: 'declined' as const } : review
      )
    );
    api
      .put(`/api/admin/reviews/${reviewId}/status`, { status: 'declined' })
      .catch(() => {});
  };

  const getReviewsForProduct = (title: string) => {
    return reviews.filter(
      review =>
        review.item_title === title &&
        review.item_type === 'Product' &&
        review.status === 'approved'
    );
  };

  const getPendingReviews = () => {
    return reviews.filter(review => review.status === 'pending');
  };

  const markHelpful = (reviewId: number) => {
    setReviews(prev => prev.map(review =>
      review.id === reviewId ? { ...review, helpful: review.helpful + 1 } : review
    ));
  };

  return (
    <ReviewContext.Provider value={{
      reviews,
      addReview,
      approveReview,
      declineReview,
      getReviewsForProduct,
      getPendingReviews,
      markHelpful
    }}>
      {children}
    </ReviewContext.Provider>
  );
};

export const useReviews = () => {
  const context = useContext(ReviewContext);
  if (context === undefined) {
    throw new Error('useReviews must be used within a ReviewProvider');
  }
  return context;
};