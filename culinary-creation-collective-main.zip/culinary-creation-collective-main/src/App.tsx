
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import Index from "./pages/Index";
import Workshops from "./pages/Workshops";
import WorkshopDetail from "./pages/WorkshopDetail";
import Shop from "./pages/Shop";
import ProductDetail from "./pages/ProductDetail";
import Booking from "./pages/Booking";
import GroupLessons from "./pages/GroupLessons";
import AboutUs from "./pages/AboutUs";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import AdminDashboard from "./pages/AdminDashboard";
import AdminReviews from "./pages/AdminReviews";
import AdminInquiries from "./pages/AdminInquiries";
import AddWorkshop from "./pages/AddWorkshop";
import AddProduct from "./pages/AddProduct";
import AddAdmin from "./pages/AddAdmin";
import AdminSiteSettings from "./pages/AdminSiteSettings";
import Cart from "./pages/Cart";
import PaymentSuccess from "./pages/PaymentSuccess";
import PaymentCancelled from "./pages/PaymentCancelled";
import ProtectedAdminRoute from "./components/ProtectedAdminRoute";
import ProtectedRoute from "./components/ProtectedRoute";
import { AuthProvider } from "./context/AuthContext";
import { CartProvider } from "./context/CartContext";
import { ReviewProvider } from "./context/ReviewContext";

const queryClient = new QueryClient();
const stripePublishableKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY;

if (!stripePublishableKey) {
  console.warn(
    "VITE_STRIPE_PUBLISHABLE_KEY is not defined. Stripe Elements will be disabled."
  );
}

const stripePromise = stripePublishableKey
  ? loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY!)
  : null;


const App = () => {
  const routes = (
    <>
      <Toaster />
      <Sonner />
      {!stripePublishableKey && (
        <Alert variant="destructive" className="rounded-none">
          <AlertTitle>Payments Unavailable</AlertTitle>
          <AlertDescription>
            Payment processing is currently unavailable.
          </AlertDescription>
        </Alert>
      )}
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/workshops" element={<Workshops />} />
          <Route path="/workshops/:id" element={<WorkshopDetail />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/shop/:id" element={<ProductDetail />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/payment-success" element={<PaymentSuccess />} />
          <Route path="/payment-cancelled" element={<PaymentCancelled />} />
          <Route path="/booking" element={<Booking />} />
          <Route path="/group-lessons" element={<GroupLessons />} />
          <Route path="/about-us" element={<AboutUs />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <Profile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/settings"
            element={
              <ProtectedRoute>
                <Settings />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin"
            element={
              <ProtectedAdminRoute>
                <AdminDashboard />
              </ProtectedAdminRoute>
            }
          />
          <Route
            path="/admin/reviews"
            element={
              <ProtectedAdminRoute>
                <AdminReviews />
              </ProtectedAdminRoute>
            }
          />
          <Route
            path="/admin/inquiries"
            element={
              <ProtectedAdminRoute>
                <AdminInquiries />
              </ProtectedAdminRoute>
            }
          />
          <Route
            path="/admin/site-settings"
            element={
              <ProtectedAdminRoute>
                <AdminSiteSettings />
              </ProtectedAdminRoute>
            }
          />
          <Route
            path="/admin/add-workshop"
            element={
              <ProtectedAdminRoute>
                <AddWorkshop />
              </ProtectedAdminRoute>
            }
          />
          <Route
            path="/admin/add-product"
            element={
              <ProtectedAdminRoute>
                <AddProduct />
              </ProtectedAdminRoute>
            }
          />
          <Route
            path="/admin/add-admin"
            element={
              <ProtectedAdminRoute>
                <AddAdmin />
              </ProtectedAdminRoute>
            }
          />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </>
  );

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ReviewProvider>
          <CartProvider>
            <TooltipProvider>
              {stripePromise ? (
                <Elements stripe={stripePromise}>{routes}</Elements>
              ) : (
                routes
              )}
            </TooltipProvider>
          </CartProvider>
        </ReviewProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;
