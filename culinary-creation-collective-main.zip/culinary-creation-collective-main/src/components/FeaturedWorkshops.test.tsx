import { render, screen, waitFor } from '@testing-library/react';
import axios from 'axios';
import FeaturedWorkshops from './FeaturedWorkshops';
import { vi } from 'vitest';

vi.mock('axios');
vi.mock('@/context/CartContext', () => ({
  useCart: () => ({ addToCart: vi.fn() })
}));

const mockedGet = axios.get as any;

describe('FeaturedWorkshops', () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  it('shows loading state initially', () => {
    mockedGet.mockResolvedValue({ data: [] });
    render(<FeaturedWorkshops />);
    expect(screen.getByText(/loading/i)).toBeInTheDocument();
  });

  it('shows error message on failure', async () => {
    mockedGet.mockRejectedValue(new Error('fail'));
    render(<FeaturedWorkshops />);
    await waitFor(() =>
      expect(screen.getByText(/failed to load workshops/i)).toBeInTheDocument()
    );
  });

  it('shows empty state when no workshops', async () => {
    mockedGet.mockResolvedValue({ data: [] });
    render(<FeaturedWorkshops />);
    await waitFor(() =>
      expect(screen.getByText(/no workshops available/i)).toBeInTheDocument()
    );
  });

  it('renders workshop timezone regardless of user timezone', async () => {
    mockedGet.mockResolvedValue({
      data: [
        {
          id: 1,
          title: 'WS',
          date: '2023-01-01T15:00:00Z',
          instructor: 'Chef',
          location: 'Culinary Studio A',
        },
      ],
    });
    vi
      .spyOn(Intl.DateTimeFormat.prototype, 'resolvedOptions')
      .mockReturnValue({ timeZone: 'Asia/Tokyo' } as Intl.ResolvedDateTimeFormatOptions);
    render(<FeaturedWorkshops />);
    await waitFor(() =>
      expect(screen.getByText(/America\/New_York/)).toBeInTheDocument()
    );
  });
});
