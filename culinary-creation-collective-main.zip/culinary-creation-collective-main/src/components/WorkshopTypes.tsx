
import { Calendar, Users, Heart, UserPlus, Building2, Rocket } from "lucide-react";
import { Link } from "react-router-dom";

interface WorkshopType {
  id: number;
  title: string;
  description: string;
  icon: string;
  link: string;
}

const iconMap: Record<string, JSX.Element> = {
  Users: <Users className="h-10 w-10 text-culinary-terracotta" />,
  UserPlus: <UserPlus className="h-10 w-10 text-culinary-sage" />,
  Heart: <Heart className="h-10 w-10 text-culinary-berry" />,
  Calendar: <Calendar className="h-10 w-10 text-culinary-butter" />,
  Building2: <Building2 className="h-10 w-10 text-culinary-navy" />,
  Rocket: <Rocket className="h-10 w-10 text-culinary-terracotta" />,
};

interface WorkshopTypesProps {
  types: WorkshopType[];
}
const WorkshopTypes = ({ types }: WorkshopTypesProps) => {
  return (
    <section className="py-16 bg-culinary-cream">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-culinary-navy">Explore Our Workshop Types</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Find the perfect cooking experience that matches your interests, schedule, and learning style
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {types.map((type) => (
            <Link
              key={type.id}
              to={type.link}
              className="workshop-card p-6 flex flex-col items-start hover:border-culinary-terracotta"
            >
              <div className="mb-4">
                {iconMap[type.icon]}
              </div>
              <h3 className="text-xl font-semibold mb-2 text-culinary-navy">{type.title}</h3>
              <p className="text-gray-600 mb-4">{type.description}</p>
              <div className="mt-auto text-culinary-terracotta font-medium">
                Learn more →
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WorkshopTypes;
