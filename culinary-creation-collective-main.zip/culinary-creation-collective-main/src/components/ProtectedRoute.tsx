import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { toast } from "sonner";
import { useEffect, useState } from "react";
import api from "@/utils/api";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const { user } = useAuth();
  const location = useLocation();
  const [valid, setValid] = useState<boolean | null>(null);

  useEffect(() => {
    const check = async () => {
      try {
        await api.get('/api/users/me');
        setValid(true);
      } catch {
        setValid(false);
      }
    };
    check();
  }, []);

  // wait for auth check and user state to resolve before making a decision
  if (valid === null || (valid && !user)) return null;

  if (!valid) {
    toast.error('You must be logged in to access this page');
    return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
