import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ShoppingBag } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { useCart } from "@/context/CartContext";
import axios from "axios";

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  rating?: number | null;
  review_count?: number;
}

const ShopPreview = () => {
  const { addToCart } = useCart();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    axios
      .get(`${import.meta.env.VITE_API_BASE_URL}/api/public/products`)
      .then((r) => {
        const data = Array.isArray(r.data)
          ? r.data
          : Array.isArray(r.data?.data)
            ? r.data.data
            : [];
        setProducts(data);
        setLoading(false);
      })
      .catch(() => {
        setError("Failed to load products");
        setLoading(false);
      });
  }, []);

  const handleAddToCart = (product: Product) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      category: "Product",
      image: product.image,
      type: "product",
    });
    toast.success(`${product.name} added to cart`);
  };

  if (loading) {
    return <div className="py-16 text-center">Loading...</div>;
  }

  if (error) {
    return <div className="py-16 text-center text-red-500">{error}</div>;
  }

  if (products.length === 0) {
    return <div className="py-16 text-center">No products available</div>;
  }

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-culinary-navy">Culinary Shop</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Take your cooking to the next level with our curated selection of premium ingredients and tools
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {products.map((product) => (
            <Link
              key={product.id}
              to={`/shop/${product.id}`}
              className="workshop-card overflow-hidden block"
            >
              <div className="h-48 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold mb-2 text-culinary-navy">{product.name}</h3>
                {product.rating !== null && (
                  <div className="flex items-center gap-1 mb-1">
                    {[...Array(5)].map((_, i) => (
                      <span
                        key={i}
                        className={`h-4 w-4 inline-block ${product.rating && i < Math.floor(product.rating) ? 'text-yellow-400' : 'text-gray-300'}`}
                      >★</span>
                    ))}
                    <span className="text-xs text-gray-600 ml-1">({product.review_count || 0})</span>
                  </div>
                )}
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-culinary-navy">${product.price.toFixed(2)}</span>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-culinary-terracotta hover:text-culinary-terracotta/90 hover:bg-culinary-cream"
                    onClick={(e) => {
                      e.preventDefault();
                      handleAddToCart(product);
                    }}
                  >
                    <ShoppingBag className="h-4 w-4 mr-1" />
                    Add to Cart
                  </Button>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link to="/shop">
            <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90 btn-culinary">
              Visit Shop
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ShopPreview;
