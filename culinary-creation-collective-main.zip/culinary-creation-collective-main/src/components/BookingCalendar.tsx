import { useState, useEffect } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Users, 
  ChefHat,
  MapPin,
  Globe
} from "lucide-react";
import { format, addHours } from "date-fns";
import { Badge } from "@/components/ui/badge";
import axios from "axios";
import { useCart } from "@/context/CartContext";
import { formatUserTime, formatUserDate, getTimeZoneForLocation } from "@/utils/timezone";
import { toast } from "sonner";

interface WorkshopEvent {
  id: number;
  title: string;
  date: Date;
  startTime: string;
  endTime: string;
  timeZone: string;
  spots: number | null;
  chef: string;
  location: string;
  description: string;
  price?: number;
  image?: string | null;
}

interface BookingCalendarProps {
  onRequestCustom?: () => void;
}

const BookingCalendar = ({ onRequestCustom }: BookingCalendarProps) => {
  const { addToCart } = useCart();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [events, setEvents] = useState<WorkshopEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [userTimeZone, setUserTimeZone] = useState<string>("");
  const [timeZoneOffset, setTimeZoneOffset] = useState<string>("");

  useEffect(() => {
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    setUserTimeZone(timezone);
    
    const offset = new Date().getTimezoneOffset();
    const hours = Math.abs(Math.floor(offset / 60));
    const minutes = Math.abs(offset % 60);
    const sign = offset < 0 ? "+" : "-";
    setTimeZoneOffset(`GMT${sign}${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`);
  }, []);

  useEffect(() => {
    axios
      .get(`${import.meta.env.VITE_API_BASE_URL}/api/public/workshops/upcoming`)
      .then((r) => {
        const data = r.data.map((w: any) => {
          const d = new Date(w.date);
          const tz = getTimeZoneForLocation(w.location) || Intl.DateTimeFormat().resolvedOptions().timeZone;
          return {
            id: w.id,
            title: w.title,
            date: d,
            startTime: formatUserTime(d, {}, tz),
            endTime: formatUserTime(addHours(d, 2), {}, tz),
            timeZone: tz,
            spots: w.spots ?? null,
            chef: w.instructor,
            location: w.location,
            price: w.price,
            description: w.description || "Description coming soon.",
            image: w.image || null,

          } as WorkshopEvent;
        });
        setEvents(data);
        setLoading(false);
      })
      .catch(() => {
        setError(true);
        setLoading(false);
      });
  }, []);

  const selectedDateEvents = date 
    ? events.filter(event => 
        event.date.getDate() === date.getDate() && 
        event.date.getMonth() === date.getMonth() && 
        event.date.getFullYear() === date.getFullYear()
      )
    : [];

  const formatTimeRange = (startTime: string, endTime: string) => {
    return `${startTime} - ${endTime}`;
  };

  const getDaysWithEvents = () => {
    return events.map(event => new Date(event.date));
  };

  const handleBookClass = (event: WorkshopEvent) => {
    addToCart({
      id: event.id,
      name: event.title,
      price: Number(event.price ?? 0),
      category: "Workshop",
      image: event.image || "",
      type: "workshop",
      scheduled_at: event.date.toISOString(),
    });
    toast.success(`${event.title} added to cart`);
  };

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <div>
        <div className="bg-white rounded-lg shadow-md border border-culinary-cream">
          <div className="flex items-center p-3 border-b border-culinary-cream">
            <CalendarIcon className="h-5 w-5 mr-2 text-culinary-terracotta" />
            <h3 className="text-lg font-semibold text-culinary-navy">Select a Date</h3>
          </div>
          
          {userTimeZone && (
            <div className="px-3 py-2 flex items-center text-sm text-gray-600">
              <Globe className="h-4 w-4 mr-1 text-culinary-sage" />
              <span>{userTimeZone} ({timeZoneOffset})</span>
            </div>
          )}
          
          <div className="flex justify-center">
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              className="compact-calendar"
              defaultMonth={new Date()}
              modifiers={{
                booked: getDaysWithEvents(),
              }}
              modifiersStyles={{
                booked: {
                  fontWeight: "bold",
                  border: "2px solid #84A59D",
                  color: "#84A59D"
                }
              }}
            />
          </div>
          
          <div className="p-3 border-t border-culinary-cream">
            <div className="flex items-center text-sm text-gray-600">
              <div className="w-4 h-4 rounded-full border-2 border-culinary-sage mr-2"></div>
              <span>Days with scheduled workshops</span>
            </div>
          </div>
        </div>
      </div>

      <div>
        <div className="bg-white rounded-lg shadow-md border border-culinary-cream h-full">
          <div className="flex items-center p-3 border-b border-culinary-cream">
            <ChefHat className="h-5 w-5 mr-2 text-culinary-terracotta" />
            <h3 className="text-lg font-semibold text-culinary-navy">
              Available Workshops {date && `on ${format(date, 'MMMM d, yyyy')}`}
            </h3>
          </div>

          <div className="p-3 overflow-y-auto max-h-[500px]">
            {loading ? (
              <div className="text-center text-sm text-gray-600">Loading workshops...</div>
            ) : error ? (
              <div className="text-center text-sm text-red-500">Failed to load events.</div>
            ) : selectedDateEvents.length > 0 ? (
              <div className="space-y-4">
                {selectedDateEvents.map(event => (
                  <Card key={event.id} className="workshop-card overflow-hidden border-culinary-cream">
                    <CardContent className="p-0">
                      <div className="bg-culinary-navy text-white p-2">
                        <h4 className="text-base font-semibold">{event.title}</h4>
                      </div>
                      
                      <div className="p-3">
                        <div className="mb-2">
                          <p className="text-sm text-gray-600">{event.description || "Description coming soon."}</p>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2 mb-3">
                          <div className="space-y-1 text-sm">
                            <div className="flex items-center">
                              <CalendarIcon className="h-4 w-4 mr-1 text-culinary-terracotta" />
                              <span>{formatUserDate(event.date, { dateStyle: 'medium' }, event.timeZone)}</span>
                            </div>
                            <div className="flex items-center">
                              <Clock className="h-4 w-4 mr-1 text-culinary-terracotta" />
                              <span>{`${formatTimeRange(event.startTime, event.endTime)} (${event.timeZone})`}</span>
                            </div>
                          </div>
                          
                          <div className="space-y-1 text-sm">
                            <div className="flex items-center">
                              <ChefHat className="h-4 w-4 mr-1 text-culinary-terracotta" />
                              <span>{event.chef}</span>
                            </div>
                            <div className="flex items-center">
                              <MapPin className="h-4 w-4 mr-1 text-culinary-terracotta" />
                              <span>{event.location}</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <Badge variant="outline" className="bg-culinary-cream text-culinary-navy">
                            <Users className="h-3 w-3 mr-1" />
                            {event.spots !== null && event.spots !== undefined
                              ? `${event.spots} spots available`
                              : "Spots TBD"}
                          </Badge>
                          
                          <Button
                            className="bg-culinary-sage hover:bg-culinary-sage/90 text-xs px-3 py-1 h-auto"
                            onClick={() => handleBookClass(event)}
                          >
                            Book This Class
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="bg-culinary-cream rounded-lg p-4 text-center">
                <p className="text-gray-600 mb-2">No workshops available on this date.</p>
                <p className="text-sm">Please select another date or check our upcoming events.</p>
                
                <div className="mt-3 p-3 border border-dashed border-gray-300 rounded-lg">
                  <h4 className="text-culinary-navy font-medium mb-1 text-sm">Need a custom workshop?</h4>
                  <p className="text-xs text-gray-600 mb-2">
                    Can't find a suitable time or course? We can arrange a customized workshop for you!
                  </p>
                  <Button
                    variant="outline"
                    className="text-culinary-terracotta border-culinary-terracotta hover:bg-culinary-terracotta/10 text-xs px-3 py-1 h-auto"
                    onClick={onRequestCustom}
                  >
                    Request Custom Workshop
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingCalendar;
