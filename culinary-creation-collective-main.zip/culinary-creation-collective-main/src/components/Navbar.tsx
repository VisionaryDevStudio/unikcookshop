
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X, ChefHat, ShoppingBag, LogIn, LogOut, User } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/context/CartContext";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout, isAdmin } = useAuth();
  const { cartItems } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const getTotalCartItems = () => {
    return cartItems.reduce((total, item) => total + item.quantity, 0);
  };

  return (
    <nav className="bg-white sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <ChefHat className="h-8 w-8 text-culinary-terracotta" />
            <span className="text-xl font-bold text-culinary-navy">Unikcookshop</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-culinary-navy hover:text-culinary-terracotta transition-colors font-medium">
              Home
            </Link>
            <Link to="/workshops" className="text-culinary-navy hover:text-culinary-terracotta transition-colors font-medium">
              Workshops
            </Link>
            <Link to="/booking" className="text-culinary-navy hover:text-culinary-terracotta transition-colors font-medium">
              Book Now
            </Link>
            <Link to="/shop" className="text-culinary-navy hover:text-culinary-terracotta transition-colors font-medium">
              Shop
            </Link>
            <Link to="/cart">
              <Button variant="outline" size="icon" className="relative">
                <ShoppingBag className="h-5 w-5" />
                {getTotalCartItems() > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-culinary-terracotta text-xs text-white">
                    {getTotalCartItems()}
                  </span>
                )}
              </Button>
            </Link>
            
            {user ? (
              <>
                <Link to={isAdmin ? "/admin" : "/dashboard"}>
                  <Button variant="outline" className="flex items-center gap-1">
                    <User className="h-4 w-4" />
                    <span>{isAdmin ? "Admin" : "Dashboard"}</span>
                  </Button>
                </Link>
                <Button variant="ghost" onClick={handleLogout} className="flex items-center gap-1">
                  <LogOut className="h-4 w-4" />
                  <span>Logout</span>
                </Button>
              </>
            ) : (
              <Link to="/login">
                <Button variant="outline" className="flex items-center gap-1">
                  <LogIn className="h-4 w-4" />
                  <span>Sign In</span>
                </Button>
              </Link>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={toggleMenu}>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden pt-4 pb-3 space-y-2 animate-fade-in">
            <Link
              to="/"
              className="block px-4 py-2 text-culinary-navy hover:bg-culinary-cream rounded-md"
              onClick={toggleMenu}
            >
              Home
            </Link>
            <Link
              to="/workshops"
              className="block px-4 py-2 text-culinary-navy hover:bg-culinary-cream rounded-md"
              onClick={toggleMenu}
            >
              Workshops
            </Link>
            <Link
              to="/booking"
              className="block px-4 py-2 text-culinary-navy hover:bg-culinary-cream rounded-md"
              onClick={toggleMenu}
            >
              Book Now
            </Link>
            <Link
              to="/shop"
              className="block px-4 py-2 text-culinary-navy hover:bg-culinary-cream rounded-md"
              onClick={toggleMenu}
            >
              Shop
            </Link>
            <div className="px-4 pt-2">
              <Link to="/cart" className="flex items-center space-x-2">
                <Button variant="outline" size="icon" className="relative">
                  <ShoppingBag className="h-5 w-5" />
                  {getTotalCartItems() > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-culinary-terracotta text-xs text-white">
                      {getTotalCartItems()}
                    </span>
                  )}
                </Button>
                <span>View Cart</span>
              </Link>
            </div>
            
            {user ? (
              <>
                <div className="px-4 pt-2">
                  <Link 
                    to={isAdmin ? "/admin" : "/dashboard"} 
                    className="block px-4 py-2 text-culinary-navy hover:bg-culinary-cream rounded-md"
                    onClick={toggleMenu}
                  >
                    {isAdmin ? "Admin Dashboard" : "Dashboard"}
                  </Link>
                </div>
                <div className="px-4">
                  <Button 
                    variant="ghost" 
                    onClick={() => {
                      handleLogout();
                      toggleMenu();
                    }}
                    className="block px-4 py-2 text-culinary-navy hover:bg-culinary-cream rounded-md w-full text-left"
                  >
                    Logout
                  </Button>
                </div>
              </>
            ) : (
              <>
                <div className="px-4 pt-2">
                  <Link 
                    to="/login" 
                    className="block px-4 py-2 text-culinary-navy hover:bg-culinary-cream rounded-md"
                    onClick={toggleMenu}
                  >
                    Sign In
                  </Link>
                </div>
                <div className="px-4">
                  <Link 
                    to="/signup" 
                    className="block px-4 py-2 text-culinary-navy hover:bg-culinary-cream rounded-md"
                    onClick={toggleMenu}
                  >
                    Sign Up
                  </Link>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
