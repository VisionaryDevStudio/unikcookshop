import { render, screen, waitFor } from '@testing-library/react';
import axios from 'axios';
import ShopPreview from './ShopPreview';
import { vi } from 'vitest';

vi.mock('axios');
vi.mock('@/context/CartContext', () => ({
  useCart: () => ({ addToCart: vi.fn() })
}));

const mockedGet = axios.get as any;

describe('ShopPreview', () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  it('shows loading state initially', () => {
    mockedGet.mockResolvedValue({ data: [] });
    render(<ShopPreview />);
    expect(screen.getByText(/loading/i)).toBeInTheDocument();
  });

  it('shows error message on failure', async () => {
    mockedGet.mockRejectedValue(new Error('fail'));
    render(<ShopPreview />);
    await waitFor(() =>
      expect(screen.getByText(/failed to load products/i)).toBeInTheDocument()
    );
  });

  it('shows empty state when no products', async () => {
    mockedGet.mockResolvedValue({ data: [] });
    render(<ShopPreview />);
    await waitFor(() =>
      expect(screen.getByText(/no products available/i)).toBeInTheDocument()
    );
  });
});
