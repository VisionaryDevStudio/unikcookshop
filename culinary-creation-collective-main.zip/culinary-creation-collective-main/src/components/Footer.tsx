
import { Link } from "react-router-dom";
import { 
  Facebook, 
  Instagram, 
  Twitter, 
  Youtube, 
  Mail, 
  Phone, 
  MapPin,
  ChefHat,
  Info
} from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-culinary-navy text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <ChefHat className="h-6 w-6 text-culinary-butter" />
              <span className="text-xl font-bold">Unikcookshop</span>
            </div>
            <p className="text-gray-300 mb-4">
              Discover the joy of cooking with our diverse culinary workshops and quality cooking products.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/workshops" className="text-gray-300 hover:text-white transition-colors">
                  Workshops
                </Link>
              </li>
              <li>
                <Link to="/booking" className="text-gray-300 hover:text-white transition-colors">
                  Book Now
                </Link>
              </li>
              <li>
                <Link to="/shop" className="text-gray-300 hover:text-white transition-colors">
                  Shop
                </Link>
              </li>
              <li>
                <Link to="/about-us" className="text-gray-300 hover:text-white transition-colors flex items-center gap-1">
                  <Info className="h-4 w-4" />
                  About Us
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Workshop Types</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/workshops?type=group" className="text-gray-300 hover:text-white transition-colors">
                  Group Lessons
                </Link>
              </li>
              <li>
                <Link to="/workshops?type=kids" className="text-gray-300 hover:text-white transition-colors">
                  Kids Workshops
                </Link>
              </li>
              <li>
                <Link to="/workshops?type=date-night" className="text-gray-300 hover:text-white transition-colors">
                  Date Night
                </Link>
              </li>
              <li>
                <Link to="/workshops?type=private" className="text-gray-300 hover:text-white transition-colors">
                  Private Sessions
                </Link>
              </li>
              <li>
                <Link to="/workshops?type=team-building" className="text-gray-300 hover:text-white transition-colors">
                  Team Building
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 mt-0.5 text-culinary-terracotta" />
                <span className="text-gray-300">
                  123 Culinary Street<br />
                  Foodville, FC 12345
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-2 text-culinary-terracotta" />
                <span className="text-gray-300">(123) 456-7890</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-2 text-culinary-terracotta" />
                <span className="text-gray-300">info@unikcookshop.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-6 mt-6 text-center">
          <p className="text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} Unikcookshop. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
