import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { PaymentModal } from './PaymentModal';
import { vi } from 'vitest';
import axios from 'axios';
import { toast } from 'sonner';

vi.mock('@/context/CartContext', () => ({
  useCart: () => ({
    cartItems: [{ id: 1, name: 'Workshop', price: 10, quantity: 1 }],
  }),
}));

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn(), info: vi.fn() },
}));

const mockStripe = { confirmCardPayment: vi.fn() } as any;
const mockElements = { getElement: vi.fn() } as any;

vi.mock('@stripe/react-stripe-js', () => ({
  CardElement: (props: any) => <div data-testid="card-element" {...props} />,
  useStripe: () => mockStripe,
  useElements: () => mockElements,
}));

const mockApi = {
  get: vi.fn(),
  post: vi.fn(),
  interceptors: { request: { use: vi.fn() } },
} as any;

vi.spyOn(axios, 'create').mockReturnValue(mockApi);

describe('PaymentModal', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockApi.get.mockReset();
    mockApi.post.mockReset();
    mockStripe.confirmCardPayment.mockReset();
    mockElements.getElement.mockReset();
    // Ensure Stripe is considered enabled for these tests
    import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY = 'test';
  });

  const fillCommonFields = () => {
    fireEvent.change(screen.getByLabelText(/Email Address/i), {
      target: { value: 'test@example.com' },
    });
    fireEvent.change(screen.getByLabelText(/Cardholder Name/i), {
      target: { value: 'John Doe' },
    });
    fireEvent.change(screen.getByLabelText(/Billing Address/i), {
      target: { value: '123 Street' },
    });
    fireEvent.change(screen.getByLabelText(/^City/i), {
      target: { value: 'NYC' },
    });
    fireEvent.change(screen.getByLabelText(/Postal Code/i), {
      target: { value: '10001' },
    });
    fireEvent.change(screen.getByLabelText(/Country/i), {
      target: { value: 'US' },
    });
    fireEvent.click(
      screen.getByText(/I agree to the Terms of Service and Privacy Policy/i)
    );
  };

  it('blocks submission when terms are not accepted', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] });

    render(
      <PaymentModal
        isOpen
        onClose={() => {}}
        onPaymentComplete={() => {}}
      />
    );

    await screen.findByText(/Total Amount/i);
    fillCommonFields();
    fireEvent.click(
      screen.getByText(/I agree to the Terms of Service and Privacy Policy/i)
    );
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await screen.findByText('You must accept the terms and conditions');
    expect(mockStripe.confirmCardPayment).not.toHaveBeenCalled();
    expect(mockApi.post).not.toHaveBeenCalled();
  });

  it('shows validation error for invalid country code', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] });

    render(
      <PaymentModal
        isOpen
        onClose={() => {}}
        onPaymentComplete={() => {}}
      />
    );

    await screen.findByText(/Total Amount/i);
    fillCommonFields();
    fireEvent.change(screen.getByLabelText(/Country/i), {
      target: { value: 'USA' },
    });
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await screen.findByText('کد کشور معتبر نیست');
  });

  it('handles successful payment', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post
      .mockResolvedValueOnce({ data: { client_secret: 'secret', amount: 5000 } })
      .mockResolvedValueOnce({ data: [] });
    mockElements.getElement.mockReturnValue({});
    mockStripe.confirmCardPayment.mockResolvedValueOnce({
      paymentIntent: { id: 'pi_1', status: 'succeeded' },
    });

    const onComplete = vi.fn();
    const onClose = vi.fn();

    render(
      <PaymentModal isOpen onClose={onClose} onPaymentComplete={onComplete} />
    );

    await screen.findByText(/Total Amount/i);
    fillCommonFields();
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await waitFor(() => expect(onComplete).toHaveBeenCalled());
    expect(mockStripe.confirmCardPayment).toHaveBeenCalledWith(
      'secret',
      expect.objectContaining({ payment_method: expect.any(Object) })
    );
  });

  it('trims whitespace from input fields before submitting', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post
      .mockResolvedValueOnce({ data: { client_secret: 'secret', amount: 5000 } })
      .mockResolvedValueOnce({ data: [] });
    mockElements.getElement.mockReturnValue({});
    mockStripe.confirmCardPayment.mockResolvedValueOnce({
      paymentIntent: { id: 'pi_1', status: 'succeeded' },
    });

    render(
      <PaymentModal isOpen onClose={() => {}} onPaymentComplete={() => {}} />
    );

    await screen.findByText(/Total Amount/i);

    fireEvent.change(screen.getByLabelText(/Email Address/i), {
      target: { value: 'test@example.com' },
    });
    fireEvent.change(screen.getByLabelText(/Cardholder Name/i), {
      target: { value: '  John Doe  ' },
    });
    fireEvent.change(screen.getByLabelText(/Billing Address/i), {
      target: { value: '  123 Street  ' },
    });
    fireEvent.change(screen.getByLabelText(/^City/i), {
      target: { value: '  NYC  ' },
    });
    fireEvent.change(screen.getByLabelText(/Postal Code/i), {
      target: { value: ' 10001  ' },
    });
    fireEvent.change(screen.getByLabelText(/Country/i), {
      target: { value: ' us ' },
    });
    fireEvent.click(
      screen.getByText(/I agree to the Terms of Service and Privacy Policy/i)
    );

    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await waitFor(() =>
      expect(mockStripe.confirmCardPayment).toHaveBeenCalled()
    );

    expect(mockStripe.confirmCardPayment).toHaveBeenCalledWith(
      'secret',
      expect.objectContaining({
        payment_method: expect.objectContaining({
          billing_details: expect.objectContaining({
            name: 'John Doe',
            address: expect.objectContaining({
              line1: '123 Street',
              city: 'NYC',
              postal_code: '10001',
              country: 'US',
            }),
          }),
        }),
      })
    );
  });

  it('shows card error message', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post
      .mockResolvedValueOnce({ data: { client_secret: 'pi_err_secret', amount: 5000 } })
      .mockResolvedValueOnce({});
    mockElements.getElement.mockReturnValue({});
    mockStripe.confirmCardPayment.mockResolvedValueOnce({
      error: {
        type: 'card_error',
        message: 'Your card was declined',
        payment_intent: { id: 'pi_err' },
      },
    });

    const onFailure = vi.fn();

    render(
      <PaymentModal
        isOpen
        onClose={() => {}}
        onPaymentComplete={() => {}}
        onPaymentFailure={onFailure}
      />
    );

    await screen.findByText(/Total Amount/i);
    fillCommonFields();
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await screen.findByText(
      'Your card was declined. Please try another payment method.'
    );
    expect(screen.queryByText(/contact support/i)).toBeNull();
    expect(onFailure).toHaveBeenCalledWith('pi_err');
    expect(mockApi.post).toHaveBeenNthCalledWith(2, '/api/cart/cancel-payment-intent', {
      payment_intent_id: 'pi_err',
    });
    expect(toast.success).toHaveBeenCalledWith('Payment canceled');
  });

  it('shows network error message', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post.mockResolvedValueOnce({ data: { client_secret: 'secret', amount: 5000 } });
    mockElements.getElement.mockReturnValue({});
    mockStripe.confirmCardPayment.mockResolvedValueOnce({
      error: { type: 'api_connection_error' },
    });

    render(
      <PaymentModal
        isOpen
        onClose={() => {}}
        onPaymentComplete={() => {}}
      />
    );

    await screen.findByText(/Total Amount/i);
    fillCommonFields();
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await screen.findByText(
      'Network error. Please check your connection and try again.'
    );
  });

  it('provides support link for unrecoverable errors', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post.mockResolvedValueOnce({ data: { client_secret: 'secret', amount: 5000 } });
    mockElements.getElement.mockReturnValue({});
    mockStripe.confirmCardPayment.mockResolvedValueOnce({
      error: { type: 'api_error' },
    });

    render(
      <PaymentModal
        isOpen
        onClose={() => {}}
        onPaymentComplete={() => {}}
      />
    );

    await screen.findByText(/Total Amount/i);
    fillCommonFields();
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await screen.findByText('A technical error occurred. Please contact support.');
    await screen.findByText(/contact support/i);
  });

  it('shows support link when payment intent status is unknown', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post.mockResolvedValueOnce({ data: { client_secret: 'secret', amount: 5000 } });
    mockElements.getElement.mockReturnValue({});
    mockStripe.confirmCardPayment.mockResolvedValueOnce({
      paymentIntent: { id: 'pi_1', status: 'processing' },
    });

    render(
      <PaymentModal
        isOpen
        onClose={() => {}}
        onPaymentComplete={() => {}}
      />
    );

    await screen.findByText(/Total Amount/i);
    fillCommonFields();
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await screen.findByText('A technical error occurred. Please contact support.');
    await screen.findByText(/contact support/i);
  });

  it('allows selecting a saved card', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({
        data: [
          {
            id: 1,
            stripe_pm_id: 'pm_1',
            brand: 'visa',
            last4: '4242',
            expiry: '12/24',
            is_primary: false,
          },
        ],
      })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post
      .mockResolvedValueOnce({ data: { client_secret: 'secret', amount: 5000 } })
      .mockResolvedValueOnce({ data: [] });
    mockStripe.confirmCardPayment.mockResolvedValueOnce({
      paymentIntent: { id: 'pi_1', status: 'succeeded' },
    });

    const onComplete = vi.fn();

    render(
      <PaymentModal isOpen onClose={() => {}} onPaymentComplete={onComplete} />
    );

    await screen.findByLabelText(/visa/i);
    fireEvent.click(screen.getByLabelText(/visa/i));
    expect(
      screen.queryByLabelText(/Cardholder Name/i)
    ).not.toBeInTheDocument();
    fireEvent.change(screen.getByLabelText(/Email Address/i), {
      target: { value: 'test@example.com' },
    });
    fireEvent.click(
      screen.getByText(/I agree to the Terms of Service and Privacy Policy/i)
    );
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await waitFor(() => expect(onComplete).toHaveBeenCalled());
    expect(mockStripe.confirmCardPayment).toHaveBeenCalledWith('secret', {
      payment_method: 'pm_1',
    });
    expect(mockElements.getElement).not.toHaveBeenCalled();
  });

  it('handles 3D Secure authentication when required', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post
      .mockResolvedValueOnce({ data: { client_secret: 'secret', amount: 5000 } })
      .mockResolvedValueOnce({ data: [] });
    mockElements.getElement.mockReturnValue({});
    mockStripe.confirmCardPayment
      .mockResolvedValueOnce({
        paymentIntent: {
          id: 'pi_1',
          status: 'requires_action',
          client_secret: 'secret',
        },
      })
      .mockResolvedValueOnce({
        paymentIntent: { id: 'pi_1', status: 'succeeded' },
      });

    const onComplete = vi.fn();
    render(
      <PaymentModal isOpen onClose={() => {}} onPaymentComplete={onComplete} />
    );

    await screen.findByText(/Total Amount/i);
    fillCommonFields();
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await waitFor(() => expect(onComplete).toHaveBeenCalled());
    expect(mockStripe.confirmCardPayment).toHaveBeenNthCalledWith(
      1,
      'secret',
      expect.objectContaining({ payment_method: expect.any(Object) })
    );
    expect(mockStripe.confirmCardPayment).toHaveBeenNthCalledWith(2, 'secret');
  });

  it('shows authentication error when 3D Secure fails', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post.mockResolvedValueOnce({ data: { client_secret: 'secret', amount: 5000 } });
    mockElements.getElement.mockReturnValue({});
    mockStripe.confirmCardPayment
      .mockResolvedValueOnce({
        paymentIntent: {
          id: 'pi_1',
          status: 'requires_action',
          client_secret: 'secret',
        },
      })
      .mockResolvedValueOnce({
        error: { type: 'authentication_error' },
      });

    render(
      <PaymentModal isOpen onClose={() => {}} onPaymentComplete={() => {}} />
    );

    await screen.findByText(/Total Amount/i);
    fillCommonFields();
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await screen.findByText(
      'Authentication failed. Please try again or use a different card.'
    );
  });

  it('handles payment intent creation failure and re-enables the pay button', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post.mockRejectedValueOnce({ code: 'ERR_NETWORK' });
    mockElements.getElement.mockReturnValue({});

    const onFailure = vi.fn();
    render(
      <PaymentModal
        isOpen
        onClose={() => {}}
        onPaymentComplete={() => {}}
        onPaymentFailure={onFailure}
      />
    );

    await screen.findByText(/Total Amount/i);
    fillCommonFields();
    const payButton = screen.getByRole('button', { name: /Pay/i });
    fireEvent.click(payButton);

    await waitFor(() => expect(payButton).toBeDisabled());
    await screen.findByText(
      'Network error. Please check your connection and try again.'
    );
    expect(onFailure).toHaveBeenCalled();
    await waitFor(() => expect(payButton).not.toBeDisabled());
  });

  it('shows cart empty message when cart is empty', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post.mockRejectedValueOnce({
      isAxiosError: true,
      response: { status: 400, data: { detail: 'Cart is empty' } },
    });
    mockElements.getElement.mockReturnValue({});

    const onFailure = vi.fn();
    render(
      <PaymentModal
        isOpen
        onClose={() => {}}
        onPaymentComplete={() => {}}
        onPaymentFailure={onFailure}
      />
    );

    await screen.findByText(/Total Amount/i);
    fillCommonFields();
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await screen.findByText('سبد خرید خالی است');
    expect(onFailure).toHaveBeenCalled();
  });

  it('updates total when payment intent returns a different amount', async () => {
    mockApi.get
      .mockResolvedValueOnce({ data: { total: 5000 } })
      .mockResolvedValueOnce({ data: [] });
    mockApi.post
      .mockResolvedValueOnce({ data: { client_secret: 'secret', amount: 6000 } })
      .mockResolvedValueOnce({ data: [] });
    mockElements.getElement.mockReturnValue({});
    mockStripe.confirmCardPayment.mockResolvedValueOnce({
      paymentIntent: { id: 'pi_1', status: 'succeeded' },
    });

    render(
      <PaymentModal isOpen onClose={() => {}} onPaymentComplete={() => {}} />
    );

    await screen.findByText('$50.00');
    fillCommonFields();
    fireEvent.click(screen.getByRole('button', { name: /Pay/i }));

    await screen.findByText('$60.00');
  });
});

