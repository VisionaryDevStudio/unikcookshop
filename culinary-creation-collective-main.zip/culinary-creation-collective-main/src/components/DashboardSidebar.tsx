import {
  BookOpen,
  Calendar,
  Home,
  Settings,
  User,
  Package,
  CreditCard,
  Star,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Skeleton } from "@/components/ui/skeleton";

interface DashboardSidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const DashboardSidebar = ({
  activeTab,
  setActiveTab,
}: DashboardSidebarProps) => {
  const { user } = useAuth();
  const isLoading = !user;
  const navigate = useNavigate();

  const menuItems = [
    { id: "overview", name: "Overview", icon: <Home className="h-5 w-5" /> },
    {
      id: "workshops",
      name: "My Workshops",
      icon: <BookOpen className="h-5 w-5" />,
    },
    {
      id: "calendar",
      name: "Calendar",
      icon: <Calendar className="h-5 w-5" />,
    },
    { id: "products", name: "Products", icon: <Package className="h-5 w-5" /> },
    {
      id: "billing",
      name: "Billing",
      icon: <CreditCard className="h-5 w-5" />,
    },
    { id: "reviews", name: "Reviews", icon: <Star className="h-5 w-5" /> },
  ];

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
  };

  return (
    <div className="w-full md:w-64 space-y-6">
      {/* User Profile Summary */}
      <div className="bg-white p-6 rounded-lg shadow-sm border flex flex-col items-center text-center space-y-4">
        {isLoading ? (
          <>
            <Skeleton className="h-20 w-20 rounded-full" />
            <div className="space-y-2 w-full flex flex-col items-center">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-3 w-24" />
            </div>
          </>
        ) : (
          <>
            <Avatar className="h-20 w-20 border-2 border-culinary-terracotta">
              <AvatarImage src={user?.image} />
              <AvatarFallback>
                {user?.name
                  ?.split(" ")
                  .map((n) => n[0])
                  .join("")
                  .toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-medium text-lg">{user?.name}</h3>
              <p className="text-sm text-muted-foreground">
                {user?.role || (user?.is_admin ? "Admin" : "Culinary Student")}
              </p>
            </div>
          </>
        )}
        <Link to="/profile">
          <Button variant="outline" className="w-full" size="sm">
            <User className="mr-2 h-4 w-4" />
            View Profile
          </Button>
        </Link>
      </div>

      {/* Navigation Menu */}
      <nav className="bg-white rounded-lg shadow-sm border p-3">
        <ul className="space-y-1">
          {menuItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => handleTabChange(item.id)}
                className={cn(
                  "w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm transition-colors",
                  activeTab === item.id
                    ? "bg-culinary-terracotta/10 text-culinary-terracotta font-medium"
                    : "text-muted-foreground hover:bg-culinary-cream hover:text-culinary-navy",
                )}
              >
                {item.icon}
                <span>{item.name}</span>
              </button>
            </li>
          ))}
        </ul>

        <div className="h-px bg-border my-3"></div>

        <ul className="space-y-1">
          <li>
            <button
              onClick={() => navigate("/settings")}
              className="w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm transition-colors text-muted-foreground hover:bg-culinary-cream hover:text-culinary-navy"
            >
              <Settings className="h-5 w-5" />
              <span>Settings</span>
            </button>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default DashboardSidebar;
