import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { toast } from "sonner";
import { useEffect, useState } from "react";
import api from "@/utils/api";

type ProtectedAdminRouteProps = {
  children: React.ReactNode;
};

const ProtectedAdminRoute = ({ children }: ProtectedAdminRouteProps) => {
  const { isAdmin, user } = useAuth();
  const location = useLocation();
  const [valid, setValid] = useState<boolean | null>(null);

  useEffect(() => {
    const check = async () => {
      try {
        await api.get('/api/users/me');
        setValid(true);
      } catch {
        setValid(false);
      }
    };
    check();
  }, []);

  // wait for auth check and user state to resolve before making a decision
  if (valid === null || (valid && !user)) return null;

  if (!valid) {
    toast.error("You must be logged in to access this page");
    return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  }

  if (!isAdmin) {
    toast.error("You don't have permission to access the admin dashboard");
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
};

export default ProtectedAdminRoute;
