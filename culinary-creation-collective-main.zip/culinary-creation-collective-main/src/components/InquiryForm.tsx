
import { useState } from "react";
import axios from "axios";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

const InquiryForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    workshopType: "",
    participants: "",
    preferredDate: "",
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await axios.post(
        `${import.meta.env.VITE_API_BASE_URL}/api/public/inquiries`,
        {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          workshop_type: formData.workshopType,
          participants: parseInt(formData.participants),
          preferred_date: formData.preferredDate,
          message: formData.message,
        }
      );
      toast.success("Your inquiry has been submitted! We'll contact you shortly.");
      setFormData({
        name: "",
        email: "",
        phone: "",
        workshopType: "",
        participants: "",
        preferredDate: "",
        message: "",
      });
    } catch {
      toast.error("Failed to submit inquiry. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="name">Full Name</Label>
          <Input
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Your name"
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Your email address"
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number</Label>
          <Input
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="Your phone number"
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="workshopType">Workshop Type</Label>
          <Select 
            value={formData.workshopType} 
            onValueChange={(value) => handleSelectChange("workshopType", value)}
          >
            <SelectTrigger id="workshopType">
              <SelectValue placeholder="Select workshop type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="group">Group Lessons</SelectItem>
              <SelectItem value="kids">Kids Workshop</SelectItem>
              <SelectItem value="date-night">Date Night</SelectItem>
              <SelectItem value="private">Private Session</SelectItem>
              <SelectItem value="team-building">Team Building</SelectItem>
              <SelectItem value="crash-course">Cooking Crash Course</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="participants">Number of Participants</Label>
          <Input
            id="participants"
            name="participants"
            type="number"
            min="1"
            value={formData.participants}
            onChange={handleChange}
            placeholder="How many people"
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="preferredDate">Preferred Date</Label>
          <Input
            id="preferredDate"
            name="preferredDate"
            type="date"
            value={formData.preferredDate}
            onChange={handleChange}
            required
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="message">Additional Information</Label>
        <Textarea
          id="message"
          name="message"
          value={formData.message}
          onChange={handleChange}
          placeholder="Tell us more about what you're looking for, dietary restrictions, etc."
          rows={4}
        />
      </div>
      
      <Button
        type="submit"
        className="w-full bg-culinary-terracotta hover:bg-culinary-terracotta/90 text-white btn-culinary"
        disabled={isSubmitting}
      >
        {isSubmitting ? "Submitting..." : "Submit Request"}
      </Button>
    </form>
  );
};

export default InquiryForm;
