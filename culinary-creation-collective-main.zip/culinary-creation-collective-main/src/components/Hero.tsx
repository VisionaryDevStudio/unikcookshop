
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

interface HeroProps {
  title: string;
  subtitle: string;
  image: string;
}

const Hero = ({ title, subtitle, image }: HeroProps) => {
  return (
    <div className="relative bg-culinary-navy text-white overflow-hidden">
      <div 
        className="absolute inset-0 z-0 opacity-30 bg-cover bg-center"
        style={{
          backgroundImage: `url("${image}")`,
          backgroundBlendMode: 'overlay'
        }}
      ></div>
      <div className="container mx-auto px-4 py-20 md:py-28 lg:py-36 relative z-10">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            {title}
          </h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl">
            {subtitle}
          </p>
          <div className="flex flex-wrap gap-4">
            <Link to="/workshops">
              <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90 text-white btn-culinary">
                Explore Workshops
              </Button>
            </Link>
            <Link to="/booking">
              <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/10 btn-culinary">
                Book Now
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
