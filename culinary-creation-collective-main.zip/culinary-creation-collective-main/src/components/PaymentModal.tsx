import { useState, useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Lock, Mail, MapPin } from "lucide-react";
import { toast } from "sonner";
import { useStripe, useElements, CardElement } from "@stripe/react-stripe-js";
import { logError, sanitizeError } from "@/utils/logger";
import { useCart } from "@/context/CartContext";
import { formatUserDate, formatUserTime, userTimeZone } from "@/utils/timezone";
import api from "@/utils/api";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const paymentSchema = z
  .object({
    email: z.string().email("Please enter a valid email address"),
    cardholderName: z
      .string()
      .min(2, "Please enter the cardholder's name")
      .optional(),
    billingAddress: z
      .string()
      .min(5, "Please enter your billing address")
      .optional(),
    city: z.string().min(2, "Please enter your city").optional(),
    postalCode: z
      .string()
      .min(3, "Please enter your postal code")
      .optional(),
    country: z
      .string()
      .optional()
      .refine((val) => !val || /^[A-Za-z]{2}$/i.test(val), {
        message: "کد کشور معتبر نیست",
      }),
    saveCard: z.boolean().optional(),
    termsAccepted: z.boolean().refine((val) => val === true, {
      message: "You must accept the terms and conditions",
    }),
  })
  .superRefine((data, ctx) => {
    if (ctx.context?.selectedMethod === "new") {
      if (!data.cardholderName) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["cardholderName"],
          message: "Please enter the cardholder's name",
        });
      }
      if (!data.billingAddress) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["billingAddress"],
          message: "Please enter your billing address",
        });
      }
      if (!data.city) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["city"],
          message: "Please enter your city",
        });
      }
      if (!data.postalCode) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["postalCode"],
          message: "Please enter your postal code",
        });
      }
      if (!data.country) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["country"],
          message: "Please enter your country",
        });
      }
    }
  });

type PaymentFormData = z.infer<typeof paymentSchema>;

interface UserError {
  message: string;
  recoverable: boolean;
}

interface ModalState {
  isProcessing: boolean;
  error: UserError | null;
  serverTotal: number | null;
  isLoadingTotal: boolean;
  totalError: string | null;
  cardBrand: string | null;
  savedMethods: any[];
  selectedMethod: string;
  paymentIntentId: string | null;
}

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentComplete: (transactions: any[]) => void;
  onPaymentFailure?: (paymentIntentId?: string) => void;
}

export const PaymentModal = ({
  isOpen,
  onClose,
  onPaymentComplete,
  onPaymentFailure,
}: PaymentModalProps) => {
  if (!import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Payments Unavailable</DialogTitle>
            <DialogDescription>
              Payment processing is currently unavailable.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <Button
              onClick={onClose}
              className="w-full bg-culinary-terracotta hover:bg-culinary-terracotta/90"
            >
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const stripe = useStripe();
  const elements = useElements();
  const { cartItems } = useCart();
  const navigate = useNavigate();

  const [modalState, setModalState] = useState<ModalState>({
    isProcessing: false,
    error: null,
    serverTotal: null,
    isLoadingTotal: false,
    totalError: null,
    cardBrand: null,
    savedMethods: [],
    selectedMethod: "new",
    paymentIntentId: null,
  });

  const updateState = (state: Partial<ModalState>) =>
    setModalState((prev) => ({ ...prev, ...state }));

  const {
    isProcessing,
    error,
    serverTotal,
    isLoadingTotal,
    totalError,
    cardBrand,
    savedMethods,
    selectedMethod,
  } = modalState;

  // use shared API instance with credentials

  const resolver = useMemo(
    () => zodResolver(paymentSchema, undefined, { context: { selectedMethod } }),
    [selectedMethod]
  );

  const form = useForm<PaymentFormData>({
    resolver,
    shouldUnregister: true,
    defaultValues: {
      email: "",
      cardholderName: "",
      billingAddress: "",
      city: "",
      postalCode: "",
      country: "",
      saveCard: false,
      termsAccepted: false,
    },
  });

  const handleMethodChange = (value: string) => {
    if (selectedMethod === "new" && value !== "new") {
      const { email, termsAccepted } = form.getValues();
      form.reset({
        email,
        saveCard: false,
        termsAccepted,
      });
    }
    updateState({ selectedMethod: value });
  };

  const fetchCartTotal = async (signal?: AbortSignal) => {
    updateState({ isLoadingTotal: true, totalError: null });
    try {
      const r = await api.get("/api/cart/total", { signal });
      updateState({ serverTotal: r.data.total / 100 });
    } catch (err: any) {
      if (axios.isCancel(err) || err?.code === "ERR_CANCELED") return;
      if (err?.response && [401, 403].includes(err.response.status)) {
        navigate("/login");
        return;
      }
      updateState({ totalError: "Unable to fetch cart total" });
      toast.error("Unable to fetch cart total", {
        action: { label: "Retry", onClick: () => fetchCartTotal() },
      });
    } finally {
      updateState({ isLoadingTotal: false });
    }
  };

  const fetchPaymentMethods = async (signal?: AbortSignal) => {
    try {
      const r = await api.get("/api/users/me/payment-methods", { signal });
      updateState({ savedMethods: r.data });
      const primary = r.data.find((m: any) => m.is_primary);
      updateState({ selectedMethod: primary ? primary.stripe_pm_id : "new" });
    } catch (err: any) {
      if (axios.isCancel(err) || err?.code === "ERR_CANCELED") return;
      if (err?.response && [401, 403].includes(err.response.status)) {
        navigate("/login");
        return;
      }
      logError(sanitizeError(err), "Failed to load payment methods");
      toast.error("Unable to load saved payment methods", {
        action: { label: "Retry", onClick: () => fetchPaymentMethods() },
      });
    }
  };

  const cancelPaymentIntent = async (paymentIntentId: string) => {
    try {
      await api.post("/api/cart/cancel-payment-intent", {
        payment_intent_id: paymentIntentId,
      });
      toast.success("Payment canceled");
    } catch (err) {
      logError(sanitizeError(err), "Failed to cancel payment intent");
      toast.error("Failed to cancel payment");
    } finally {
      updateState({ paymentIntentId: null });
    }
  };

  const handleClose = async () => {
    if (modalState.paymentIntentId) {
      await cancelPaymentIntent(modalState.paymentIntentId);
    }
    onClose();
  };

  useEffect(() => {
    if (!elements) return;
    const card = elements.getElement(CardElement);
    if (!card) return;
    const handleChange = (event: any) => {
      if (event.brand) updateState({ cardBrand: event.brand });
    };
    card.on("change", handleChange);
    return () => {
      card.off("change", handleChange);
    };
  }, [elements]);


  useEffect(() => {
    if (!isOpen) {
      updateState({ error: null, serverTotal: null, totalError: null });
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const controller = new AbortController();
    fetchCartTotal(controller.signal);
    return () => controller.abort();
  }, [isOpen, api, cartItems]);

  useEffect(() => {
    if (!isOpen) return;
    const controller = new AbortController();
    fetchPaymentMethods(controller.signal);
    return () => controller.abort();
  }, [isOpen, api]);

  const getError = (err: any, context?: "authentication"): UserError => {
    if (
      axios.isAxiosError(err) &&
      err.response?.data?.detail === "Cart is empty"
    ) {
      return { message: "سبد خرید خالی است", recoverable: false };
    }
    if (
      axios.isAxiosError(err) ||
      err?.type === "api_connection_error" ||
      err?.code === "ERR_NETWORK"
    ) {
      return {
        message: "Network error. Please check your connection and try again.",
        recoverable: true,
      };
    }
    if (context === "authentication") {
      return {
        message:
          err?.message ||
          "Authentication failed. Please try again or use a different card.",
        recoverable: true,
      };
    }
    if (err?.type === "card_error") {
      return {
        message:
          err?.message ||
          "Your card was declined. Please try another payment method.",
        recoverable: true,
      };
    }
    if (err?.type === "api_error" || err?.type === "unknown_status") {
      return {
        message: "A technical error occurred. Please contact support.",
        recoverable: false,
      };
    }
    return {
      message: "Something went wrong. Please contact support.",
      recoverable: false,
    };
  };

  const onSubmit = async (data: PaymentFormData) => {
    if (
      isProcessing ||
      !stripe ||
      !elements ||
      isLoadingTotal ||
      !!totalError
    )
      return;
    if (selectedMethod === "new" && !elements) return;

    updateState({ isProcessing: true, error: null });

    const sanitizedData = {
      cardholderName: data.cardholderName?.trim(),
      billingAddress: data.billingAddress?.trim(),
      city: data.city?.trim(),
      postalCode: data.postalCode?.trim(),
      country: data.country?.trim().toUpperCase(),
    };

    let clientSecret: string;
    try {
      const res = await api.post("/api/cart/create-payment-intent");
      clientSecret = res.data.client_secret;
      const idFromSecret = clientSecret.split("_secret")[0];
      updateState({
        serverTotal: res.data.amount / 100,
        paymentIntentId: idFromSecret,
      });
    } catch (err) {
      logError(sanitizeError(err), "Error creating payment intent");
      if (
        axios.isAxiosError(err) &&
        err.response?.status === 400 &&
        err.response?.data?.detail === "Cart is empty"
      ) {
        const friendly = { message: "سبد خرید خالی است", recoverable: false };
        updateState({ error: friendly });
        toast.error(friendly.message);
      } else {
        const friendly = getError(err);
        updateState({ error: friendly });
        toast.error(
          friendly.message,
          friendly.recoverable
            ? { action: { label: "Retry", onClick: () => onSubmit(data) } }
            : undefined
        );
      }
      onPaymentFailure?.();
      updateState({ isProcessing: false });
      return;
    }

    const confirmParams =
      selectedMethod === "new"
        ? {
            payment_method: {
              card: elements.getElement(CardElement)!,
              billing_details: {
                name: sanitizedData.cardholderName,
                email: data.email,
                address: {
                  line1: sanitizedData.billingAddress,
                  city: sanitizedData.city,
                  postal_code: sanitizedData.postalCode,
                  country: sanitizedData.country,
                },
              },
            },
            ...(data.saveCard ? { setup_future_usage: "off_session" } : {}),
          }
        : { payment_method: selectedMethod };
    const { paymentIntent, error: stripeError } = await stripe.confirmCardPayment(
      clientSecret,
      confirmParams
    );
    updateState({
      paymentIntentId:
        paymentIntent?.id || stripeError?.payment_intent?.id || modalState.paymentIntentId,
    });

    if (stripeError) {
      const friendly = getError(stripeError);
      logError(sanitizeError(stripeError), "Stripe payment confirmation failed");
      updateState({ error: friendly });
      toast.error(friendly.message);
      const piId =
        paymentIntent?.id || stripeError.payment_intent?.id || modalState.paymentIntentId;
      if (piId) {
        await cancelPaymentIntent(piId);
      }
      onPaymentFailure?.(piId);
      updateState({ isProcessing: false });
      return;
    }

    if (!paymentIntent) {
      const err = new Error("No payment intent returned");
      logError(sanitizeError(err), "Stripe payment failed");
      const friendly = getError(err);
      updateState({ error: friendly });
      toast.error(friendly.message);
      if (modalState.paymentIntentId) {
        await cancelPaymentIntent(modalState.paymentIntentId);
        onPaymentFailure?.(modalState.paymentIntentId);
      } else {
        onPaymentFailure?.();
      }
      updateState({ isProcessing: false });
      return;
    }

    let finalPaymentIntent = paymentIntent;

      if (paymentIntent.status === "requires_action") {
        toast.info(
          "Additional authentication required. Please complete the verification."
        );
        const { paymentIntent: actionIntent, error: actionError } =
          await stripe.confirmCardPayment(paymentIntent.client_secret);
        if (actionError) {
          const friendly = getError(actionError, "authentication");
          logError(
            sanitizeError(actionError),
            "Stripe 3D Secure authentication failed"
          );
          updateState({ error: friendly });
          toast.error(friendly.message);
          if (modalState.paymentIntentId) {
            await cancelPaymentIntent(modalState.paymentIntentId);
            onPaymentFailure?.(modalState.paymentIntentId);
          } else {
            onPaymentFailure?.();
          }
          updateState({ isProcessing: false });
          return;
        }
        if (!actionIntent) {
          const err = new Error(
            "No payment intent returned after authentication"
          );
          logError(sanitizeError(err), "Stripe payment failed");
          const friendly = getError(err);
          updateState({ error: friendly });
          toast.error(friendly.message);
          if (modalState.paymentIntentId) {
            await cancelPaymentIntent(modalState.paymentIntentId);
            onPaymentFailure?.(modalState.paymentIntentId);
          } else {
            onPaymentFailure?.();
          }
          updateState({ isProcessing: false });
          return;
        }
        updateState({ paymentIntentId: actionIntent.id });
        finalPaymentIntent = actionIntent;
      }

    if (finalPaymentIntent.status !== "succeeded") {
      const friendly = getError({
        type: "unknown_status",
        status: finalPaymentIntent.status,
      });
      updateState({ error: friendly });
      toast.error(friendly.message);
      await cancelPaymentIntent(finalPaymentIntent.id);
      onPaymentFailure?.(finalPaymentIntent.id);
      updateState({ isProcessing: false });
      return;
    }

    try {
      const res = await api.post("/api/cart/checkout", {
        payment_intent_id: finalPaymentIntent.id,
        save_payment_method: selectedMethod === "new" && data.saveCard,
      });
      try {
        const methods = await api.get("/api/users/me/payment-methods");
        updateState({ savedMethods: methods.data });

        const primary = methods.data.find((m: any) => m.is_primary);
        if (primary) updateState({ selectedMethod: primary.stripe_pm_id });
      } catch (err) {
        logError(sanitizeError(err), "Failed to refresh payment methods");
        toast.error("Could not refresh saved payment methods", {
        action: { label: "Retry", onClick: () => fetchPaymentMethods() },
        });
      }
      toast.success("Payment successful! Thank you for your purchase.");
      onPaymentComplete(res.data);
      onClose();
      form.reset();
      updateState({ selectedMethod: "new", paymentIntentId: null });
    } catch (err) {
      logError(sanitizeError(err), "Checkout finalization failed");
      toast.error("Payment succeeded but checkout failed", {
        action: { label: "Go Back", onClick: () => window.history.back() },
      });
      onPaymentFailure?.(paymentIntent.id);
    } finally {
      updateState({ isProcessing: false });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!open) handleClose(); }}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-culinary-navy">
            <CreditCard className="h-5 w-5" />
            Payment Information
          </DialogTitle>
          <DialogDescription>
            Complete your purchase securely. Your payment information is encrypted and protected.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Order Summary */}
            <div className="bg-culinary-cream p-4 rounded-lg">
              <h3 className="font-medium text-culinary-navy mb-2">Order Summary</h3>
              <div className="space-y-2 mb-4">
                {cartItems.map((item) => (
                  <div key={`${item.id}-${item.scheduled_at || "nosched"}`} className="text-sm">
                    <div className="flex justify-between">
                      <span>
                        {item.name}
                        {item.quantity > 1 ? ` ×${item.quantity}` : ""}
                      </span>
                      <span>${item.price.toFixed(2)}</span>
                    </div>
                    {item.scheduled_at && (
                      <div className="text-xs text-gray-500">
                        {formatUserDate(item.scheduled_at)} at {formatUserTime(item.scheduled_at)} ({userTimeZone})
                      </div>
                    )}
                  </div>
                ))}
              </div>
              {isLoadingTotal ? (
                <div className="flex justify-center py-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-culinary-navy"></div>
                </div>
              ) : totalError ? (
                <div className="flex items-center justify-between text-sm text-red-500">
                  <span>{totalError}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fetchCartTotal()}
                  >
                    Retry
                  </Button>
                </div>
              ) : (
                <div className="flex justify-between text-lg font-bold">
                  <span>Total Amount:</span>
                  <span className="text-culinary-navy">
                    ${serverTotal?.toFixed(2)}
                  </span>
                </div>
              )}
            </div>

            {/* Contact Information */}
            <div className="space-y-4">
              <h3 className="font-medium text-culinary-navy flex items-center gap-2">
                <Mail className="h-4 w-4" />
                Contact Information
              </h3>
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input placeholder="your@email.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Separator />

            {/* Payment Information */}
            <div className="space-y-4">
              <h3 className="font-medium text-culinary-navy flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Payment Details
              </h3>
              {savedMethods.length > 0 && (
                <RadioGroup
                  value={selectedMethod}
                  onValueChange={handleMethodChange}
                  className="space-y-3"
                >
                  {savedMethods.map((m) => (
                    <div
                      key={m.id}
                      className="flex items-center justify-between p-2 border rounded"
                    >
                      <div className="flex items-center space-x-3">
                        <RadioGroupItem value={m.stripe_pm_id} id={`pm-${m.id}`} />
                        <label htmlFor={`pm-${m.id}`} className="text-sm">
                          {m.brand} •••• {m.last4} (exp {m.expiry})
                        </label>
                      </div>
                      {m.is_primary && <Badge variant="culinary">Primary</Badge>}
                    </div>
                  ))}
                  <div className="flex items-center space-x-3 p-2 border rounded">
                    <RadioGroupItem value="new" id="pm-new" />
                    <label htmlFor="pm-new" className="text-sm">
                      Use a new card
                    </label>
                  </div>
                </RadioGroup>
              )}

              {selectedMethod === "new" && (
                <>
                  <FormField
                    control={form.control}
                    name="cardholderName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cardholder Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="rounded-md border p-2">
                    <CardElement
                      options={{
                        hidePostalCode: true,
                        style: {
                          base: {
                            fontSize: "16px",
                            color: "#020817",
                            "::placeholder": { color: "#9CA3AF" },
                          },
                          invalid: { color: "#EF4444" },
                        },
                      }}
                    />
                  </div>
                  {cardBrand && (
                    <p className="text-sm text-gray-500 mt-1">Card type: {cardBrand}</p>
                  )}
                  <FormField
                    control={form.control}
                    name="saveCard"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 pt-2">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="text-sm">
                          Save this card for future payments
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                </>
              )}
              {error && (
                <p className="text-sm text-red-500">
                  {error.message}
                  {!error.recoverable && (
                    <>
                      {" "}Please{" "}
                      <a
                        href="mailto:support@example.com"
                        className="underline"
                      >
                        contact support
                      </a>
                      .
                    </>
                  )}
                </p>
              )}
            </div>

            {selectedMethod === "new" && (
              <>
                <Separator />

                {/* Billing Address */}
                <div className="space-y-4">
                  <h3 className="font-medium text-culinary-navy flex items-center gap-2">
                    <MapPin className="h-4 w-4" />
                    Billing Address
                  </h3>

                  <FormField
                    control={form.control}
                    name="billingAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Street Address</FormLabel>
                        <FormControl>
                          <Input placeholder="123 Main Street" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>City</FormLabel>
                          <FormControl>
                            <Input placeholder="New York" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="postalCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Postal Code</FormLabel>
                          <FormControl>
                            <Input placeholder="10001" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="country"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Country</FormLabel>
                        <FormControl>
                          <Input placeholder="United States" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </>
            )}

            <Separator />

            {/* Terms and Conditions */}
            <FormField
              control={form.control}
              name="termsAccepted"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel className="text-sm">
                      I agree to the
                      {" "}
                      <a
                        href="/terms"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="underline"
                      >
                        Terms of Service
                      </a>
                      {" "}and{" "}
                      <a
                        href="/privacy"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="underline"
                      >
                        Privacy Policy
                      </a>
                    </FormLabel>
                    <FormMessage />
                  </div>
                </FormItem>
              )}
            />

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1"
                disabled={isProcessing}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-culinary-terracotta hover:bg-culinary-terracotta/90"
                disabled={
                  isProcessing || !stripe || isLoadingTotal || !!totalError
                }
              >
                {isProcessing ? (
                  <div className="flex items-center gap-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Processing...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Lock className="h-4 w-4" />
                    {isLoadingTotal
                      ? "Calculating..."
                      : `Pay $${serverTotal?.toFixed(2)}`}
                  </div>
                )}
              </Button>
            </div>

            <div className="text-center text-sm text-gray-500 flex items-center justify-center gap-1">
              <Lock className="h-3 w-3" />
              Your payment information is secure and encrypted
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};
