import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";
import { Link } from "react-router-dom";
import { useCart } from "@/context/CartContext";
import { toast } from "sonner";
import axios from "axios";
import { formatUserDate, formatUserTime, getTimeZoneForLocation } from "@/utils/timezone";
import { addHours } from "date-fns";

interface Workshop {
  id: number;
  title: string;
  date: string;
  instructor: string;
  location: string;
  image?: string | null;
  price?: number;
  startTime: string;
  endTime: string;
  timeZone: string;
}

const FeaturedWorkshops = () => {
  const { addToCart } = useCart();
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    axios
      .get(`${import.meta.env.VITE_API_BASE_URL}/api/public/workshops/upcoming`)
      .then((r) => {
        const data = Array.isArray(r.data)
          ? r.data
          : Array.isArray(r.data?.data)
            ? r.data.data
            : [];
        const formatted = data.map((w: any) => {
          const d = new Date(w.date);
          const tz = getTimeZoneForLocation(w.location) || Intl.DateTimeFormat().resolvedOptions().timeZone;
          return {
            ...w,
            startTime: formatUserTime(d, {}, tz),
            endTime: formatUserTime(addHours(d, 2), {}, tz),
            timeZone: tz,
          } as Workshop;
        });
        setWorkshops(formatted);
        setLoading(false);
      })
      .catch(() => {
        setError("Failed to load workshops");
        setLoading(false);
      });
  }, []);

  const handleAddToCart = (workshop: Workshop) => {
    addToCart({
      id: workshop.id,
      name: workshop.title,
      price: Number(workshop.price ?? 0),
      category: "Workshop",
      image: workshop.image || "",
      type: "workshop",
      scheduled_at: new Date(workshop.date).toISOString(),
    });
    toast.success(`${workshop.title} added to cart`);
  };

  if (loading) {
    return <div className="py-16 text-center">Loading...</div>;
  }

  if (error) {
    return <div className="py-16 text-center text-red-500">{error}</div>;
  }

  if (workshops.length === 0) {
    return <div className="py-16 text-center">No workshops available</div>;
  }

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-culinary-navy">
            Featured Workshops
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our most popular culinary experiences handpicked for you
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {workshops.map((workshop) => (
            <div key={workshop.id} className="p-6 bg-white rounded-lg shadow flex flex-col">
              {workshop.image && (
                <img
                  src={workshop.image}
                  alt={workshop.title}
                  className="w-full h-40 object-cover rounded mb-4"
                />
              )}
              <h3 className="text-xl font-semibold mb-2 text-culinary-navy">
                {workshop.title}
              </h3>
              <p className="text-gray-600 mb-2">Instructor: {workshop.instructor}</p>
              <p className="text-gray-600 mb-4">
                {formatUserDate(workshop.date, { dateStyle: 'medium' }, workshop.timeZone)}
                {` ${workshop.startTime} - ${workshop.endTime} (${workshop.timeZone}) - ${workshop.location}`}
              </p>
              <div className="mt-auto flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleAddToCart(workshop)}
                  className="flex items-center gap-1"
                >
                  <ShoppingCart className="h-4 w-4" />
                  Add to Cart
                </Button>
                <Link to="/booking">
                  <Button size="sm" className="bg-culinary-sage hover:bg-culinary-sage/90">
                    Book Now
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link to="/workshops">
            <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90 btn-culinary">
              View All Workshops
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedWorkshops;
