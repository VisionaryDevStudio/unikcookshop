import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import api from "@/utils/api";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useAuth } from "@/context/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { BookOpen } from "lucide-react";
import { toast } from "sonner";
import { formatUserDate } from "@/utils/timezone";

const AdminInquiries = () => {
  const { isAdmin, isAuthenticated } = useAuth();
  const [inquiries, setInquiries] = useState<any[]>([]);

  useEffect(() => {
    const fetchInquiries = async () => {
      try {
        const res = await api.get(`/api/admin/inquiries`);
        setInquiries(res.data);
      } catch {
        toast.error('Failed to fetch inquiries');
      }
    };
    fetchInquiries();
  }, []);

  if (!isAuthenticated || !isAdmin) {
    return <Navigate to="/" replace />;
  }

  const updateStatus = async (id: number, status: string) => {
    try {
      await api.put(`/api/admin/inquiries/${id}/status`, { status });
      setInquiries((prev) =>
        prev.map((inq) => (inq.id === id ? { ...inq, status } : inq))
      );
      toast.success(`Inquiry ${status}`);
    } catch {
      toast.error('Failed to update inquiry');
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow py-8">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-culinary-navy mb-2">Inquiry Management</h1>
            <p className="text-gray-600">View and track customer inquiries</p>
          </div>

          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6 text-center">
                <BookOpen className="h-8 w-8 text-culinary-navy mx-auto mb-2" />
                <div className="text-2xl font-bold text-culinary-navy">{inquiries.length}</div>
                <div className="text-sm text-gray-600">Total Inquiries</div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Recent Inquiries</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Workshop Type</TableHead>
                    <TableHead>Participants</TableHead>
                    <TableHead>Preferred Date</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead>Received</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {inquiries.map((inq) => (
                    <TableRow key={inq.id}>
                      <TableCell className="font-medium">{inq.name}</TableCell>
                      <TableCell>{inq.email}</TableCell>
                      <TableCell>{inq.phone}</TableCell>
                      <TableCell>{inq.workshop_type}</TableCell>
                      <TableCell>{inq.participants}</TableCell>
                      <TableCell>{inq.preferred_date}</TableCell>
                      <TableCell className="max-w-xs break-words whitespace-pre-line">{inq.message || '-'}</TableCell>
                      <TableCell>{formatUserDate(inq.created_at)}</TableCell>
                      <TableCell className="capitalize">{inq.status}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => updateStatus(inq.id, 'resolved')}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            Mark as Resolved
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => updateStatus(inq.id, 'archived')}
                          >
                            Archive
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AdminInquiries;
