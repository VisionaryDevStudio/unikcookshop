
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { PlusCircle, ShoppingBag, BookOpen, Users, TrendingUp, Calendar, Package, CreditCard, Activity, Eye, Trash2, Edit, MessageSquare, Star, Check, X, Clock, Settings, Shield } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { formatUserDate } from "@/utils/timezone";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import api from "@/utils/api";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useReviews } from "@/context/ReviewContext";

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const navigate = useNavigate();
  const { getPendingReviews, approveReview, declineReview, reviews } = useReviews();
  const [analytics, setAnalytics] = useState({
    totalRevenue: 0,
    totalOrders: 0,
    totalUsers: 0,
    activeWorkshops: 0,
    monthlyGrowth: 0,
    topProducts: [] as { name: string; sales: number; revenue: number }[],
    recentActivity: [] as { description: string; time: string }[],
    ordersThisMonth: 0,
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      const statsPromise = api
        .get(`/api/admin/stats`)
        .then(res => {
          setAnalytics({
            totalRevenue: res.data.revenue,
            totalOrders: res.data.orders,
            totalUsers: res.data.users,
            activeWorkshops: res.data.active_workshops,
            monthlyGrowth: res.data.monthly_growth ?? 0,
            topProducts: res.data.top_products,
            recentActivity: res.data.recent_activity,
            ordersThisMonth: res.data.orders_this_month,
          });
        })
        .catch(() => {
          toast.error('Failed to fetch stats');
          setError('Failed to fetch stats');
        });

      const productsPromise = api
        .get(`/api/admin/products`)
        .then(r =>
          setProducts(
            r.data.map((p: any) => ({
              ...p,
              stock: p.stock ?? p.stock_count ?? 0,
              revenue: (p.price ?? 0) * (p.sold ?? 0),
            }))
          )
        )
        .catch(() => {});

      const workshopsPromise = api
        .get(`/api/admin/workshops`)
        .then(r => setWorkshops(r.data))
        .catch(() => {});

      const usersPromise = api
        .get(`/api/admin/users`)
        .then(r => setUsers(r.data))
        .catch(() => {});

      const ordersPromise = api
        .get(`/api/admin/orders`)
        .then(r => setOrders(r.data))
        .catch(() => {});

      await Promise.all([
        statsPromise,
        productsPromise,
        workshopsPromise,
        usersPromise,
        ordersPromise,
      ]);
    };

    fetchData().finally(() => setLoading(false));
  }, []);
  const [products, setProducts] = useState<any[]>([]);
  
  const [workshops, setWorkshops] = useState<any[]>([]);

  const [users, setUsers] = useState<any[]>([]);

  const [orders, setOrders] = useState<any[]>([]);

  const [viewUser, setViewUser] = useState<any | null>(null);
  const [viewOrder, setViewOrder] = useState<any | null>(null);
  const [editOrder, setEditOrder] = useState<any | null>(null);
  const [editStatus, setEditStatus] = useState<string>("paid");
  const [typeFilter, setTypeFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  // Function to get display status for orders
  const getOrderDisplayStatus = (order) => {
    if (order.type === "product") {
      return order.status; // "paid" or "declined"
    } else if (order.type === "workshop") {
      if (order.status !== "paid") return order.status;

      const today = new Date();
      const wsDate = order.workshop_date
        ? new Date(order.workshop_date)
        : null;

      if (wsDate && wsDate > today) {
        return "upcoming";
      } else {
        return "completed";
      }
    }
    return order.status;
  };

  const exportOrders = async () => {
    try {
      const res = await api.get(`/api/admin/orders/export`, { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'orders.csv');
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch {
      toast.error('Failed to export orders');
    }
  };

  const submitOrderStatus = async () => {
    if (!editOrder) return;
    try {
      const res = await api.put(
        `/api/admin/orders/${editOrder.id}/status`,
        { status: editStatus },
      );
      setOrders(orders.map(o => (o.id === editOrder.id ? res.data : o)));
      toast.success('Order updated');
    } catch {
      toast.error('Failed to update');
    }
    setEditOrder(null);
  };

  const openEditProduct = (product: any) => {
    navigate('/admin/add-product', { state: { product } });
  };

  const deleteProduct = async (id: number) => {
    try {
      await api.delete(`/api/admin/products/${id}`);
      setProducts(products.filter(p => p.id !== id));
      toast.success('Product deleted');
    } catch {
      toast.error('Failed to delete product');
    }
  };

  const editWorkshop = (workshop: any) => {
    navigate('/admin/add-workshop', { state: { workshop } });
  };

  const deleteWorkshop = async (id: number) => {
    try {
      await api.delete(`/api/admin/workshops/${id}`);
      setWorkshops(workshops.filter(w => w.id !== id));
      toast.success('Workshop deleted');
    } catch {
      toast.error('Failed to delete workshop');
    }
  };

  const filteredOrders = orders.filter(o => {
    const typeOk = typeFilter === 'all' || o.type === typeFilter;
    const statusOk =
      statusFilter === 'all' || getOrderDisplayStatus(o) === statusFilter;
    return typeOk && statusOk;
  });

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-culinary-cream/10">
        <Navbar />
        <div className="container mx-auto px-4 py-8 flex-grow">Loading...</div>
        <Footer />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col bg-culinary-cream/10">
        <Navbar />
        <div className="container mx-auto px-4 py-8 flex-grow text-red-500">{error}</div>
        <Footer />
      </div>
    );
  }

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  const ordersThisMonth =
    analytics.ordersThisMonth ??
    orders.filter(o => {
      const orderDate = new Date(o.date);
      return (
        orderDate.getMonth() === currentMonth &&
        orderDate.getFullYear() === currentYear
      );
    }).length;

  return (
    <div className="min-h-screen flex flex-col bg-culinary-cream/10">
      <Navbar />

      <div className="container mx-auto px-4 py-8 flex-grow">
        <header className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-culinary-navy">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage your products and workshops</p>
          </div>
          <div className="flex gap-2">
            <Link to="/admin/inquiries">
              <Button variant="outline" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Inquiries
              </Button>
            </Link>
            <Link to="/admin/site-settings">
              <Button variant="outline" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Site Settings
              </Button>
            </Link>
          </div>
        </header>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-8 grid grid-cols-7 w-full">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="reviews" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Reviews
            </TabsTrigger>
            <TabsTrigger value="admins" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Admins
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Users
            </TabsTrigger>
            <TabsTrigger value="orders" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Orders
            </TabsTrigger>
            <TabsTrigger value="products" className="flex items-center gap-2">
              <Package className="h-4 w-4" />
              Products
            </TabsTrigger>
            <TabsTrigger value="workshops" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Workshops
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6 animate-fade-in">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${analytics.totalRevenue.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground">
                    +{analytics.monthlyGrowth}% from last month
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics.totalOrders}</div>
                  <p className="text-xs text-muted-foreground">
                    {ordersThisMonth} this month
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics.totalUsers}</div>
                  <p className="text-xs text-muted-foreground">
                    {users.filter(u => u.status === 'active').length} active users
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Workshops</CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics.activeWorkshops}</div>
                  <p className="text-xs text-muted-foreground">
                    {workshops.filter(w => w.status === 'upcoming').length} upcoming
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Top Products</CardTitle>
                  <CardDescription>Best selling products by revenue</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analytics.topProducts.map((product, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-muted-foreground">{product.sales} sold</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">${product.revenue.toLocaleString()}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest activities across the platform</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analytics.recentActivity.map((activity, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                        <div className="flex-1">
                          <p className="text-sm">{activity.description}</p>
                          <p className="text-xs text-muted-foreground">{activity.time}</p>
                        </div>
                        <Activity className="h-4 w-4 text-muted-foreground" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Reviews Tab */}
          <TabsContent value="reviews" className="space-y-6 animate-fade-in">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">Review Management</h2>
              <div className="flex gap-2">
                <Badge variant="secondary">
                  {getPendingReviews().length} Pending
                </Badge>
              </div>
            </div>

            {/* Review Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending Reviews</CardTitle>
                  <Clock className="h-4 w-4 text-orange-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{getPendingReviews().length}</div>
                  <p className="text-xs text-muted-foreground">Awaiting approval</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Approved Reviews</CardTitle>
                  <Check className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{reviews.filter(r => r.status === 'approved').length}</div>
                  <p className="text-xs text-muted-foreground">Published reviews</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
                  <Star className="h-4 w-4 text-yellow-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {reviews.filter(r => r.status === 'approved').length > 0 
                      ? (reviews.filter(r => r.status === 'approved').reduce((acc, r) => acc + r.rating, 0) / reviews.filter(r => r.status === 'approved').length).toFixed(1)
                      : 'N/A'
                    }
                  </div>
                  <p className="text-xs text-muted-foreground">Overall rating</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Reviews</CardTitle>
                  <MessageSquare className="h-4 w-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{reviews.length}</div>
                  <p className="text-xs text-muted-foreground">All reviews</p>
                </CardContent>
              </Card>
            </div>

            {/* Pending Reviews */}
            <Card>
              <CardHeader>
                <CardTitle>Pending Reviews</CardTitle>
                <CardDescription>Reviews awaiting your approval or rejection</CardDescription>
              </CardHeader>
              <CardContent>
                {getPendingReviews().length > 0 ? (
                  <div className="space-y-4">
                    {getPendingReviews().map((review) => (
                      <div key={review.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-culinary-navy">{review.item_title}</span>
                              <Badge variant="outline">{review.item_type}</Badge>
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <Star 
                                    key={i}
                                    className={`h-4 w-4 ${i < Math.floor(review.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                                  />
                                ))}
                              </div>
                              <span className="text-sm text-gray-500">{formatUserDate(review.date)}</span>
                            </div>
                          </div>
                          <Badge variant="secondary">Pending</Badge>
                        </div>
                        
                        <p className="text-gray-700 mb-4 leading-relaxed">{review.review}</p>
                        
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => {
                              approveReview(review.id);
                              toast.success("Review approved successfully!");
                            }}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <Check className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => {
                              declineReview(review.id);
                              toast.success("Review declined");
                            }}
                          >
                            <X className="h-4 w-4 mr-1" />
                            Decline
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-600">No pending reviews</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Approved Reviews */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Approved Reviews</CardTitle>
                <CardDescription>Latest reviews that have been approved</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Customer</TableHead>
                      <TableHead>Product</TableHead>
                      <TableHead>Rating</TableHead>
                      <TableHead>Comment</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Helpful</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {reviews.filter(r => r.status === 'approved').slice(0, 5).map((review) => (
                      <TableRow key={review.id}>
                        <TableCell className="font-medium">{review.item_title}</TableCell>
                        <TableCell>{review.item_type}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i}
                                className={`h-3 w-3 ${i < Math.floor(review.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                              />
                            ))}
                            <span className="ml-1 text-sm">{review.rating}</span>
                          </div>
                        </TableCell>
                        <TableCell className="max-w-xs truncate">{review.review}</TableCell>
                        <TableCell>{formatUserDate(review.date)}</TableCell>
                        <TableCell>{review.helpful}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Admins Tab */}
          <TabsContent value="admins" className="space-y-6 animate-fade-in">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">Admin Management</h2>
              <Link to="/admin/add-admin">
                <Button className="bg-culinary-navy text-white hover:bg-culinary-navy/90">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add Admin
                </Button>
              </Link>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>All Admins</CardTitle>
                <CardDescription>Manage administrators</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Join Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.filter(u => u.is_admin).map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{formatUserDate(user.created_at)}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => setViewUser(user)}>
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => navigate('/admin/add-admin', { state: { user } })}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6 animate-fade-in">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">User Management</h2>
              <div className="flex gap-2">
                <Link to="/admin/add-admin">
                  <Button className="bg-culinary-navy text-white hover:bg-culinary-navy/90">
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Add Admin
                  </Button>
                </Link>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>All Users</CardTitle>
                <CardDescription>Manage your user base and customer activity</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Join Date</TableHead>
                      <TableHead>Total Spent</TableHead>
                      <TableHead>Workshops</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{formatUserDate(user.created_at)}</TableCell>
                        <TableCell>${user.total_spent.toFixed(2)}</TableCell>
                        <TableCell>{user.workshops_attended}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            user.status === 'active'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}>
                            {user.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => setViewUser(user)}>
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => navigate('/admin/add-admin', { state: { user } })}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders" className="space-y-6 animate-fade-in">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">Order Management</h2>
              <div className="flex gap-2">
                <Button variant="outline" onClick={exportOrders}>Export Orders</Button>
              </div>
            </div>

            <div className="flex gap-4">
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="product">Product</SelectItem>
                  <SelectItem value="workshop">Workshop</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="declined">Declined</SelectItem>
                  <SelectItem value="shipped">Shipped</SelectItem>
                  <SelectItem value="upcoming">Upcoming</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>All Orders</CardTitle>
                <CardDescription>Track and manage customer orders and workshop bookings</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order ID</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Items</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredOrders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">#{order.id}</TableCell>
                        <TableCell>{order.user_id}</TableCell>
                        <TableCell>{order.description}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            order.type === 'workshop'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-purple-100 text-purple-800'
                          }`}>
                            {order.type}
                          </span>
                        </TableCell>
                        <TableCell>${order.amount.toFixed(2)}</TableCell>
                        <TableCell>{formatUserDate(order.date)}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            getOrderDisplayStatus(order) === 'completed' ? 'bg-green-100 text-green-800' :
                            getOrderDisplayStatus(order) === 'upcoming' ? 'bg-blue-100 text-blue-800' :
                            getOrderDisplayStatus(order) === 'paid' ? 'bg-green-100 text-green-800' :
                            getOrderDisplayStatus(order) === 'declined' ? 'bg-red-100 text-red-800' :
                            'bg-yellow-100 text-yellow-800'
                          }`}>
                            {getOrderDisplayStatus(order)}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => setViewOrder(order)}>
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => { setEditOrder(order); setEditStatus(order.status); }}>
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-6 animate-fade-in">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">Product Management</h2>
              
              <Link to="/admin/add-product">
                <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add Product
                </Button>
              </Link>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Products Inventory</CardTitle>
                <CardDescription>Manage your product inventory and sales</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Product Name</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Stock</TableHead>
                      <TableHead>Sold</TableHead>
                      <TableHead>Revenue</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products.map((product) => (
                      <TableRow key={product.id}>
                        <TableCell>{product.id}</TableCell>
                        <TableCell className="font-medium">{product.name}</TableCell>
                        <TableCell>${product.price.toFixed(2)}</TableCell>
                        <TableCell>{product.category}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            product.stock < 10 
                              ? 'bg-red-100 text-red-800' 
                              : 'bg-green-100 text-green-800'
                          }`}>
                            {product.stock}
                          </span>
                        </TableCell>
                        <TableCell>{product.sold}</TableCell>
                        <TableCell>${product.revenue.toFixed(2)}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => openEditProduct(product)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => deleteProduct(product.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Workshops Tab */}
          <TabsContent value="workshops" className="space-y-6 animate-fade-in">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">Workshop Management</h2>
              
              <Link to="/admin/add-workshop">
                <Button className="bg-culinary-sage hover:bg-culinary-sage/90">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add Detailed Workshop
                </Button>
              </Link>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Workshop Schedule</CardTitle>
                <CardDescription>Manage your workshop calendar and enrollments</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Workshop</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Instructor</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Enrollment</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Revenue</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {workshops.map((workshop) => (
                      <TableRow key={workshop.id}>
                        <TableCell>{workshop.id}</TableCell>
                        <TableCell className="font-medium">{workshop.title}</TableCell>
                        <TableCell>{formatUserDate(workshop.date)}</TableCell>
                        <TableCell>{workshop.instructor}</TableCell>
                        <TableCell>
                          {workshop.price !== undefined
                            ? `$${Number(workshop.price).toFixed(2)}`
                            : 'N/A'}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <span>{workshop.enrolled}/{workshop.capacity}</span>
                            <div className="w-16 h-2 bg-gray-200 rounded-full">
                              <div 
                                className="h-2 bg-primary rounded-full" 
                                style={{ width: `${(workshop.enrolled / workshop.capacity) * 100}%` }}
                              ></div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            workshop.status === 'upcoming' 
                              ? 'bg-blue-100 text-blue-800' 
                              : 'bg-green-100 text-green-800'
                          }`}>
                            {workshop.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          {workshop.price !== undefined && workshop.enrolled !== undefined
                            ? `$${(Number(workshop.price) * Number(workshop.enrolled)).toFixed(2)}`
                            : 'N/A'}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => navigate(`/workshops/${workshop.id}`)}>
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => editWorkshop(workshop)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => deleteWorkshop(workshop.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={!!viewUser} onOpenChange={(open) => !open && setViewUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
          </DialogHeader>
          {viewUser && (
            <div className="space-y-2">
              <p>
                <span className="font-semibold">Name:</span> {viewUser.name}
              </p>
              <p>
                <span className="font-semibold">Email:</span> {viewUser.email}
              </p>
              <p>
                <span className="font-semibold">Joined:</span>{" "}
                {formatUserDate(viewUser.created_at)}
              </p>
              <p>
                <span className="font-semibold">Status:</span> {viewUser.status}
              </p>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setViewUser(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!viewOrder} onOpenChange={(o) => !o && setViewOrder(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Order Details</DialogTitle>
          </DialogHeader>
          {viewOrder && (
            <div className="space-y-2">
              <p>
                <span className="font-semibold">ID:</span> {viewOrder.id}
              </p>
              <p>
                <span className="font-semibold">User:</span> {viewOrder.user_id}
              </p>
              <p>
                <span className="font-semibold">Item:</span> {viewOrder.description}
              </p>
              <p>
                <span className="font-semibold">Amount:</span> ${viewOrder.amount.toFixed(2)}
              </p>
              <p>
                <span className="font-semibold">Status:</span> {viewOrder.status}
              </p>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setViewOrder(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>


      <Dialog open={!!editOrder} onOpenChange={(o) => !o && setEditOrder(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Order Status</DialogTitle>
          </DialogHeader>
          {editOrder && (
            <div className="space-y-4">
              <Select value={editStatus} onValueChange={setEditStatus}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="declined">Declined</SelectItem>
                  <SelectItem value="shipped">Shipped</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setEditOrder(null)} variant="secondary">Cancel</Button>
            <Button onClick={submitOrderStatus}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default AdminDashboard;
