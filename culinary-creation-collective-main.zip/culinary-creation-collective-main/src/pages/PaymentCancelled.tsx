import { Link, useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import api from "@/utils/api";
import { isValidPaymentIntentId } from "@/utils/payment";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  XCircle,
  ArrowLeft,
  CreditCard,
  HelpCircle,
  Loader2,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getStatusColor } from "@/utils/status";

const PaymentCancelled = () => {
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const [transactions, setTransactions] = useState<any[]>(
    () => (location.state as any)?.transactions || []
  );
  const paymentIntentId = searchParams.get("payment_intent_id");
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const apiInstance = useMemo(() => api, []);

  const fetchTransactions = () => {
    setLoadError(null);
    setIsLoading(true);
    apiInstance
      .get(`/api/users/me/transactions/${paymentIntentId}`)
      .then((r) => {
        setTransactions(r.data);
        setIsLoading(false);
      })
      .catch((err) => {
        if (err?.response && [401, 403].includes(err.response.status)) {
          toast({
            title: "Authentication required",
            description: "Please log in to view your payment details.",
            variant: "destructive",
          });
          navigate("/login", {
            state: { from: `${location.pathname}${location.search}` },
          });
        } else {
          toast({
            title: "Error",
            description: "Failed to load transaction details.",
            variant: "destructive",
          });
          setLoadError("Failed to load transaction details.");
        }
        setIsLoading(false);
      });
  };

  useEffect(() => {
    if (
      transactions.length === 0 &&
      paymentIntentId &&
      isValidPaymentIntentId(paymentIntentId)
    ) {
      fetchTransactions();
    }
  }, [transactions.length, paymentIntentId, apiInstance]);

  useEffect(() => {
    if (paymentIntentId && isValidPaymentIntentId(paymentIntentId)) {
      const interval = setInterval(() => {
        fetchTransactions();
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [paymentIntentId]);

  if (!paymentIntentId) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow py-16">
          <div className="container mx-auto px-4 max-w-2xl text-center space-y-6">
            <h1 className="text-3xl md:text-4xl font-bold text-culinary-navy">
              Payment Details Unavailable
            </h1>
            <p className="text-gray-600">
              We couldn't find your payment information. Please check your orders or
              contact support if you believe this is a mistake.
            </p>
            <div className="flex gap-4 justify-center">
              <Link to="/dashboard">
                <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90">
                  View Orders
                </Button>
              </Link>
              <Link to="/about-us">
                <Button variant="outline">Contact Support</Button>
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!isValidPaymentIntentId(paymentIntentId)) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow py-16">
          <div className="container mx-auto px-4 max-w-2xl text-center space-y-6">
            <h1 className="text-3xl md:text-4xl font-bold text-culinary-navy">
              Payment Details Unavailable
            </h1>
            <p className="text-gray-600">
              The payment reference provided is invalid. Please check your
              orders or contact support if you believe this is a mistake.
            </p>
            <div className="flex gap-4 justify-center">
              <Link to="/dashboard">
                <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90">
                  View Orders
                </Button>
              </Link>
              <Link to="/about-us">
                <Button variant="outline">Contact Support</Button>
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const transactionIds = transactions.map((t: any) => t.id).join(", ");
  const hasPotentialSuccess = transactions.some(
    (t: any) => t.status === "Paid" || t.status === "Processing"
  );

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow py-16">
        <div className="container mx-auto px-4 max-w-2xl">
          {hasPotentialSuccess && (
            <div className="bg-blue-50 border border-blue-200 text-blue-800 p-4 rounded-lg mb-8">
              <p>
                It looks like your payment may have gone through. Please check
                your dashboard for the latest status or contact support for
                assistance.
              </p>
            </div>
          )}
          <div className="text-center mb-8">
            <XCircle className="h-16 w-16 text-orange-500 mx-auto mb-4" />
            <h1 className="text-3xl md:text-4xl font-bold mb-4 text-culinary-navy">
              Payment Cancelled
            </h1>
            <p className="text-gray-600 text-lg">
              Your payment was not completed. No charges have been made to your account.
            </p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-culinary-navy">
                <HelpCircle className="h-5 w-5" />
                What Happened?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600">
                The payment process was interrupted or cancelled. This could happen for several reasons:
              </p>
              <ul className="space-y-2 text-gray-600 list-disc list-inside ml-4">
                <li>You clicked the back button or closed the payment window</li>
                <li>There was an issue with your payment method</li>
                <li>The payment session expired</li>
                <li>You chose to cancel the transaction</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-culinary-navy">
                <CreditCard className="h-5 w-5" />
                Payment Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {isLoading ? (
                <div
                  className="flex items-center justify-center py-4"
                  data-testid="loading"
                >
                  <Loader2 className="h-6 w-6 animate-spin text-culinary-navy" />
                  <span className="sr-only">Loading...</span>
                </div>
              ) : (
                <>
                  {loadError && (
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-red-600">{loadError}</p>
                      <Button variant="outline" size="sm" onClick={fetchTransactions}>
                        Retry
                      </Button>
                    </div>
                  )}
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Payment Intent ID:</span>
                    <span className="font-semibold">
                      {paymentIntentId || "Unavailable"}
                    </span>
                  </div>
                  {transactionIds && (
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Transaction ID(s):</span>
                      <span className="font-semibold">{transactionIds}</span>
                    </div>
                  )}
                </>
              )}
              {transactions.map((t: any) => (
                <div
                  key={t.id}
                  className="flex justify-between items-center text-sm"
                >
                  <div className="flex flex-col">
                    <span className="text-gray-600">{t.description}</span>
                    <span
                      className={`text-xs font-medium capitalize ${getStatusColor(
                        t.status
                      )}`}
                    >
                      {t.status}
                    </span>
                  </div>
                  <span className="font-semibold">${t.amount.toFixed(2)}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="bg-yellow-50 border border-yellow-200 p-6 rounded-lg mb-8">
            <h3 className="font-semibold text-yellow-800 mb-3">Your Cart is Still Saved</h3>
            <p className="text-yellow-700 mb-4">
              Don't worry! All items in your cart are still there. You can complete your purchase whenever you're ready.
            </p>
          </div>

          <div className="flex gap-4 justify-center">
            <Link to="/cart">
              <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90">
                <CreditCard className="h-4 w-4 mr-2" />
                Try Payment Again
              </Button>
            </Link>
            <Link to="/shop">
              <Button variant="outline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Continue Shopping
              </Button>
            </Link>
          </div>

          <div className="text-center mt-8">
            <p className="text-gray-500 text-sm">
              Need help? <Link to="/about-us" className="text-culinary-terracotta hover:underline">Contact our support team</Link>
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PaymentCancelled;
