import { Link, useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { useEffect, useMemo, useState, useRef } from "react";
import api from "@/utils/api";
import { isValidPaymentIntentId } from "@/utils/payment";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  CheckCircle,
  Package,
  ArrowRight,
  Home,
  ClipboardList,
  Loader2,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getStatusColor } from "@/utils/status";

const PaymentSuccess = () => {
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const paymentIntentId = searchParams.get("payment_intent_id");
  const [transactions, setTransactions] = useState<any[]>(
    () => (location.state as any)?.transactions || []
  );
  const [transactionStatus, setTransactionStatus] = useState<string | null>(
    (location.state as any)?.transactions?.[0]?.status || null
  );
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const apiInstance = useMemo(() => api, []);

  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchTransactions = () => {
    setLoadError(null);
    setIsLoading(true);
    apiInstance
      .get(`/api/users/me/transactions/${paymentIntentId}`)
      .then((r) => {
        setTransactions(r.data);
        setTransactionStatus(r.data?.[0]?.status || null);
        setIsLoading(false);
      })
      .catch((err) => {
        if (err?.response && [401, 403].includes(err.response.status)) {
          toast({
            title: "Authentication required",
            description: "Please log in to view your payment details.",
            variant: "destructive",
          });
          navigate("/login", {
            state: { from: `${location.pathname}${location.search}` },
          });
        } else {
          toast({
            title: "Error",
            description: "Failed to load transaction details.",
            variant: "destructive",
          });
          setLoadError("Failed to load transaction details.");
        }
        setIsLoading(false);
      });
  };

  const pollTransactions = () => {
    apiInstance
      .get(`/api/users/me/transactions/${paymentIntentId}`)
      .then((r) => {
        setTransactions(r.data);
        const status = r.data?.[0]?.status || null;
        setTransactionStatus(status);
        if (status && ["Paid", "Failed"].includes(status)) {
          if (pollingRef.current) {
            clearInterval(pollingRef.current);
            pollingRef.current = null;
          }
        }
      })
      .catch(() => {});
  };

  useEffect(() => {
    if (
      transactions.length === 0 &&
      paymentIntentId &&
      isValidPaymentIntentId(paymentIntentId)
    ) {
      fetchTransactions();
    }
  }, [transactions.length, paymentIntentId, apiInstance]);

  useEffect(() => {
    if (
      paymentIntentId &&
      isValidPaymentIntentId(paymentIntentId) &&
      transactionStatus &&
      !["Paid", "Failed"].includes(transactionStatus)
    ) {
      pollingRef.current = setInterval(pollTransactions, 3000);
    }
    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
        pollingRef.current = null;
      }
    };
  }, [paymentIntentId, transactionStatus, apiInstance]);

  if (!paymentIntentId) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow py-16">
          <div className="container mx-auto px-4 max-w-2xl text-center space-y-6">
            <h1 className="text-3xl md:text-4xl font-bold text-culinary-navy">
              Payment Details Unavailable
            </h1>
            <p className="text-gray-600">
              We couldn't find your payment information. Please check your orders or
              contact support if you believe this is a mistake.
            </p>
            <div className="flex gap-4 justify-center">
              <Link to="/dashboard">
                <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90">
                  View Orders
                </Button>
              </Link>
              <Link to="/about-us">
                <Button variant="outline">Contact Support</Button>
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!isValidPaymentIntentId(paymentIntentId)) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow py-16">
          <div className="container mx-auto px-4 max-w-2xl text-center space-y-6">
            <h1 className="text-3xl md:text-4xl font-bold text-culinary-navy">
              Payment Details Unavailable
            </h1>
            <p className="text-gray-600">
              The payment reference provided is invalid. Please check your
              orders or contact support if you believe this is a mistake.
            </p>
            <div className="flex gap-4 justify-center">
              <Link to="/dashboard">
                <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90">
                  View Orders
                </Button>
              </Link>
              <Link to="/about-us">
                <Button variant="outline">Contact Support</Button>
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const transactionIds = transactions.map((t: any) => t.id).join(", ");

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow py-16">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="text-center mb-8">
            <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h1 className="text-3xl md:text-4xl font-bold mb-4 text-culinary-navy">
              Payment Successful!
            </h1>
            <p className="text-gray-600 text-lg">
              Thank you for your purchase. Your order has been processed successfully.
            </p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-culinary-navy">
                <Package className="h-5 w-5" />
                Order Confirmation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {isLoading ? (
                <div
                  className="flex items-center justify-center py-4"
                  data-testid="loading"
                >
                  <Loader2 className="h-6 w-6 animate-spin text-culinary-navy" />
                  <span className="sr-only">Loading...</span>
                </div>
              ) : (
                <>
                  {loadError && (
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-red-600">{loadError}</p>
                      <Button variant="outline" size="sm" onClick={fetchTransactions}>
                        Retry
                      </Button>
                    </div>
                  )}
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Transaction ID(s):</span>
                    <span className="font-semibold">
                      {transactionIds || "Unavailable"}
                    </span>
                  </div>
                  {transactions.map((t: any) => (
                    <div
                      key={t.id}
                      className="flex justify-between items-center text-sm"
                    >
                      <div className="flex flex-col">
                        <span className="text-gray-600">{t.description}</span>
                        <span
                          className={`text-xs font-medium capitalize ${getStatusColor(
                            t.status
                          )}`}
                        >
                          {t.status}
                        </span>
                      </div>
                      <span className="font-semibold">${t.amount.toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Payment Status:</span>
                    <span
                      className={`${getStatusColor(
                        transactionStatus || ""
                      )} font-semibold capitalize`}
                    >
                      {transactionStatus || "Unavailable"}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Confirmation Email:</span>
                    <span className="text-sm text-gray-500">
                      Sent to your registered email
                    </span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <div className="bg-culinary-cream p-6 rounded-lg mb-8">
            <h3 className="font-semibold text-culinary-navy mb-3">What's Next?</h3>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-center gap-2">
                <ArrowRight className="h-4 w-4 text-culinary-terracotta" />
                You'll receive a confirmation email with order details
              </li>
              <li className="flex items-center gap-2">
                <ArrowRight className="h-4 w-4 text-culinary-terracotta" />
                For workshops, you'll get booking instructions via email
              </li>
              <li className="flex items-center gap-2">
                <ArrowRight className="h-4 w-4 text-culinary-terracotta" />
                Products will be prepared for pickup/delivery as scheduled
              </li>
            </ul>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/dashboard">
              <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90">
                <ClipboardList className="h-4 w-4 mr-2" />
                Track Order
              </Button>
            </Link>
            <Link to="/">
              <Button variant="outline">
                <Home className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <Link to="/shop">
              <Button variant="outline">Continue Shopping</Button>
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PaymentSuccess;
