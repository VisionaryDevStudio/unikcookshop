import { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import axios from "axios";
import { Clock, MapPin, ChefHat, Users, Tag } from "lucide-react";

interface Workshop {
  id: number;
  title: string;
  date: string;
  instructor: string;
  location: string;
  image?: string | null;
  description?: string | null;
  type?: string | null;
  cuisine?: string | null;
  level?: string | null;
  duration?: string | null;
  price?: number | null;
  spots?: number | null;
}

interface WorkshopExtended extends Workshop {
  type: string;
  typeLabel: string;
  cuisine: string;
  duration: string;
  price: string;
  spots: number | null;
  description: string;
  chef: string;
  level: string;
  featured?: boolean;
}

const Workshops = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const typeParam = queryParams.get("type");

  const [workshops, setWorkshops] = useState<WorkshopExtended[]>([]);
  const [filteredWorkshops, setFilteredWorkshops] = useState<WorkshopExtended[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [selectedType, setSelectedType] = useState<string>(typeParam || "all");
  const [selectedCuisine, setSelectedCuisine] = useState<string>("all");
  const [selectedLevel, setSelectedLevel] = useState<string>("all");

  useEffect(() => {
    axios
      .get(`${import.meta.env.VITE_API_BASE_URL}/api/public/workshops`)
      .then(r => {
        const typeLabels: Record<string, string> = {
          group: "Group Lesson",
          kids: "Kids Workshop",
          "date-night": "Date Night",
          private: "Private Session",
          "team-building": "Team Building",
          "crash-course": "Crash Course",
          seasonal: "Seasonal Special",
        };

        const mapped: WorkshopExtended[] = r.data.map((w: Workshop, index: number) => {
          const type = w.type || "group";
          const price =
            w.price !== null && w.price !== undefined
              ? w.price === 0
                ? "Free"
                : `$${w.price}`
              : "Free";

          return {
            ...w,
            type,
            typeLabel: typeLabels[type] || "Workshop",
            cuisine: w.cuisine || "Various",
            duration: w.duration || "TBD",
            price,
            spots: w.spots ?? null,
            description: w.description || "Description coming soon.",
            chef: w.instructor,
            level: w.level || "all-levels",
            featured: index === 0,
          };
        });
        setWorkshops(mapped);
        setLoading(false);
      })
      .catch(() => {
        setError(true);
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    let filtered = workshops;
    if (selectedType !== "all") {
      filtered = filtered.filter(w => w.type === selectedType);
    }
    if (selectedCuisine !== "all") {
      filtered = filtered.filter(w => w.cuisine === selectedCuisine);
    }
    if (selectedLevel !== "all") {
      filtered = filtered.filter(w => w.level === selectedLevel || w.level === "all-levels");
    }
    setFilteredWorkshops(filtered);
  }, [workshops, selectedType, selectedCuisine, selectedLevel]);

  if (loading) {
    return <div className="py-20 text-center">Loading...</div>;
  }

  if (error) {
    return (
      <div className="py-20 text-center text-red-500">
        Failed to load workshops
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow">
        {/* Hero */}
        <div className="bg-culinary-navy text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">Culinary Workshops</h1>
            <p className="text-lg max-w-2xl mx-auto">
              Discover and book from our wide range of hands-on cooking experiences led by expert chefs
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-culinary-cream py-6">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap gap-4 items-center justify-center md:justify-between">
              <h2 className="text-lg font-semibold text-culinary-navy">Filter Workshops:</h2>

              <div className="flex flex-wrap gap-4">
                <div className="w-40">
                  <Select value={selectedType} onValueChange={setSelectedType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Workshop Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="group">Group Lessons</SelectItem>
                      <SelectItem value="kids">Kids Workshops</SelectItem>
                      <SelectItem value="date-night">Date Night</SelectItem>
                      <SelectItem value="private">Private Sessions</SelectItem>
                      <SelectItem value="team-building">Team Building</SelectItem>
                      <SelectItem value="crash-course">Crash Course</SelectItem>
                      <SelectItem value="seasonal">Seasonal Special</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="w-40">
                  <Select value={selectedCuisine} onValueChange={setSelectedCuisine}>
                    <SelectTrigger>
                      <SelectValue placeholder="Cuisine" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Cuisines</SelectItem>
                      <SelectItem value="Italian">Italian</SelectItem>
                      <SelectItem value="Japanese">Japanese</SelectItem>
                      <SelectItem value="French">French</SelectItem>
                      <SelectItem value="Thai">Thai</SelectItem>
                      <SelectItem value="Mediterranean">Mediterranean</SelectItem>
                      <SelectItem value="Baking">Baking</SelectItem>
                      <SelectItem value="Fusion">Fusion</SelectItem>
                      <SelectItem value="Modern American">Modern American</SelectItem>
                      <SelectItem value="Various">Various</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="w-40">
                  <Select value={selectedLevel} onValueChange={setSelectedLevel}>
                    <SelectTrigger>
                      <SelectValue placeholder="Skill Level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Workshop Listings */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            {filteredWorkshops.length > 0 ? (
              <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                {filteredWorkshops.map(workshop => (
                  <div key={workshop.id} className="workshop-card overflow-hidden flex flex-col h-full">
                    <Link to={`/workshops/${workshop.id}`} className="relative h-48 overflow-hidden">
                      {workshop.image && (
                        <img
                          src={workshop.image}
                          alt={workshop.title}
                          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                        />
                      )}
                      <div className="absolute top-4 left-4 bg-culinary-terracotta text-white text-sm font-medium px-3 py-1 rounded-full">
                        {workshop.typeLabel}
                      </div>
                      {workshop.featured && (
                        <div className="absolute top-4 right-4 bg-culinary-butter text-culinary-navy text-sm font-medium px-3 py-1 rounded-full">
                          Featured
                        </div>
                      )}
                    </Link>
                    <div className="p-6 flex flex-col flex-grow">
                      <Link to={`/workshops/${workshop.id}`} className="group">
                        <h3 className="text-xl font-semibold mb-2 text-culinary-navy group-hover:text-culinary-terracotta transition-colors">
                          {workshop.title}
                        </h3>
                      </Link>
                      <p className="text-gray-600 mb-4">{workshop.description}</p>

                      <div className="flex flex-wrap gap-4 mb-4 text-sm text-gray-500">
                        <div className="flex items-center">
                          <ChefHat className="h-4 w-4 mr-1" />
                          <span>{workshop.chef}</span>
                        </div>
                        <div className="flex items-center">
                          <Tag className="h-4 w-4 mr-1" />
                          <span>{workshop.cuisine}</span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          <span>{workshop.duration}</span>
                        </div>
                        <div className="flex items-center">
                          <Users className="h-4 w-4 mr-1" />
                          <span>{workshop.spots !== null && workshop.spots !== undefined ? `${workshop.spots} spots` : "TBD"}</span>
                        </div>
                      </div>

                      <div className="mt-auto">
                        <div className="flex justify-between items-center mb-4">
                          <span className="text-xl font-bold text-culinary-navy">{workshop.price}</span>
                          <Link to={`/workshops/${workshop.id}`}>
                            <Button className="bg-culinary-sage hover:bg-culinary-sage/90">
                              View Details
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold mb-2 text-culinary-navy">No workshops found</h3>
                <p className="text-gray-600 mb-6">Try adjusting your filters to find available workshops.</p>
                <Button
                  variant="outline"
                  className="border-culinary-terracotta text-culinary-terracotta hover:bg-culinary-terracotta hover:text-white"
                  onClick={() => {
                    setSelectedType("all");
                    setSelectedCuisine("all");
                    setSelectedLevel("all");
                  }}
                >
                  Reset Filters
                </Button>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Workshops;
