import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import api from "@/utils/api";
import { toast } from "sonner";
import { Navigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Minus, Plus } from "lucide-react";

const schema = z.object({
  hero_title: z.string().min(1, { message: "Required" }),
  hero_subtitle: z.string().min(1, { message: "Required" }),
  hero_image: z.string().url({ message: "Must be a valid URL" }),
  inquiry_title: z.string().min(1, { message: "Required" }),
  inquiry_description: z.string().min(1, { message: "Required" }),
  expert_title: z.string().min(1, { message: "Required" }),
  expert_description: z.string().min(1, { message: "Required" }),
});

interface WorkshopType {
  id: number;
  title: string;
  description: string;
  icon: string;
  link: string;
}

type SettingsValues = z.infer<typeof schema>;

const AdminSiteSettings = () => {
  const { isAdmin, isAuthenticated } = useAuth();
  const form = useForm<SettingsValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      hero_title: "",
      hero_subtitle: "",
      hero_image: "",
      inquiry_title: "",
      inquiry_description: "",
      expert_title: "",
      expert_description: "",
    },
  });

  const [types, setTypes] = useState<WorkshopType[]>([]);

  useEffect(() => {
    api
      .get(`/api/admin/site-settings`)
      .then((res) => {
        const hp = res.data["homepage"] ? JSON.parse(res.data["homepage"]) : {};
        form.reset({
          hero_title: hp.hero_title || "",
          hero_subtitle: hp.hero_subtitle || "",
          hero_image: hp.hero_image || "",
          inquiry_title: hp.inquiry_title || "",
          inquiry_description: hp.inquiry_description || "",
          expert_title: hp.expert_title || "",
          expert_description: hp.expert_description || "",
        });
        setTypes(hp.workshop_types || []);
      })
      .catch(() => toast.error("Failed to load settings"));
  }, []);

  const addType = () => {
    setTypes([
      ...types,
      { id: Date.now(), title: "", description: "", icon: "Users", link: "" },
    ]);
  };

  const updateType = (index: number, field: keyof WorkshopType, value: string) => {
    const updated = [...types];
    updated[index][field] = value;
    setTypes(updated);
  };

  const removeType = (index: number) => {
    if (types.length > 1) {
      setTypes(types.filter((_, i) => i !== index));
    }
  };

  const onSubmit = (values: SettingsValues) => {
    api
      .put(
        `/api/admin/site-settings/homepage`,
        { value: JSON.stringify({ ...values, workshop_types: types }) },
      )
      .then(() => toast.success("Settings updated"))
      .catch(() => toast.error("Failed to update settings"));
  };

  if (!isAuthenticated || !isAdmin) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow py-8">
        <div className="container mx-auto px-4 space-y-6">
          <h1 className="text-3xl font-bold text-culinary-navy">Site Settings</h1>
          <Card>
            <CardHeader>
              <CardTitle>Homepage Content</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="hero_title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Hero Title</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="hero_subtitle"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Hero Subtitle</FormLabel>
                        <FormControl>
                          <Textarea rows={2} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="hero_image"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Hero Image URL</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="inquiry_title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Inquiry Section Title</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="inquiry_description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Inquiry Description</FormLabel>
                        <FormControl>
                          <Textarea rows={3} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="expert_title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Expert Section Title</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="expert_description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Expert Description</FormLabel>
                        <FormControl>
                          <Textarea rows={3} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="space-y-3">
                    <h3 className="font-semibold text-lg text-culinary-navy">
                      Workshop Types
                    </h3>
                    {types.map((type, index) => (
                      <div key={type.id} className="grid grid-cols-1 md:grid-cols-5 gap-2 items-start">
                        <Input
                          value={type.title}
                          onChange={(e) => updateType(index, "title", e.target.value)}
                          placeholder="Title"
                          className="md:col-span-1"
                        />
                        <Input
                          value={type.icon}
                          onChange={(e) => updateType(index, "icon", e.target.value)}
                          placeholder="Icon"
                          className="md:col-span-1"
                        />
                        <Input
                          value={type.link}
                          onChange={(e) => updateType(index, "link", e.target.value)}
                          placeholder="Link"
                          className="md:col-span-1"
                        />
                        <Textarea
                          value={type.description}
                          onChange={(e) => updateType(index, "description", e.target.value)}
                          placeholder="Description"
                          rows={2}
                          className="md:col-span-2"
                        />
                        {types.length > 1 && (
                          <Button type="button" variant="outline" size="icon" onClick={() => removeType(index)}>
                            <Minus className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                    <Button type="button" variant="outline" onClick={addType} className="mt-2">
                      <Plus className="h-4 w-4 mr-2" /> Add Type
                    </Button>
                  </div>

                  <div className="pt-4">
                    <Button type="submit">Save Settings</Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AdminSiteSettings;
