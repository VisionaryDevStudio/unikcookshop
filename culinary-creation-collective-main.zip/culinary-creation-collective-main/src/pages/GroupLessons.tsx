import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import axios from "axios";
import { Clock, MapPin, ChefHat } from "lucide-react";
import { Link } from "react-router-dom";
import { formatUserDate } from "@/utils/timezone";

interface Workshop {
  id: number;
  title: string;
  date: string;
  instructor: string;
  location: string;
}

const GroupLessons = () => {
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    axios
      .get(`${import.meta.env.VITE_API_BASE_URL}/api/public/workshops`)
      .then(r => {
        setWorkshops(r.data);
        setLoading(false);
      })
      .catch(() => {
        setError(true);
        setLoading(false);
      });
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold text-culinary-navy mb-8 text-center">
            Group Lessons
          </h1>
          {loading && <p className="text-center">Loading...</p>}
          {error && (
            <p className="text-center text-red-500">Failed to load workshops</p>
          )}
          {!loading && !error && workshops.length === 0 && (
            <p className="text-center">No workshops available</p>
          )}
          {!loading && !error && workshops.length > 0 && (
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {workshops.map(workshop => (
                <div
                  key={workshop.id}
                  className="p-6 bg-white rounded-lg shadow flex flex-col"
                >
                  <h2 className="text-xl font-semibold mb-2 text-culinary-navy">
                    {workshop.title}
                  </h2>
                  <div className="text-gray-600 space-y-1 mb-4">
                    <div className="flex items-center">
                      <ChefHat className="h-4 w-4 mr-2" />
                      {workshop.instructor}
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2" />
                      {formatUserDate(workshop.date)}
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-2" />
                      {workshop.location}
                    </div>
                  </div>
                  <div className="mt-auto">
                    <Link to={`/workshops/${workshop.id}`}>
                      <Button className="bg-culinary-sage hover:bg-culinary-sage/90 w-full">
                        View Details
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default GroupLessons;
