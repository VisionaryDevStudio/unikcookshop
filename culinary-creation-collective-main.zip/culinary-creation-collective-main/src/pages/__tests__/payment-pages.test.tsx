import { render, screen, waitFor, act } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import PaymentSuccess from "../PaymentSuccess";
import PaymentCancelled from "../PaymentCancelled";
import { getStatusColor } from "@/utils/status";

const navigateMock = vi.fn();
vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>(
    "react-router-dom"
  );
  return {
    ...actual,
    useNavigate: () => navigateMock,
  };
});

vi.mock("@/components/Navbar", () => ({ default: () => <div /> }));
vi.mock("@/components/Footer", () => ({ default: () => <div /> }));
vi.mock("@/hooks/use-toast", () => ({ useToast: () => ({ toast: vi.fn() }) }));

const getMock = vi.fn(() => Promise.reject(new Error("error")));
const createMock = vi.fn(() => ({
  get: getMock,
  interceptors: { request: { use: vi.fn() } },
}));

vi.mock("axios", () => ({
  default: { create: createMock },
  __esModule: true,
}));

const testPaymentIntentId = "pi_1";

describe("payment pages error handling", () => {
  beforeEach(() => {
    getMock.mockClear();
    createMock.mockClear();
    navigateMock.mockClear();
  });

  it("shows message when payment_intent_id missing on PaymentSuccess", () => {
    render(
      <MemoryRouter initialEntries={["/success"]}>
        <PaymentSuccess />
      </MemoryRouter>
    );
    expect(
      screen.getByText(/Payment Details Unavailable/i)
    ).toBeInTheDocument();
    expect(getMock).not.toHaveBeenCalled();
  });

  it("shows message when payment_intent_id missing on PaymentCancelled", () => {
    render(
      <MemoryRouter initialEntries={["/cancelled"]}>
        <PaymentCancelled />
      </MemoryRouter>
    );
    expect(
      screen.getByText(/Payment Details Unavailable/i)
    ).toBeInTheDocument();
    expect(getMock).not.toHaveBeenCalled();
  });

  it("shows message when payment_intent_id invalid on PaymentSuccess", () => {
    render(
      <MemoryRouter initialEntries={["/success?payment_intent_id=invalid"]}>
        <PaymentSuccess />
      </MemoryRouter>
    );
    expect(
      screen.getByText(/The payment reference provided is invalid/i)
    ).toBeInTheDocument();
    expect(getMock).not.toHaveBeenCalled();
  });

  it("shows message when payment_intent_id invalid on PaymentCancelled", () => {
    render(
      <MemoryRouter initialEntries={["/cancelled?payment_intent_id=invalid"]}>
        <PaymentCancelled />
      </MemoryRouter>
    );
    expect(
      screen.getByText(/The payment reference provided is invalid/i)
    ).toBeInTheDocument();
    expect(getMock).not.toHaveBeenCalled();
  });

  it("shows error message on PaymentSuccess when fetch fails", async () => {
    render(
      <MemoryRouter
        initialEntries={[`/success?payment_intent_id=${testPaymentIntentId}`]}
      >
        <PaymentSuccess />
      </MemoryRouter>
    );
    await waitFor(() =>
      expect(
        screen.getByText(/Failed to load transaction details/i)
      ).toBeInTheDocument()
    );
    expect(getMock).toHaveBeenCalledWith(
      `/api/users/me/transactions/${testPaymentIntentId}`
    );
  });

  it("shows error message on PaymentCancelled when fetch fails", async () => {
    render(
      <MemoryRouter
        initialEntries={[`/cancelled?payment_intent_id=${testPaymentIntentId}`]}
      >
        <PaymentCancelled />
      </MemoryRouter>
    );
    await waitFor(() =>
      expect(
        screen.getByText(/Failed to load transaction details/i)
      ).toBeInTheDocument()
    );
    expect(getMock).toHaveBeenCalledWith(
      `/api/users/me/transactions/${testPaymentIntentId}`
    );
  });

  it("redirects to login on PaymentSuccess when unauthorized", async () => {
    getMock.mockImplementationOnce(() =>
      Promise.reject({ response: { status: 401 } })
    );

    render(
      <MemoryRouter
        initialEntries={[`/success?payment_intent_id=${testPaymentIntentId}`]}
      >
        <PaymentSuccess />
      </MemoryRouter>
    );
    await waitFor(() =>
      expect(navigateMock).toHaveBeenCalledWith(
        "/login",
        { state: { from: `/success?payment_intent_id=${testPaymentIntentId}` } }
      )
    );
    expect(getMock).toHaveBeenCalledWith(
      `/api/users/me/transactions/${testPaymentIntentId}`
    );
  });

  it("redirects to login on PaymentCancelled when unauthorized", async () => {
    getMock.mockImplementationOnce(() =>
      Promise.reject({ response: { status: 403 } })
    );

    render(
      <MemoryRouter
        initialEntries={[`/cancelled?payment_intent_id=${testPaymentIntentId}`]}
      >
        <PaymentCancelled />
      </MemoryRouter>
    );
    await waitFor(() =>
      expect(navigateMock).toHaveBeenCalledWith(
        "/login",
        { state: { from: `/cancelled?payment_intent_id=${testPaymentIntentId}` } }
      )
    );
    expect(getMock).toHaveBeenCalledWith(
      `/api/users/me/transactions/${testPaymentIntentId}`
    );
  });
});

describe("payment status display", () => {
  beforeEach(() => {
    getMock.mockClear();
    createMock.mockClear();
    navigateMock.mockClear();
  });

  it("shows transaction status from provided data", () => {
    const transactions = [
      { id: 1, description: "Test", amount: 10, status: "Processing" },
    ];
    render(
      <MemoryRouter
        initialEntries={[
          {
            pathname: "/success",
            search: `?payment_intent_id=${testPaymentIntentId}`,
            state: { transactions },
          },
        ]}
      >
        <PaymentSuccess />
      </MemoryRouter>
    );

    const statusLabel = screen.getByText(/Payment Status:/i);
    expect(statusLabel.nextElementSibling).toHaveTextContent(/Processing/i);
    expect(statusLabel.nextElementSibling).toHaveClass(getStatusColor("Processing"));
    expect(getMock).not.toHaveBeenCalled();
  });

  it.each([
    ["Paid", "text-green-600"],
    ["Processing", "text-yellow-600"],
    ["Refunded", "text-blue-600"],
    ["Failed", "text-red-600"],
    ["Canceled", "text-gray-600"],
    ["Disputed", "text-purple-600"],
  ])("shows %s status with correct color", (status, expectedClass) => {
    const transactions = [{ id: 1, description: "Test", amount: 10, status }];
    render(
      <MemoryRouter
        initialEntries={[
          {
            pathname: "/success",
            search: `?payment_intent_id=${testPaymentIntentId}`,
            state: { transactions },
          },
        ]}
      >
        <PaymentSuccess />
      </MemoryRouter>
    );

    const statusValue = screen.getByText(/Payment Status:/i)
      .nextElementSibling as HTMLElement;
    expect(statusValue).toHaveTextContent(new RegExp(status, "i"));
    expect(statusValue).toHaveClass(expectedClass);
  });
});

describe("payment status colors", () => {
  beforeEach(() => {
    getMock.mockClear();
    createMock.mockClear();
    navigateMock.mockClear();
  });

  const cases: [string, string][] = [
    ["Paid", "text-green-600"],
    ["Processing", "text-yellow-600"],
    ["Refunded", "text-blue-600"],
    ["Failed", "text-red-600"],
    ["Canceled", "text-gray-600"],
    ["Disputed", "text-orange-600"],
  ];

  it.each(cases)("renders %s status with correct color", (status, colorClass) => {
    const transactions = [
      { id: 1, description: "Test", amount: 10, status },
    ];
    render(
      <MemoryRouter
        initialEntries={[
          {
            pathname: "/success",
            search: `?payment_intent_id=${testPaymentIntentId}`,
            state: { transactions },
          },
        ]}
      >
        <PaymentSuccess />
      </MemoryRouter>
    );

    const statusLabel = screen.getByText(/Payment Status:/i);
    const statusElement = statusLabel.nextElementSibling as HTMLElement;
    expect(statusElement).toHaveTextContent(new RegExp(status, "i"));
    expect(statusElement).toHaveClass(colorClass);
    expect(getMock).not.toHaveBeenCalled();
  });
});

describe("payment pages loading state", () => {
  beforeEach(() => {
    getMock.mockClear();
    createMock.mockClear();
    navigateMock.mockClear();
  });

  it("shows loading indicator on PaymentSuccess while fetching", async () => {
    getMock.mockImplementationOnce(
      () => new Promise(() => {}) // never resolves
    );

    render(
      <MemoryRouter
        initialEntries={[`/success?payment_intent_id=${testPaymentIntentId}`]}
      >
        <PaymentSuccess />
      </MemoryRouter>
    );

    await waitFor(() =>
      expect(screen.getByTestId("loading")).toBeInTheDocument()
    );
  });

  it("shows loading indicator on PaymentCancelled while fetching", async () => {
    getMock.mockImplementationOnce(
      () => new Promise(() => {})
    );

    render(
      <MemoryRouter
        initialEntries={[`/cancelled?payment_intent_id=${testPaymentIntentId}`]}
      >
        <PaymentCancelled />
      </MemoryRouter>
    );

    await waitFor(() =>
      expect(screen.getByTestId("loading")).toBeInTheDocument()
    );
  });
});

describe("status color classes", () => {
  beforeEach(() => {
    getMock.mockClear();
    createMock.mockClear();
    navigateMock.mockClear();
  });

  const scenarios: [string, string][] = [
    ["Paid", getStatusColor("Paid")],
    ["Canceled", getStatusColor("Canceled")],
    ["Disputed", getStatusColor("Disputed")],
  ];

  it.each(scenarios)(
    "applies %s status class on success and cancel pages",
    (status, expectedClass) => {
      const transactions = [
        { id: 1, description: "Test", amount: 10, status },
      ];

      render(
        <MemoryRouter
          initialEntries={[
            {
              pathname: "/success",
            search: `?payment_intent_id=${testPaymentIntentId}`,
            state: { transactions },
          },
        ]}
      >
        <PaymentSuccess />
        </MemoryRouter>
      );

      const statusElSuccess = screen.getByText(status);
      expect(statusElSuccess).toHaveClass(expectedClass);

      render(
        <MemoryRouter
          initialEntries={[
            {
              pathname: "/cancelled",
              search: `?payment_intent_id=${testPaymentIntentId}`,
              state: { transactions },
            },
          ]}
        >
          <PaymentCancelled />
        </MemoryRouter>
      );

      const statusElCancel = screen.getByText(status);
      expect(statusElCancel).toHaveClass(expectedClass);
    }
  );
});

describe("payment polling", () => {
  beforeEach(() => {
    getMock.mockClear();
    createMock.mockClear();
    navigateMock.mockClear();
  });

  it("polls transactions until status is Paid", async () => {
    vi.useFakeTimers();

    getMock
      .mockResolvedValueOnce({
        data: [
          { id: 1, description: "Test", amount: 10, status: "Processing" },
        ],
      })
      .mockResolvedValueOnce({
        data: [
          { id: 1, description: "Test", amount: 10, status: "Paid" },
        ],
      });

    render(
      <MemoryRouter
        initialEntries={[`/success?payment_intent_id=${testPaymentIntentId}`]}
      >
        <PaymentSuccess />
      </MemoryRouter>
    );

    await waitFor(() =>
      expect(getMock).toHaveBeenCalledWith(
        `/api/users/me/transactions/${testPaymentIntentId}`
      )
    );

    const statusLabel = screen.getByText(/Payment Status:/i);
    expect(statusLabel.nextElementSibling).toHaveTextContent(/Processing/i);

    await act(async () => {
      vi.advanceTimersByTime(3000);
    });

    await waitFor(() =>
      expect(statusLabel.nextElementSibling).toHaveTextContent(/Paid/i)
    );
    expect(getMock).toHaveBeenCalledTimes(2);

    await act(async () => {
      vi.advanceTimersByTime(3000);
    });
    expect(getMock).toHaveBeenCalledTimes(2);

    vi.useRealTimers();
  });

  it("stops polling when component unmounts", async () => {
    vi.useFakeTimers();

    getMock.mockResolvedValue({
      data: [
        { id: 1, description: "Test", amount: 10, status: "Processing" },
      ],
    });

    const { unmount } = render(
      <MemoryRouter
        initialEntries={[`/success?payment_intent_id=${testPaymentIntentId}`]}
      >
        <PaymentSuccess />
      </MemoryRouter>
    );

    await waitFor(() =>
      expect(getMock).toHaveBeenCalledWith(
        `/api/users/me/transactions/${testPaymentIntentId}`
      )
    );

    unmount();

    await act(async () => {
      vi.advanceTimersByTime(3000);
    });
    expect(getMock).toHaveBeenCalledTimes(1);

    vi.useRealTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("refreshes transactions and updates status", async () => {
    const transactions = [
      { id: 1, description: "Test", amount: 10, status: "Pending" },
    ];

    getMock.mockResolvedValueOnce({
      data: [
        { id: 1, description: "Test", amount: 10, status: "Paid" },
      ],
    });

    render(
      <MemoryRouter
        initialEntries={[
          {
            pathname: "/cancelled",
            search: `?payment_intent_id=${testPaymentIntentId}`,
            state: { transactions },
          },
        ]}
      >
        <PaymentCancelled />
      </MemoryRouter>
    );

    expect(screen.queryByText(/may have gone through/i)).not.toBeInTheDocument();

    await vi.advanceTimersByTimeAsync(5000);

    await waitFor(() =>
      expect(screen.getByText(/may have gone through/i)).toBeInTheDocument()
    );
    expect(screen.getByText(/Paid/i)).toBeInTheDocument();
    expect(getMock).toHaveBeenCalledWith(
      `/api/users/me/transactions/${testPaymentIntentId}`
    );
  });
});

