import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import Cart from "../Cart";

const mockGet = vi.fn();
vi.mock("@/utils/api", () => ({
  default: { get: mockGet },
}));

vi.mock("@/components/Navbar", () => ({ default: () => <div /> }));
vi.mock("@/components/Footer", () => ({ default: () => <div /> }));
vi.mock("@/components/PaymentModal", () => ({ PaymentModal: () => <div /> }));

vi.mock("@/context/CartContext", () => ({
  useCart: () => ({
    cartItems: [
      {
        id: 1,
        name: "Knife Set",
        price: 10,
        category: "Tools",
        image: "url",
        quantity: 1,
        type: "product",
      },
    ],
    removeFromCart: vi.fn(),
    updateQuantity: vi.fn(),
    clearCart: vi.fn(),
    getCartTotal: vi.fn(() => 10),
  }),
}));

vi.mock("@/context/AuthContext", () => ({
  useAuth: () => ({ isAuthenticated: true }),
}));

describe("Cart page", () => {
  beforeEach(() => {
    mockGet.mockReset();
  });

  it("shows subtotal and total", async () => {
    mockGet.mockResolvedValueOnce({ data: { subtotal: 10 } });

    render(
      <MemoryRouter>
        <Cart />
      </MemoryRouter>
    );

    expect(await screen.findAllByText("$10.00")).toHaveLength(3);
    expect(screen.queryByText("Shipping")).not.toBeInTheDocument();

  });
});
