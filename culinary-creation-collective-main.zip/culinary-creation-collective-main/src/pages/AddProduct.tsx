import { useState, useRef, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Upload, Eye, Star, ShoppingBag, Package, DollarSign, Tag, Hash } from "lucide-react";
import { toast } from "sonner";
import api from "@/utils/api";

const AddProduct = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const editingProduct = (location.state as any)?.product as any | undefined;
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [productData, setProductData] = useState({
    name: editingProduct?.name ?? "",
    price: editingProduct?.price ? editingProduct.price.toString() : "",
    originalPrice: editingProduct?.originalPrice ? editingProduct.originalPrice.toString() : "",
    category: editingProduct?.category ?? "",
    description: editingProduct?.description ?? "",
    features: editingProduct?.features?.length ? editingProduct.features : [""],
    specifications: editingProduct?.specifications ?? { key: "", value: "" },
    stock: editingProduct?.stock_count ? editingProduct.stock_count.toString() : "",
    images: [
      editingProduct?.image ??
        "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    ],
    tags: editingProduct?.tags ?? "",
    rating: editingProduct?.rating ?? 4.5,
    reviewCount: editingProduct?.reviewCount ?? 0,

  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const [activeSpecifications, setActiveSpecifications] = useState(
    editingProduct?.specifications
      ? Object.entries(editingProduct.specifications).map(([key, value]) => ({ key, value }))
      : [
          { key: "Material", value: "" },
          { key: "Dimensions", value: "" },
          { key: "Weight", value: "" },
          { key: "Care Instructions", value: "" },
        ]
  );

  useEffect(() => {
    if (editingProduct) {
      setProductData({
        name: editingProduct.name ?? "",
        price: editingProduct.price ? editingProduct.price.toString() : "",
        originalPrice: editingProduct.originalPrice
          ? editingProduct.originalPrice.toString()
          : "",
        category: editingProduct.category ?? "",
        description: editingProduct.description ?? "",
        features: editingProduct.features?.length ? editingProduct.features : [""],
        specifications: editingProduct.specifications ?? { key: "", value: "" },
        stock: editingProduct.stock_count ? editingProduct.stock_count.toString() : "",
        images: [
          editingProduct.image ??
            "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        ],
        tags: editingProduct.tags ?? "",
        rating: editingProduct.rating ?? 4.5,
        reviewCount: editingProduct.reviewCount ?? 0,
      });

      if (editingProduct.specifications) {
        setActiveSpecifications(
          Object.entries(editingProduct.specifications).map(([key, value]) => ({ key, value }))
        );
      }
    }
  }, [editingProduct]);

  const categories = [
    "Kitchen Tools",
    "Cookware", 
    "Bakeware",
    "Appliances",
    "Ingredients",
    "Spices",
    "Books",
    "Accessories",
    "Cutlery"
  ];

  const handleInputChange = (field: string, value: string) => {
    setProductData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleFeatureChange = (index: number, value: string) => {
    const newFeatures = [...productData.features];
    newFeatures[index] = value;
    setProductData(prev => ({
      ...prev,
      features: newFeatures
    }));
  };

  const addFeature = () => {
    setProductData(prev => ({
      ...prev,
      features: [...prev.features, ""]
    }));
  };

  const removeFeature = (index: number) => {
    const newFeatures = productData.features.filter((_, i) => i !== index);
    setProductData(prev => ({
      ...prev,
      features: newFeatures
    }));
  };

  const handleSpecificationChange = (index: number, field: 'key' | 'value', value: string) => {
    const newSpecs = [...activeSpecifications];
    newSpecs[index][field] = value;
    setActiveSpecifications(newSpecs);
  };

  const addSpecification = () => {
    setActiveSpecifications([...activeSpecifications, { key: "", value: "" }]);
  };

  const handleImageAdd = () => {
    const newImage = prompt("Enter image URL:");
    if (newImage) {
      setProductData(prev => ({
        ...prev,
        images: [...prev.images, newImage]
      }));
    }
  };

  const handleImageRemove = (index: number) => {
    setProductData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const handleSetMainImage = (index: number) => {
    setProductData(prev => {
      const newImages = [...prev.images];
      const [selected] = newImages.splice(index, 1);
      newImages.unshift(selected);
      return { ...prev, images: newImages };
    });
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    const formData = new FormData();
    formData.append('file', file);
    try {
      const res = await api.post(
        `/api/admin/upload-image`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );
      const imgPath = res.data.path;
      setProductData(prev => ({ ...prev, images: [...prev.images, imgPath] }));
    } catch {
      toast.error('Failed to upload image');
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async () => {
    if (!productData.name || !productData.price || !productData.category || !productData.description) {
      toast.error("Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);

    try {
      if (editingProduct) {
        await api.put(
          `/api/admin/products/${editingProduct.id}`,
          {
            name: productData.name,
            price: parseFloat(productData.price),
            image: productData.images[0],
            images: productData.images,
            category: productData.category,
            description: productData.description,
            features: productData.features.filter(f => f),
            specifications: Object.fromEntries(
              activeSpecifications.filter(s => s.key && s.value).map(s => [s.key, s.value])
            ),
            stock_count: parseInt(productData.stock || "0"),
          },
        );
        toast.success("Product updated successfully!");
      } else {
        await api.post(
          `/api/admin/products`,
          {
            name: productData.name,
            price: parseFloat(productData.price),
            image: productData.images[0],
            images: productData.images,
            category: productData.category,
            description: productData.description,
            features: productData.features.filter(f => f),
            specifications: Object.fromEntries(
              activeSpecifications.filter(s => s.key && s.value).map(s => [s.key, s.value])
            ),
            stock_count: parseInt(productData.stock || "0"),
          },
        );
        toast.success("Product created successfully!");
      }
      navigate("/admin");
    } catch {
      toast.error(editingProduct ? "Failed to update product" : "Failed to create product");
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatPrice = (price: string) => {
    return price ? `$${parseFloat(price).toFixed(2)}` : "$0.00";
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      
      <main className="flex-grow py-8">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <Button 
              variant="outline" 
              onClick={() => navigate("/admin")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Admin
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-culinary-navy">{editingProduct ? 'Edit Product' : 'Add New Product'}</h1>
              <p className="text-gray-600">{editingProduct ? 'Update product details' : 'Create a new product with live preview'}</p>
            </div>
          </div>

          <div className="space-y-8">
            {/* Form Section */}
            <div className="space-y-6 max-w-4xl mx-auto">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    Basic Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Product Name *</Label>
                    <Input
                      id="name"
                      placeholder="e.g., Professional Chef Knife"
                      value={productData.name}
                      onChange={(e) => handleInputChange("name", e.target.value)}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="price">Price *</Label>
                      <div className="relative">
                        <DollarSign className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="price"
                          type="number"
                          placeholder="29.99"
                          className="pl-10"
                          value={productData.price}
                          onChange={(e) => handleInputChange("price", e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="originalPrice">Original Price</Label>
                      <div className="relative">
                        <DollarSign className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="originalPrice"
                          type="number"
                          placeholder="39.99"
                          className="pl-10"
                          value={productData.originalPrice}
                          onChange={(e) => handleInputChange("originalPrice", e.target.value)}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="category">Category *</Label>
                      <Select value={productData.category} onValueChange={(value) => handleInputChange("category", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="stock">Stock Quantity</Label>
                      <div className="relative">
                        <Hash className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="stock"
                          type="number"
                          placeholder="50"
                          className="pl-10"
                          value={productData.stock}
                          onChange={(e) => handleInputChange("stock", e.target.value)}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description *</Label>
                    <Textarea
                      id="description"
                      placeholder="Detailed product description..."
                      rows={4}
                      value={productData.description}
                      onChange={(e) => handleInputChange("description", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tags">Tags (comma-separated)</Label>
                    <Input
                      id="tags"
                      placeholder="professional, kitchen, tool, chef"
                      value={productData.tags}
                      onChange={(e) => handleInputChange("tags", e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Features */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="h-5 w-5" />
                    Key Features
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {productData.features.map((feature, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        placeholder={`Feature ${index + 1}`}
                        value={feature}
                        onChange={(e) => handleFeatureChange(index, e.target.value)}
                        className="flex-1"
                      />
                      {productData.features.length > 1 && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeFeature(index)}
                        >
                          Remove
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button variant="outline" onClick={addFeature} className="w-full">
                    Add Feature
                  </Button>
                </CardContent>
              </Card>

              {/* Specifications */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Tag className="h-5 w-5" />
                    Specifications
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {activeSpecifications.map((spec, index) => (
                    <div key={index} className="grid grid-cols-2 gap-2">
                      <Input
                        placeholder="Specification name"
                        value={spec.key}
                        onChange={(e) => handleSpecificationChange(index, 'key', e.target.value)}
                      />
                      <Input
                        placeholder="Value"
                        value={spec.value}
                        onChange={(e) => handleSpecificationChange(index, 'value', e.target.value)}
                      />
                    </div>
                  ))}
                  <Button variant="outline" onClick={addSpecification} className="w-full">
                    Add Specification
                  </Button>
                </CardContent>
              </Card>

              {/* Images */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="h-5 w-5" />
                    Product Images
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    {productData.images.map((image, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={image}
                          alt={`Product ${index + 1}`}
                          className="w-full h-32 object-cover rounded-lg border"
                        />
                        {index === 0 && (
                          <span className="absolute top-1 left-1 bg-culinary-terracotta text-white text-xs px-1 rounded">Main</span>
                        )}
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center gap-2">
                          {index !== 0 && (
                            <Button variant="secondary" size="sm" className="text-xs" onClick={() => handleSetMainImage(index)}>
                              Set Main
                            </Button>
                          )}
                          <Button variant="destructive" size="sm" className="text-xs" onClick={() => handleImageRemove(index)}>
                            Delete
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    ref={fileInputRef}
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => fileInputRef.current?.click()} className="flex-1">
                      <Upload className="h-4 w-4 mr-2" />
                      Upload Image
                    </Button>
                    <Button variant="outline" onClick={handleImageAdd} className="flex-1">
                      <Upload className="h-4 w-4 mr-2" />
                      Add Image URL
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Submit */}
              <div className="flex gap-4">
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="bg-culinary-terracotta hover:bg-culinary-terracotta/90 flex-1"
                  size="lg"
                >
                  {isSubmitting
                    ? editingProduct
                      ? 'Updating Product...'
                      : 'Creating Product...'
                    : editingProduct
                      ? 'Update Product'
                      : 'Create Product'}
                </Button>
                <Button variant="outline" onClick={() => navigate("/admin")} size="lg">
                  Cancel
                </Button>
              </div>
            </div>

            {/* Live Preview Section - Product Detail Style */}
            <div className="mt-16">
              <h2 className="text-2xl font-bold mb-6 text-culinary-navy flex items-center gap-2">
                <Eye className="h-6 w-6" />
                Live Preview - Product Detail Page
              </h2>
              
              <div className="grid lg:grid-cols-2 gap-12 border-2 border-dashed border-gray-300 rounded-lg p-8 bg-gray-50/50">
                {/* Product Images */}
                <div className="space-y-4">
                  <div className="aspect-square overflow-hidden rounded-lg bg-gray-100">
                    <img
                      src={productData.images[0]}
                      alt={productData.name || "Product preview"}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex gap-2 overflow-x-auto">
                    {productData.images.map((image, index) => (
                      <button
                        key={index}
                        onClick={() => handleSetMainImage(index)}
                        className={`relative flex-shrink-0 w-20 h-20 rounded-md overflow-hidden border-2 ${index === 0 ? 'border-culinary-terracotta' : 'border-gray-200'}`}
                      >
                        {index === 0 && (
                          <span className="absolute top-1 left-1 bg-culinary-terracotta text-white text-xs px-1 rounded">Main</span>
                        )}
                        <img src={image} alt={`Preview ${index + 1}`} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Product Info */}
                <div className="space-y-6">
                  <div>
                    <Badge variant="secondary" className="mb-2">
                      {productData.category || "Category"}
                    </Badge>
                    <h1 className="text-3xl font-bold text-culinary-navy mb-2">
                      {productData.name || "Product Name"}
                    </h1>
                    
                    <div className="flex items-center gap-4 mb-4">
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i}
                            className={`h-4 w-4 ${i < Math.floor(productData.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                          />
                        ))}
                        <span className="text-sm text-gray-600 ml-1">({productData.reviewCount} reviews)</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 mb-4">
                      <span className="text-3xl font-bold text-culinary-navy">
                        {formatPrice(productData.price)}
                      </span>
                      {productData.originalPrice && (
                        <span className="text-lg text-gray-500 line-through">
                          {formatPrice(productData.originalPrice)}
                        </span>
                      )}
                    </div>

                    <p className="text-gray-600 leading-relaxed">
                      {productData.description || "Product description will appear here..."}
                    </p>
                  </div>

                  {/* Stock Status */}
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${parseInt(productData.stock) > 10 ? 'bg-green-500' : 'bg-orange-500'}`}></div>
                    <span className={`text-sm font-medium ${parseInt(productData.stock) > 10 ? 'text-green-600' : 'text-orange-600'}`}>
                      {productData.stock ? `In Stock (${productData.stock} available)` : 'Stock quantity not set'}
                    </span>
                  </div>

                  {/* Quantity and Add to Cart */}
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <label className="text-sm font-medium">Quantity:</label>
                      <div className="flex items-center border rounded-md">
                        <button className="px-3 py-1 hover:bg-gray-100">-</button>
                        <span className="px-4 py-1 border-x">1</span>
                        <button className="px-3 py-1 hover:bg-gray-100">+</button>
                      </div>
                    </div>

                    <Button
                      className="bg-culinary-terracotta hover:bg-culinary-terracotta/90 flex-1"
                      size="lg"
                      disabled
                    >
                      <ShoppingBag className="h-4 w-4 mr-2" />
                      Add to Cart
                    </Button>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-3">
                    <Button variant="outline" size="sm" className="flex-1" disabled>
                      <Star className="h-4 w-4 mr-2" />
                      Add to Wishlist
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1" disabled>
                      <Star className="h-4 w-4 mr-2" />
                      Share
                    </Button>
                  </div>

                  {/* Features */}
                  <Card>
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-3 text-culinary-navy">Key Features</h3>
                      <ul className="space-y-2">
                        {productData.features.filter(f => f.trim()).map((feature, index) => (
                          <li key={index} className="flex items-center gap-2 text-sm">
                            <div className="w-2 h-2 rounded-full bg-culinary-terracotta"></div>
                            {feature}
                          </li>
                        ))}
                        {productData.features.filter(f => f.trim()).length === 0 && (
                          <li className="text-sm text-gray-500">Add features to see them here...</li>
                        )}
                      </ul>
                    </CardContent>
                  </Card>

                  {/* Shipping Info */}
                  <div className="grid grid-cols-3 gap-4 text-center text-sm">
                    <div className="flex flex-col items-center gap-2">
                      <Package className="h-6 w-6 text-culinary-terracotta" />
                      <span className="font-medium">Free Shipping</span>
                      <span className="text-gray-500">On orders $50+</span>
                    </div>
                    <div className="flex flex-col items-center gap-2">
                      <Star className="h-6 w-6 text-culinary-terracotta" />
                      <span className="font-medium">2 Year Warranty</span>
                      <span className="text-gray-500">Quality guaranteed</span>
                    </div>
                    <div className="flex flex-col items-center gap-2">
                      <ArrowLeft className="h-6 w-6 text-culinary-terracotta" />
                      <span className="font-medium">30-Day Returns</span>
                      <span className="text-gray-500">Hassle-free returns</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Product Specifications Preview */}
              <div className="mt-8">
                <h3 className="text-xl font-bold mb-4 text-culinary-navy">Product Specifications Preview</h3>
                <Card>
                  <CardContent className="p-6">
                    <div className="grid md:grid-cols-2 gap-8">
                      <div>
                        <h4 className="font-semibold mb-4 text-culinary-navy">Specifications</h4>
                        <div className="space-y-3">
                          {activeSpecifications.filter(s => s.key && s.value).map((spec, index) => (
                            <div key={index} className="flex justify-between">
                              <span className="text-gray-600">{spec.key}:</span>
                              <span className="font-medium">{spec.value}</span>
                            </div>
                          ))}
                          {activeSpecifications.filter(s => s.key && s.value).length === 0 && (
                            <p className="text-sm text-gray-500">Add specifications to see them here...</p>
                          )}
                        </div>
                      </div>

                      {productData.tags && (
                        <div>
                          <h4 className="font-semibold mb-4 text-culinary-navy">Tags</h4>
                          <div className="flex flex-wrap gap-2">
                            {productData.tags.split(',').map((tag, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {tag.trim()}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default AddProduct;