import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChefHat, Award, Clock, Heart, Users, Star, Briefcase, Handshake, Calendar, Trophy, Rocket, Flag, Map, Building, MessageSquare, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 }
  }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

const founderData = [
  {
    name: "Parsati Maji",
    role: "Co-Founder & Culinary Instructor",
    image: "/lovable-uploads/ecd310c4-dec1-4a77-8737-3558d816539a.png",
    bio: "Parsati is a dedicated culinary and chef instructor who is passionate about creating healthy eating habits and cuisine. She loves to explore creativity through cooking and has curated special classes for teenagers and young adults to practice healthy eating habits. Her recipes are budget friendly, time friendly, and use fresh local seasonal ingredients.",
    quote: "We are changing the industry by teaching life lessons through culinary arts, bringing community together with diverse culture; making friends through feasts.",
    achievements: ["Award-Winning Chef", "10+ Years Experience", "Certified Nutritionist"],
    favoriteCuisine: "Indian Fusion"
  },
  {
    name: "Shivam Maji",
    role: "Co-Founder & Technical Director",
    image: "/lovable-uploads/20ae5eff-e5a6-4d9d-939e-ebd401e105d2.png",
    bio: "As a first-generation immigrant, Shivam grew up in a family of avid home cooks who bonded over food. His coding and photography skills allowed him to blend both passions into UnikCookShop - an online platform making home cooking education accessible while facilitating cultural exchange. Leveraging his technical background, he built UnikCookShop from the ground up, creating courses on cooking techniques and world cuisines.",
    quote: "The site has grown into a hub where home chefs share family recipes and chronicle their journeys. My aim is to continue expanding this thriving community and empowering people to explore their culinary roots.",
    achievements: ["Software Development Expert", "Food Photography Specialist", "Digital Marketing Guru"],
    favoriteCuisine: "Global Fusion"
  }
];

const milestoneData = [
  { 
    year: "2015", 
    event: "Unikcookshop founded with a single small kitchen and three workshops per week",
    icon: <Flag className="h-6 w-6 text-white" />,
    color: "bg-gradient-to-r from-amber-500 to-pink-500"
  },
  { 
    year: "2017", 
    event: "Expanded to current location with three teaching kitchens and retail space",
    icon: <Building className="h-6 w-6 text-white" />,
    color: "bg-gradient-to-r from-blue-500 to-teal-400"
  },
  { 
    year: "2019", 
    event: "Launched online shop with curated cooking tools and ingredients",
    icon: <Briefcase className="h-6 w-6 text-white" />,
    color: "bg-gradient-to-r from-violet-500 to-purple-400"
  },
  { 
    year: "2020", 
    event: "Introduced virtual cooking classes during global pandemic",
    icon: <Users className="h-6 w-6 text-white" />,
    color: "bg-gradient-to-r from-emerald-500 to-lime-400"
  },
  { 
    year: "2022", 
    event: "Celebrated teaching our 10,000th student",
    icon: <Trophy className="h-6 w-6 text-white" />,
    color: "bg-gradient-to-r from-rose-500 to-orange-400"
  },
  { 
    year: "2023", 
    event: "Won 'Best Culinary Workshop' in the city for the third consecutive year",
    icon: <Award className="h-6 w-6 text-white" />,
    color: "bg-gradient-to-r from-fuchsia-500 to-pink-400"
  }
];

const valueTiles = [
  {
    icon: <ChefHat className="w-10 h-10 text-culinary-terracotta" />,
    title: "Culinary Excellence",
    description: "We're committed to teaching proper techniques and maintaining the highest standards in everything we do."
  },
  {
    icon: <Users className="w-10 h-10 text-culinary-terracotta" />,
    title: "Inclusive Learning",
    description: "Our workshops are designed for all skill levels, creating a supportive environment for everyone to learn."
  },
  {
    icon: <Heart className="w-10 h-10 text-culinary-terracotta" />,
    title: "Passion for Food",
    description: "We believe cooking is an expression of creativity and love that brings people together."
  },
  {
    icon: <Award className="w-10 h-10 text-culinary-terracotta" />,
    title: "Quality Ingredients",
    description: "We source the finest seasonal and local ingredients to ensure authentic and delicious results."
  }
];

const reviewData = [
  {
    name: "Sarah Johnson",
    avatar: "SJ",
    date: "March, 2024",
    rating: 5,
    comment: "The pasta making workshop was incredible! Chef Parsati taught us techniques that I've been struggling with for years. The atmosphere was welcoming and I met some wonderful fellow food enthusiasts. Can't wait to come back for the bread baking class!",
    workshop: "Italian Pasta Masterclass"
  },
  {
    name: "Michael Chen",
    avatar: "MC",
    date: "February, 2024",
    rating: 5,
    comment: "I attended the Indian Spice Journey workshop and it completely transformed my home cooking. The instructors were patient and knowledgeable, explaining not just how but why certain techniques work. The small class size meant I got plenty of personal attention.",
    workshop: "Indian Spice Journey"
  },
  {
    name: "Emily Rodriguez",
    avatar: "ER",
    date: "January, 2024",
    rating: 4,
    comment: "My teenager and I took the Family Cooking Basics course together and it's been such a bonding experience. The recipes were practical enough for weeknight dinners but still exciting and flavorful. The kitchen facilities are top-notch too!",
    workshop: "Family Cooking Basics"
  }
];

const AboutUs = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <section className="relative h-[70vh] lg:h-[80vh] overflow-hidden flex items-center">
          <motion.div 
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1.5 }}
            className="absolute inset-0 z-0"
          >
            <div 
              className="absolute inset-0 bg-culinary-navy/80 z-10"
              style={{ mixBlendMode: 'multiply' }}
            ></div>
            <div 
              className="absolute inset-0 bg-cover bg-center z-0"
              style={{ 
                backgroundImage: 'url("https://images.unsplash.com/photo-1556910103-1c02745aae4d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80")',
              }}
            ></div>
          </motion.div>

          <div className="container mx-auto px-4 relative z-20">
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="max-w-3xl text-white"
            >
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
                Our Culinary <motion.span 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.8 }}
                  className="text-culinary-butter"
                >Story</motion.span>
              </h1>
              
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.5 }}
              >
                <p className="text-xl md:text-2xl mb-8 font-light max-w-2xl">
                  Journey with us through our passion for food, teaching, and bringing people together through the art of cooking.
                </p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.9 }}
                className="flex gap-6 items-center"
              >
                <motion.div 
                  whileHover={{ scale: 1.05, rotate: 5 }}
                  className="inline-block bg-culinary-terracotta p-4 rounded-full shadow-lg"
                >
                  <ChefHat className="h-8 w-8 text-white" />
                </motion.div>
                
                <div className="h-px w-16 bg-culinary-butter opacity-60"></div>
                
                <p className="text-culinary-cream italic">
                  "Bringing communities together through diverse cuisines"
                </p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.2, duration: 0.8 }}
                className="absolute bottom-12 left-1/2 transform -translate-x-1/2 hidden md:block"
              >
                <motion.div
                  animate={{ y: [0, 10, 0] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                >
                  <svg className="w-8 h-8 text-white opacity-80" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
                  </svg>
                </motion.div>
              </motion.div>
            </motion.div>
          </div>
        </section>

        <section className="py-16 bg-white overflow-hidden">
          <div className="container mx-auto px-4">
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeIn}
              className="max-w-4xl mx-auto text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-culinary-navy relative inline-block">
                Our Story
                <motion.div 
                  initial={{ width: 0 }}
                  whileInView={{ width: '100%' }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                  viewport={{ once: true }}
                  className="absolute -bottom-2 left-0 h-1 bg-culinary-terracotta rounded-full"
                />
              </h2>
            </motion.div>
            
            <div className="flex flex-col md:flex-row items-center gap-12 mb-16">
              <motion.div 
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.7 }}
                viewport={{ once: true }}
                className="md:w-1/2"
              >
                <div className="prose prose-lg max-w-none text-gray-700 space-y-4">
                  <p className="text-lg leading-relaxed">
                    <span className="text-xl font-semibold text-culinary-terracotta">Unikcookshop began in 2015</span> as a small passion project between two friends who shared a love for cooking and teaching. What started in a tiny rented kitchen with just a handful of students has blossomed into one of the city's premier culinary education spaces.
                  </p>
                  <p className="text-lg leading-relaxed">
                    Our mission has always been to demystify cooking techniques, inspire creativity in the kitchen, and build a community around the shared joy of food. We believe that cooking is both an art and a science—one that anyone can master with the right guidance.
                  </p>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.7 }}
                viewport={{ once: true }}
                className="md:w-1/2 relative"
              >
                <div className="relative rounded-lg overflow-hidden shadow-xl">
                  <img 
                    src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
                    alt="Cooking class in progress" 
                    className="w-full h-auto object-cover aspect-video"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-culinary-navy/60 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <p className="text-sm font-medium">Our first workshop, 2015</p>
                  </div>
                </div>
                
                <motion.div 
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                  viewport={{ once: true }}
                  className="absolute -bottom-8 -right-8 bg-culinary-butter p-4 rounded-lg shadow-lg rotate-3 z-10 hidden md:block"
                >
                  <p className="text-culinary-navy font-medium text-sm">From 3 students to over 10,000!</p>
                </motion.div>
              </motion.div>
            </div>
            
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              viewport={{ once: true }}
              className="my-16"
            >
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div className="relative h-full">
                  <div className="grid grid-cols-2 gap-4 relative z-10">
                    <motion.div 
                      whileHover={{ scale: 1.05, rotate: -2 }} 
                      className="rounded-lg overflow-hidden shadow-md"
                    >
                      <img 
                        src="https://images.unsplash.com/photo-1556911220-e15b29be8c8f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
                        alt="Cooking class" 
                        className="w-full h-full object-cover aspect-square"
                      />
                    </motion.div>
                    <motion.div 
                      whileHover={{ scale: 1.05, rotate: 2 }} 
                      className="rounded-lg overflow-hidden shadow-md translate-y-8"
                    >
                      <img 
                        src="https://images.unsplash.com/photo-1507048331197-7d4ac70811cf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
                        alt="Cooking ingredients" 
                        className="w-full h-full object-cover aspect-square"
                      />
                    </motion.div>
                    <motion.div 
                      whileHover={{ scale: 1.05, rotate: 2 }} 
                      className="rounded-lg overflow-hidden shadow-md -translate-y-4"
                    >
                      <img 
                        src="https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
                        alt="Chef preparing food" 
                        className="w-full h-full object-cover aspect-square"
                      />
                    </motion.div>
                    <motion.div 
                      whileHover={{ scale: 1.05, rotate: -2 }} 
                      className="rounded-lg overflow-hidden shadow-md translate-y-4"
                    >
                      <img 
                        src="https://images.unsplash.com/photo-1549590143-d5855148a9d5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
                        alt="People enjoying food" 
                        className="w-full h-full object-cover aspect-square"
                      />
                    </motion.div>
                  </div>
                  <div className="absolute inset-0 transform -rotate-3 bg-culinary-terracotta/10 rounded-lg -z-10"></div>
                </div>
                
                <motion.div 
                  initial={{ opacity: 0, x: 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.7 }}
                  viewport={{ once: true }}
                >
                  <div className="prose prose-lg max-w-none text-gray-700 space-y-4">
                    <p className="text-lg leading-relaxed">
                      These events are not only cooking classes, but we share stories, emotions, create experiences, and explore global cuisines. We bring communities together through diverse cultures, making friends through feasts and teaching life lessons through culinary arts.
                    </p>
                    <p className="text-lg leading-relaxed">
                      Today, our state-of-the-art teaching kitchen hosts dozens of workshops each week, led by professional chefs and culinary experts. From fundamental knife skills to specialized ethnic cuisines, we offer experiences that cater to every interest and skill level.
                    </p>
                    
                    <motion.div 
                      whileHover={{ scale: 1.03 }}
                      className="bg-culinary-cream rounded-lg p-6 shadow-sm mt-8"
                    >
                      <blockquote className="border-l-4 border-culinary-terracotta pl-4 italic">
                        <p className="text-lg text-culinary-navy">"Through food, we connect hearts and minds, creating memories that last a lifetime."</p>
                        <footer className="text-culinary-terracotta font-medium">— Parsati Maji, Co-Founder</footer>
                      </blockquote>
                    </motion.div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              viewport={{ once: true }}
              className="flex flex-col items-center justify-center mt-16 text-center"
            >
              <div className="inline-block bg-culinary-navy p-4 rounded-full shadow-lg mb-8">
                <ChefHat className="h-8 w-8 text-white" />
              </div>
              
              <h3 className="text-2xl font-bold text-culinary-navy mb-6">From Small Beginnings to Culinary Excellence</h3>
              
              <div className="max-w-2xl mx-auto flex gap-3 mb-8">
                {[1, 2, 3].map((_, index) => (
                  <motion.div
                    key={index}
                    initial={{ width: 0 }}
                    whileInView={{ width: '100%' }}
                    transition={{ duration: 0.5, delay: index * 0.2 }}
                    viewport={{ once: true }}
                    className="h-1 bg-culinary-terracotta rounded-full flex-1"
                  />
                ))}
              </div>
              
              <motion.p 
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
                className="text-xl text-gray-700 italic max-w-3xl"
              >
                "We never could have imagined how much our little cooking workshop would grow. 
                What started as a hobby has become our life's work—bringing people together through 
                the universal language of food."
              </motion.p>
            </motion.div>
          </div>
        </section>
        
        <section className="py-20 bg-culinary-cream/50 relative overflow-hidden">
          <div className="absolute inset-0 opacity-5 pointer-events-none">
            <div className="h-full w-full bg-[url('https://images.unsplash.com/photo-1547592180-85f173990554?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')] bg-repeat bg-center"></div>
          </div>
          
          <div className="container mx-auto px-4 relative z-10">
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeIn}
              className="text-center mb-16"
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="inline-block"
              >
                <div className="flex items-center justify-center gap-3 mb-4">
                  <div className="h-px w-10 bg-culinary-terracotta"></div>
                  <Users className="h-6 w-6 text-culinary-terracotta" />
                  <div className="h-px w-10 bg-culinary-terracotta"></div>
                </div>
                <h2 className="text-3xl md:text-4xl font-bold mb-3 text-culinary-navy">Meet Our Founders</h2>
              </motion.div>
              
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.6 }}
                viewport={{ once: true }}
                className="text-lg text-gray-600 max-w-2xl mx-auto"
              >
                Our culinary journey is led by passionate experts who bring their unique experiences and love for food to every class we offer.
              </motion.p>
            </motion.div>

            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={staggerContainer}
              className="grid md:grid-cols-2 gap-10 max-w-5xl mx-auto"
            >
              {founderData.map((founder, index) => (
                <motion.div 
                  key={founder.name}
                  variants={fadeIn}
                  className="relative"
                >
                  <Card className="overflow-hidden bg-white border-none shadow-xl">
                    <div className="relative">
                      <div className="aspect-square overflow-hidden">
                        <motion.img 
                          whileHover={{ scale: 1.05 }}
                          transition={{ duration: 0.4 }}
                          src={founder.image} 
                          alt={founder.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-6">
                        <h3 className="text-2xl font-bold text-white mb-1">{founder.name}</h3>
                        <p className="text-culinary-butter font-medium">{founder.role}</p>
                      </div>
                    </div>
                    
                    <CardContent className="p-6">
                      <div className="mb-6">
                        <p className="text-gray-700 leading-relaxed">{founder.bio}</p>
                      </div>
                      
                      <div className="mb-6">
                        <div className="bg-culinary-navy/5 p-4 rounded-lg border-l-4 border-culinary-terracotta">
                          <p className="italic text-culinary-navy text-sm">"{founder.quote}"</p>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h4 className="font-semibold text-culinary-navy flex items-center gap-2">
                          <Award className="h-4 w-4 text-culinary-terracotta" />
                          Achievements
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {founder.achievements.map((achievement, i) => (
                            <motion.span 
                              key={i}
                              whileHover={{ y: -3 }}
                              className="px-3 py-1 bg-culinary-cream text-culinary-navy text-sm rounded-full"
                            >
                              {achievement}
                            </motion.span>
                          ))}
                        </div>
                        
                        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
                          <div className="flex items-center gap-2">
                            <ChefHat className="h-4 w-4 text-culinary-terracotta" />
                            <span className="text-sm text-gray-600">Favorite: {founder.favoriteCuisine}</span>
                          </div>
                          
                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            className="text-sm text-culinary-terracotta font-medium hover:underline"
                          >
                            Connect
                          </motion.button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <motion.div 
                    initial={{ opacity: 0, x: index === 0 ? -20 : 20, y: 20 }}
                    whileInView={{ opacity: 1, x: 0, y: 0 }}
                    transition={{ delay: 0.6, duration: 0.5 }}
                    viewport={{ once: true }}
                    className={`absolute ${index === 0 ? '-bottom-4 -left-4' : '-bottom-4 -right-4'} z-10`}
                  >
                    <div className={`w-16 h-16 rounded-full ${index === 0 ? 'bg-culinary-butter' : 'bg-culinary-terracotta'} flex items-center justify-center shadow-lg`}>
                      {index === 0 ? (
                        <ChefHat className="h-8 w-8 text-culinary-navy" />
                      ) : (
                        <Briefcase className="h-8 w-8 text-white" />
                      )}
                    </div>
                  </motion.div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>
        
        <section className="py-24 bg-gradient-to-br from-culinary-navy to-slate-900 text-white relative overflow-hidden">
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 0.2 }}
            transition={{ duration: 1.5 }}
            viewport={{ once: true }}
            className="absolute inset-0 z-0"
          >
            <div className="absolute top-10 right-10 w-72 h-72 bg-culinary-butter/20 rounded-full blur-3xl"></div>
            <div className="absolute bottom-20 left-10 w-80 h-80 bg-culinary-terracotta/20 rounded-full blur-3xl"></div>
          </motion.div>

          <div className="container mx-auto px-4 relative z-10">
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeIn}
              className="mb-20 text-center"
            >
              <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="inline-block mb-4"
              >
                <div className="inline-flex items-center gap-3 mb-4">
                  <div className="h-0.5 w-10 bg-culinary-terracotta"></div>
                  <Rocket className="h-8 w-8 text-culinary-terracotta" />
                  <div className="h-0.5 w-10 bg-culinary-terracotta"></div>
                </div>
                <h2 className="text-4xl md:text-5xl font-bold my-4 relative inline-block">
                  Our Culinary Journey
                </h2>
                <div className="flex gap-2 items-center justify-center mt-4">
                  {[1, 2, 3, 4, 5].map((_, index) => (
                    <motion.div
                      key={index}
                      initial={{ width: 0 }}
                      whileInView={{ width: '100%' }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      viewport={{ once: true }}
                      className="h-1 bg-gradient-to-r from-culinary-terracotta to-culinary-butter rounded-full w-5 sm:w-10"
                    />
                  ))}
                </div>
              </motion.div>
              
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.6 }}
                viewport={{ once: true }}
                className="text-xl text-gray-300 max-w-2xl mx-auto"
              >
                From humble beginnings to culinary excellence, explore the key moments that shaped who we are today.
              </motion.p>
            </motion.div>
            
            <div className="max-w-5xl mx-auto">
              <div className="relative">
                <motion.div 
                  initial={{ height: 0 }}
                  whileInView={{ height: '100%' }}
                  transition={{ duration: 1.5, ease: "easeInOut" }}
                  viewport={{ once: true }}
                  className="absolute left-1/2 transform -translate-x-1/2 w-1 bg-gradient-to-b from-culinary-terracotta via-culinary-butter to-culinary-cream h-full rounded-full hidden md:block"
                ></motion.div>

                {milestoneData.map((milestone, index) => (
                  <Collapsible key={index} className="mb-20 relative">
                    <motion.div 
                      initial={{ opacity: 0, y: 50 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1, duration: 0.7 }}
                      viewport={{ once: true }}
                      className={`flex flex-col ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}
                    >
                      <div className="md:w-1/2 flex flex-col items-center mb-6 md:mb-0">
                        <motion.div 
                          whileHover={{ scale: 1.1, rotate: 5 }}
                          className={`w-16 h-16 ${milestone.color} rounded-full flex items-center justify-center shadow-lg z-20`}
                        >
                          {milestone.icon}
                        </motion.div>
                        <div className="text-center mt-3">
                          <motion.div
                            whileHover={{ scale: 1.05 }}
                            transition={{ duration: 0.2 }}
                            className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-culinary-terracotta to-culinary-butter"
                          >
                            {milestone.year}
                          </motion.div>
                        </div>
                      </div>

                      <div className={`md:w-1/2 flex ${index % 2 === 0 ? 'justify-start' : 'justify-end'}`}>
                        <CollapsibleTrigger className="w-full">
                          <motion.div
                            whileHover={{ scale: 1.03, y: -5 }}
                            className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 backdrop-blur-sm p-6 rounded-xl shadow-xl border border-gray-700 w-full max-w-md cursor-pointer"
                          >
                            <div className="flex items-start gap-4">
                              <div className="flex-grow">
                                <p className="text-xl text-white font-medium mb-3">{milestone.event}</p>
                                <div className="text-sm text-gray-400 flex items-center gap-2 mt-2">
                                  <Calendar className="h-4 w-4" />
                                  <span>Click to learn more</span>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        </CollapsibleTrigger>
                        
                        <CollapsibleContent>
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.3 }}
                            className="bg-gradient-to-br from-slate-800/60 to-slate-900/70 backdrop-blur-sm p-6 rounded-xl mt-4 border border-gray-700 w-full max-w-md"
                          >
                            {index === 0 && (
                              <div className="space-y-4">
                                <p>With a shared passion for cooking and teaching, our founders started with just one small rented kitchen and a dream to create an inclusive culinary community.</p>
                                <div className="grid grid-cols-2 gap-2 mt-3">
                                  <div className="rounded-lg overflow-hidden bg-slate-800">
                                    <img src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80" alt="First workshop" className="w-full h-24 object-cover" />
                                  </div>
                                  <div className="rounded-lg overflow-hidden bg-slate-800">
                                    <img src="https://images.unsplash.com/photo-1507048331197-7d4ac70811cf?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80" alt="First ingredients" className="w-full h-24 object-cover" />
                                  </div>
                                </div>
                              </div>
                            )}
                            {index === 1 && (
                              <div className="space-y-4">
                                <p>After two years of growth, we moved to our current location featuring three fully equipped teaching kitchens and a retail space for culinary tools.</p>
                                <div className="flex items-center justify-start gap-4 mt-2">
                                  <span className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-xs">3 Kitchens</span>
                                  <span className="px-3 py-1 bg-green-500/20 text-green-300 rounded-full text-xs">Retail Shop</span>
                                  <span className="px-3 py-1 bg-amber-500/20 text-amber-300 rounded-full text-xs">Event Space</span>
                                </div>
                              </div>
                            )}
                            {index === 2 && (
                              <div className="space-y-4">
                                <p>We expanded our offerings by launching an online shop with a curated selection of kitchen tools, specialty ingredients, and cookbooks recommended by our chefs.</p>
                                <div className="flex items-center justify-start gap-2 mt-3">
                                  <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
                                  <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
                                  <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
                                  <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
                                  <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
                                  <span className="text-gray-400 text-sm ml-2">500+ products</span>
                                </div>
                              </div>
                            )}
                            {index === 3 && (
                              <div className="space-y-4">
                                <p>When the world changed, so did we. We quickly adapted by creating virtual cooking experiences that brought our expertise into homes around the country.</p>
                                <div className="flex justify-between items-center mt-3">
                                  <div className="text-sm text-gray-400">
                                    <Map className="h-4 w-4 inline mr-1" /> 
                                    <span>Nationwide reach</span>
                                  </div>
                                  <div className="text-sm text-gray-400">
                                    <Users className="h-4 w-4 inline mr-1" /> 
                                    <span>5,000+ virtual students</span>
                                  </div>
                                </div>
                              </div>
                            )}
                            {index === 4 && (
                              <div className="space-y-4">
                                <p>A major milestone as we celebrated teaching our 10,000th student - a testament to our growing community and the quality of our culinary education.</p>
                                <div className="relative h-4 bg-gray-700 rounded-full mt-4">
                                  <div className="absolute left-0 top-0 h-full w-3/4 bg-gradient-to-r from-culinary-terracotta to-culinary-butter rounded-full"></div>
                                  <div className="absolute -top-6 left-3/4 transform -translate-x-1/2 text-xs font-medium text-white">75%</div>
                                </div>
                                <div className="text-center text-xs text-gray-400 mt-1">Goal: 10,000 students</div>
                              </div>
                            )}
                            {index === 5 && (
                              <div className="space-y-4">
                                <p>Our commitment to excellence was recognized as we won the city's Best Culinary Workshop award for the third consecutive year, cementing our reputation as the premier cooking school in the region.</p>
                                <div className="flex items-center justify-center gap-4 mt-3">
                                  <div className="flex">
                                    {[1, 2, 3].map((year) => (
                                      <div key={year} className="relative mx-1">
                                        <Award className="h-8 w-8 text-yellow-400" />
                                        <span className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-[10px] font-bold">
                                          {2021 + year - 1}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            )}
                          </motion.div>
                        </CollapsibleContent>
                      </div>
                    </motion.div>
                  </Collapsible>
                ))}
              </div>
            </div>
          </div>
        </section>
        
        <section className="py-24 bg-white relative overflow-hidden">
          <div className="absolute inset-0 opacity-5 pointer-events-none">
            <div className="h-full w-full bg-[url('https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')] bg-repeat bg-center"></div>
          </div>
          
          <div className="container mx-auto px-4 relative z-10">
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeIn}
              className="text-center mb-16"
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="inline-block"
              >
                <div className="flex items-center justify-center gap-3 mb-4">
                  <div className="h-px w-10 bg-culinary-terracotta"></div>
                  <MessageSquare className="h-6 w-6 text-culinary-terracotta" />
                  <div className="h-px w-10 bg-culinary-terracotta"></div>
                </div>
                <h2 className="text-3xl md:text-4xl font-bold mb-3 text-culinary-navy">What Our Students Say</h2>
              </motion.div>
              
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.6 }}
                viewport={{ once: true }}
                className="text-lg text-gray-600 max-w-2xl mx-auto"
              >
                The true measure of our success is the satisfaction and growth of our students. Here are a few stories from our culinary community.
              </motion.p>
            </motion.div>

            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={staggerContainer}
              className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto"
            >
              {reviewData.map((review, index) => (
                <motion.div 
                  key={review.name}
                  variants={fadeIn}
                  whileHover={{ y: -8 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="h-full bg-white border border-gray-100 shadow-md hover:shadow-xl transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarImage src="" alt={review.name} />
                            <AvatarFallback className="bg-culinary-terracotta text-white">{review.avatar}</AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-semibold text-culinary-navy">{review.name}</h4>
                            <p className="text-sm text-gray-500">{review.date}</p>
                          </div>
                        </div>
                        <div className="flex">
                          {Array.from({ length: review.rating }).map((_, i) => (
                            <Star key={i} className="h-4 w-4 text-amber-400 fill-amber-400" />
                          ))}
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <p className="text-gray-700 italic">"{review.comment}"</p>
                      </div>
                      
                      <div className="mt-4 pt-4 border-t border-gray-100">
                        <div className="flex items-center gap-2">
                          <ChefHat className="h-4 w-4 text-culinary-terracotta" />
                          <span className="text-sm text-gray-600 font-medium">{review.workshop}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
            
            <div className="mt-12 text-center">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.6 }}
                viewport={{ once: true }}
              >
                <Link to="/workshops" className="inline-flex items-center text-culinary-terracotta hover:text-culinary-navy font-medium transition-colors">
                  <span>Read more reviews</span>
                  <div className="ml-1 w-5 h-5 rounded-full bg-culinary-terracotta/10 flex items-center justify-center">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M6 12L10 8L6 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                </Link>
              </motion.div>
            </div>
          </div>
        </section>
        
        <section className="py-20 bg-gradient-to-r from-culinary-navy to-slate-800 text-white relative overflow-hidden">
          <div className="absolute inset-0 z-0">
            <div className="absolute inset-0 bg-black/30 z-10"></div>
            <div 
              className="absolute inset-0 bg-cover bg-center z-0 opacity-40"
              style={{ 
                backgroundImage: 'url("https://images.unsplash.com/photo-1551218808-94e220e084d2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80")',
                backgroundPosition: 'center 30%'
              }}
            ></div>
          </div>
          
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto">
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7 }}
                viewport={{ once: true }}
                className="text-center mb-10"
              >
                <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                  Ready to Start Your <span className="text-culinary-butter">Culinary Journey</span>?
                </h2>
                <p className="text-xl text-culinary-cream/90 mb-8 max-w-2xl mx-auto">
                  Join our upcoming workshops and transform your cooking skills with guidance from our expert chefs.
                </p>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-white/10 backdrop-blur-sm p-8 md:p-10 rounded-2xl shadow-lg border border-white/20"
              >
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <h3 className="text-2xl font-semibold mb-4 text-culinary-butter">Featured Upcoming Workshops</h3>
                    <ul className="space-y-4">
                      <li className="flex items-start gap-3">
                        <div className="mt-1 rounded-full bg-culinary-terracotta/20 p-1 flex-shrink-0">
                          <ChefHat className="h-4 w-4 text-culinary-terracotta" />
                        </div>
                        <div>
                          <p className="font-medium">Mediterranean Feast</p>
                          <p className="text-sm text-gray-300">April 15, 2024 • 6:00 PM - 9:00 PM</p>
                        </div>
                      </li>
                      <li className="flex items-start gap-3">
                        <div className="mt-1 rounded-full bg-culinary-terracotta/20 p-1 flex-shrink-0">
                          <ChefHat className="h-4 w-4 text-culinary-terracotta" />
                        </div>
                        <div>
                          <p className="font-medium">Artisan Bread Baking</p>
                          <p className="text-sm text-gray-300">April 22, 2024 • 10:00 AM - 2:00 PM</p>
                        </div>
                      </li>
                      <li className="flex items-start gap-3">
                        <div className="mt-1 rounded-full bg-culinary-terracotta/20 p-1 flex-shrink-0">
                          <ChefHat className="h-4 w-4 text-culinary-terracotta" />
                        </div>
                        <div>
                          <p className="font-medium">Sushi & Japanese Basics</p>
                          <p className="text-sm text-gray-300">April 30, 2024 • 6:00 PM - 9:00 PM</p>
                        </div>
                      </li>
                    </ul>
                    
                    <div className="mt-6 flex flex-col sm:flex-row gap-4">
                      <Button asChild className="bg-culinary-terracotta hover:bg-culinary-terracotta/90 text-white">
                        <Link to="/booking">Book a Class</Link>
                      </Button>
                      <Button asChild variant="outline" className="border-white/30 text-white hover:bg-white/10">
                        <Link to="/workshops">View All Workshops</Link>
                      </Button>
                    </div>
                  </div>
                  
                  <div className="hidden md:block">
                    <div className="relative">
                      <motion.div 
                        whileHover={{ scale: 1.03, rotate: 2 }}
                        className="rounded-lg overflow-hidden shadow-xl"
                      >
                        <img 
                          src="https://images.unsplash.com/photo-1528712306091-ed0763094c98?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80" 
                          alt="Cooking class in progress" 
                          className="w-full h-64 object-cover rounded-lg"
                        />
                      </motion.div>
                      
                      <motion.div 
                        initial={{ opacity: 0, y: 20, x: 20 }}
                        whileInView={{ opacity: 1, y: 0, x: 0 }}
                        transition={{ delay: 0.6, duration: 0.5 }}
                        viewport={{ once: true }}
                        className="absolute -bottom-4 -right-4"
                      >
                        <div className="bg-culinary-butter text-culinary-navy px-4 py-2 rounded shadow-lg transform rotate-3">
                          <div className="flex items-center gap-2">
                            <Phone className="h-4 w-4" />
                            <span className="text-sm font-medium">Call us: (555) 123-4567</span>
                          </div>
                        </div>
                      </motion.div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default AboutUs;
