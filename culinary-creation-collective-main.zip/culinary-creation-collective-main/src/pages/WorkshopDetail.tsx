import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { toast } from "sonner";
import { useCart } from "@/context/CartContext";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import {
  ChefHat,
  Clock,
  Calendar as CalendarIcon,
  Users,
  Tag,
  Leaf,
  ShoppingCart,
  Star,
  MessageSquare,
} from "lucide-react";
import { formatUserDate, getTimeZoneForLocation } from "@/utils/timezone";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";

interface Workshop {
  id: number;
  title: string;
  date: string;
  instructor: string;
  location: string;
  image?: string | null;
  price?: number;

  description?: string | null;
  type?: string | null;
  cuisine?: string | null;
  level?: string | null;
  duration?: string | null;
  price?: number | null;
  spots?: number | null;
  full_description?: string | null;
  what_youll_make?: string | null;
  seasonal_ingredients?: string[] | null;
  learning_outcomes?: string[] | null;
}

const WorkshopDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [workshop, setWorkshop] = useState<Workshop | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState<string>("10:00 AM");
  const [participants, setParticipants] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [visibleSection, setVisibleSection] = useState("overview");
  const [reviewContent, setReviewContent] = useState("");
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewSubmitting, setReviewSubmitting] = useState(false);

  const availableTimes = ["10:00 AM", "2:00 PM", "6:00 PM"];

  const workshopTimeZone =
    workshop ? getTimeZoneForLocation(workshop.location) || Intl.DateTimeFormat().resolvedOptions().timeZone : Intl.DateTimeFormat().resolvedOptions().timeZone;

  useEffect(() => {
    if (!id) return;
    axios
      .get(`${import.meta.env.VITE_API_BASE_URL}/api/public/workshops/${id}`)
      .then((r) => {
        setWorkshop(r.data);
        setLoading(false);
      })
      .catch(() => {
        setError(true);
        setLoading(false);
      });
  }, [id]);

  useEffect(() => {
    if (!workshop) return;
    const observerOptions = {
      root: null,
      rootMargin: "0px",
      threshold: 0.1,
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("opacity-100", "translate-y-0");
          entry.target.classList.remove("opacity-0", "translate-y-10");
        }
      });
    }, observerOptions);

    const elements = document.querySelectorAll(".animate-on-scroll");
    elements.forEach((el) => observer.observe(el));

    return () => elements.forEach((el) => observer.unobserve(el));
  }, [workshop]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <p>Loading...</p>
        </main>
        <Footer />
      </div>
    );
  }

  if (error || !workshop) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <p className="text-red-500">Workshop not found</p>
        </main>
        <Footer />
      </div>
    );
  }

  // seasonalIngredients and learningOutcomes are now provided by the backend

  const priceDisplay =
    workshop.price !== null && workshop.price !== undefined
      ? workshop.price === 0
        ? "Free"
        : `$${workshop.price}`
      : "Free";
  const priceNumber = workshop.price ?? 0;
  const totalPrice = priceNumber * participants;

  const handleAddToCart = () => {
    if (!selectedDate) {
      toast.error("Please select a date for your workshop");
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);

      addToCart({
        id: workshop.id,
        name: `${workshop.title} - ${selectedDate.toDateString()} at ${selectedTime}`,
        price: Number(workshop.price ?? 0),
        category: "Workshop",
        image: workshop.image || "",
        type: "workshop",
        scheduled_at: selectedDate.toISOString(),
      });

      toast.success(
        `Added ${workshop.title} to cart for ${participants} ${participants > 1 ? "people" : "person"}`
      );
    }, 1500);
  };
  const reviews = [
    {
      id: 1,
      name: "Sarah Johnson",
      date: "March 15, 2025",
      rating: 5,
      content:
        "This workshop exceeded my expectations! Chef Isabella is not only knowledgeable but also a wonderful teacher.",
      avatar:
        "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
    },
  ];

  const handleReviewSubmit = () => {
    if (reviewContent.length < 10) {
      toast.error("Please write a more detailed review");
      return;
    }

    setReviewSubmitting(true);

    setTimeout(() => {
      setReviewSubmitting(false);
      toast.success("Thank you for your review!");
      setReviewContent("");
    }, 1000);
  };

  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, index) => (
        <Star
          key={index}
          className={`h-4 w-4 ${index < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
        />
      ));
  };

  const renderRatingInput = () => {
    return (
      <div className="flex space-x-1">
        {Array(5)
          .fill(0)
          .map((_, index) => (
            <button
              key={index}
              type="button"
              className="focus:outline-none"
              onClick={() => setReviewRating(index + 1)}
            >
              <Star
                className={`h-6 w-6 ${index < reviewRating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
              />
            </button>
          ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow">
        <div
          className="relative bg-cover bg-center py-20"
          style={{
            backgroundImage: `linear-gradient(to bottom, rgba(0,0,0,0.3), rgba(0,0,0,0.6)), url(${
              workshop.image
            })`,
          }}
        >
          <div className="container mx-auto px-4 relative z-10 text-white">
            <Badge variant="terracotta" className="mb-4 opacity-0 translate-y-10 animate-on-scroll transition-all duration-700 delay-100">
              Workshop
            </Badge>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 opacity-0 translate-y-10 animate-on-scroll transition-all duration-700 delay-200">
              {workshop.title}
            </h1>

            <div className="flex flex-wrap items-center gap-4 mb-6 opacity-0 translate-y-10 animate-on-scroll transition-all duration-700 delay-300">
              <div className="flex items-center">
                <ChefHat className="h-5 w-5 mr-2" />
                <span>{workshop.instructor}</span>
              </div>
              <div className="flex items-center">
                <Tag className="h-5 w-5 mr-2" />
                <span>{workshop.cuisine || "Cooking"}</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                <span>
                  {formatUserDate(workshop.date, { dateStyle: 'medium', timeStyle: 'short' }, workshopTimeZone)} ({workshopTimeZone})
                </span>
              </div>
              <div className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                <span>
                  {workshop.spots !== null && workshop.spots !== undefined
                    ? `${workshop.spots} spots available`
                    : "Spots TBD"}
                </span>
              </div>
            </div>

            <p className="text-lg max-w-2xl opacity-0 translate-y-10 animate-on-scroll transition-all duration-700 delay-400">
              {workshop.location}
            </p>
          </div>
        </div>

        <div className="py-12 bg-culinary-cream">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
              <div className="lg:col-span-2">
                <div className="flex border-b border-gray-200 mb-8 gap-1">
                  <button
                    onClick={() => setVisibleSection("overview")}
                    className={`px-4 py-2 font-medium rounded-t-md transition-colors ${
                      visibleSection === "overview"
                        ? "bg-culinary-terracotta text-white"
                        : "text-gray-600 hover:text-culinary-terracotta"
                    }`}
                  >
                    Overview
                  </button>
                  <button
                    onClick={() => setVisibleSection("ingredients")}
                    className={`px-4 py-2 font-medium rounded-t-md transition-colors ${
                      visibleSection === "ingredients"
                        ? "bg-culinary-terracotta text-white"
                        : "text-gray-600 hover:text-culinary-terracotta"
                    }`}
                  >
                    Seasonal Ingredients
                  </button>
                  <button
                    onClick={() => setVisibleSection("learning")}
                    className={`px-4 py-2 font-medium rounded-t-md transition-colors ${
                      visibleSection === "learning"
                        ? "bg-culinary-terracotta text-white"
                        : "text-gray-600 hover:text-culinary-terracotta"
                    }`}
                  >
                    What You'll Learn
                  </button>
                  <button
                    onClick={() => setVisibleSection("reviews")}
                    className={`px-4 py-2 font-medium rounded-t-md transition-colors flex items-center gap-1 ${
                      visibleSection === "reviews"
                        ? "bg-culinary-terracotta text-white"
                        : "text-gray-600 hover:text-culinary-terracotta"
                    }`}
                  >
                    <MessageSquare className="h-4 w-4" />
                    Reviews
                  </button>
                </div>

                <div className="p-2">
                  <div className={`${visibleSection === "overview" ? "block animate-fade-in" : "hidden"}`}>
                    <div className="prose max-w-none text-gray-700">
                      <h2 className="text-2xl font-semibold text-culinary-navy mb-4">Workshop Overview</h2>
                      <p className="mb-4">
                        {workshop.full_description || workshop.description ||
                          "Join us for this exciting workshop. Further details will be provided soon."}
                      </p>
                    </div>
                  </div>

                  <div className={`${visibleSection === "ingredients" ? "block animate-fade-in" : "hidden"}`}>
                    <h2 className="text-2xl font-semibold text-culinary-navy mb-6">Seasonal Ingredients</h2>
                    {workshop.seasonal_ingredients && workshop.seasonal_ingredients.length > 0 ? (
                      <>
                        <p className="text-gray-700 mb-6">
                          Our workshop features the freshest ingredients of the season.
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                          {workshop.seasonal_ingredients.map((ingredient) => (
                            <div
                              key={ingredient}
                              className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 flex items-center hover:-translate-y-1 transition-transform duration-300"
                            >
                              <div className="w-8 h-8 rounded-full bg-culinary-sage/20 flex items-center justify-center mr-3">
                                <Leaf className="h-4 w-4 text-culinary-sage" />
                              </div>
                              <span className="text-gray-700">{ingredient}</span>
                            </div>
                          ))}
                        </div>
                      </>
                    ) : (
                      <p className="text-gray-700 mb-6">Seasonal ingredients to be announced.</p>
                    )}
                  </div>

                  <div className={`${visibleSection === "learning" ? "block animate-fade-in" : "hidden"}`}>
                    <h2 className="text-2xl font-semibold text-culinary-navy mb-6">What You'll Learn</h2>
                    {workshop.learning_outcomes && workshop.learning_outcomes.length > 0 ? (
                      <div className="space-y-4 mb-8">
                        {workshop.learning_outcomes.map((outcome, index) => (
                          <div
                            key={index}
                            className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 flex items-start"
                          >
                            <div className="w-8 h-8 rounded-full bg-culinary-terracotta/20 flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
                              <span className="text-culinary-terracotta font-medium">{index + 1}</span>
                            </div>
                            <span className="text-gray-700">{outcome}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-700 mb-6">Learning outcomes to be announced.</p>
                    )}
                  </div>

                  <div className={`${visibleSection === "reviews" ? "block animate-fade-in" : "hidden"}`}>
                    <h2 className="text-2xl font-semibold text-culinary-navy mb-6 flex items-center gap-2">
                      Workshop Reviews
                      <div className="flex items-center ml-2">
                        {renderStars(5)}
                        <span className="ml-2 text-base font-medium text-gray-700">5/5</span>
                      </div>
                    </h2>

                    <div className="space-y-6 mb-10">
                      {reviews.map((review) => (
                        <Card key={review.id} className="border border-gray-200 hover:shadow-md transition-shadow duration-300">
                          <CardContent className="p-6">
                            <div className="flex items-start">
                              <img src={review.avatar} alt={review.name} className="h-10 w-10 rounded-full mr-4" />
                              <div className="flex-1">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2">
                                  <h3 className="font-medium text-culinary-navy">{review.name}</h3>
                                  <span className="text-sm text-gray-500">{review.date}</span>
                                </div>
                                <div className="flex mb-3">{renderStars(review.rating)}</div>
                                <p className="text-gray-700">{review.content}</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 animate-on-scroll opacity-0 translate-y-10 transition-all duration-700">
                      <h3 className="text-xl font-semibold text-culinary-navy mb-4">Write a Review</h3>
                      <div className="mb-4">
                        <label className="block text-gray-700 mb-2">Your Rating</label>
                        {renderRatingInput()}
                      </div>
                      <div className="mb-4">
                        <label htmlFor="review" className="block text-gray-700 mb-2">
                          Your Review
                        </label>
                        <Textarea
                          id="review"
                          placeholder="Share your experience with this workshop..."
                          value={reviewContent}
                          onChange={(e) => setReviewContent(e.target.value)}
                          className="w-full min-h-[120px]"
                        />
                      </div>
                      <Button
                        className="bg-culinary-terracotta hover:bg-culinary-terracotta/90"
                        onClick={handleReviewSubmit}
                        disabled={reviewSubmitting}
                      >
                        {reviewSubmitting ? (
                          <div className="flex items-center gap-2">
                            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                            Submitting...
                          </div>
                        ) : (
                          "Submit Review"
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-1">
                <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 sticky top-8">
                  <h2 className="text-2xl font-semibold text-culinary-navy mb-6">Book This Workshop</h2>

                  <div className="mb-6">
                    <h3 className="text-lg font-medium text-culinary-navy mb-3">Select Date</h3>
                    <div className="border rounded-md p-2 compact-calendar">
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={setSelectedDate}
                        disabled={(date) => date < new Date()}
                        className="w-full"
                      />
                    </div>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-lg font-medium text-culinary-navy mb-3">Select Time</h3>
                    <Select value={selectedTime} onValueChange={setSelectedTime}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select a time" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableTimes.map((time) => (
                          <SelectItem key={time} value={time}>
                            {time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-lg font-medium text-culinary-navy mb-3">Participants</h3>
                    <div className="flex items-center">
                      <button
                        className="w-10 h-10 rounded-md bg-culinary-cream flex items-center justify-center hover:bg-culinary-cream/80 transition-colors"
                        onClick={() => setParticipants((prev) => Math.max(1, prev - 1))}
                      >
                        -
                      </button>
                      <span className="mx-4 text-lg font-medium text-culinary-navy">{participants}</span>
                      <button
                        className="w-10 h-10 rounded-md bg-culinary-cream flex items-center justify-center hover:bg-culinary-cream/80 transition-colors"
                        onClick={() => setParticipants((prev) => prev + 1)}
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="mb-6 pt-4 border-t border-gray-200">
                  <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-600">Price per person:</span>
                      <span className="font-medium text-culinary-navy">${priceNumber.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center text-lg font-bold mt-4">
                      <span className="text-culinary-navy">Total:</span>
                      <span className="text-culinary-terracotta">${totalPrice.toFixed(2)}</span>
                  </div>
                </div>

                  <Button
                    className="w-full bg-culinary-terracotta hover:bg-culinary-terracotta/90 h-12 text-lg flex items-center justify-center gap-2"
                    onClick={handleAddToCart}
                    disabled={isLoading || !selectedDate}
                  >
                    {isLoading ? (
                      <div className="flex items-center">
                        <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                        Adding...
                      </div>
                    ) : (
                      <>
                        <ShoppingCart className="h-5 w-5" />
                        Add to Cart
                      </>
                    )}
                  </Button>

                  <p className="mt-4 text-sm text-gray-500 text-center">
                    {selectedDate ? (
                      <>
                        You're booking for <span className="font-medium">{formatUserDate(selectedDate, { weekday: 'long', month: 'long', day: 'numeric' }, workshopTimeZone)}</span> at <span className="font-medium">{selectedTime} ({workshopTimeZone})</span>
                      </>
                    ) : (
                      "Please select a date to proceed with booking"
                    )}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-culinary-navy mb-8 text-center">You Might Also Like</h2>
            <p className="text-center text-gray-600">More workshops coming soon.</p>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default WorkshopDetail;
