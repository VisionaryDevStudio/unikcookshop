import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Check, X, Clock, User } from "lucide-react";
import { formatUserDate } from "@/utils/timezone";
import { useReviews } from "@/context/ReviewContext";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { Navigate } from "react-router-dom";

const AdminReviews = () => {
  const { getPendingReviews, approveReview, declineReview, reviews } = useReviews();
  const { isAdmin, isAuthenticated } = useAuth();
  
  if (!isAuthenticated || !isAdmin) {
    return <Navigate to="/" replace />;
  }

  const pendingReviews = getPendingReviews();
  const approvedReviews = reviews.filter(r => r.status === 'approved');
  const declinedReviews = reviews.filter(r => r.status === 'declined');

  const handleApprove = (reviewId: number) => {
    approveReview(reviewId);
    toast.success("Review approved successfully!");
  };

  const handleDecline = (reviewId: number) => {
    declineReview(reviewId);
    toast.success("Review declined");
  };

  const ReviewCard = ({ review, showActions = false }: { review: any, showActions?: boolean }) => (
    <Card className="mb-4">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            <div>
              <h4 className="font-semibold text-culinary-navy">{review.item_title}</h4>
              <div className="flex items-center gap-2 mt-1">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i}
                      className={`h-4 w-4 ${i < Math.floor(review.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-500">{formatUserDate(review.date)}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge
              variant={review.status === 'approved' ? 'default' : review.status === 'pending' ? 'secondary' : 'destructive'}
            >
              {review.status}
            </Badge>
            {review.verified ? (
              <Badge variant="outline" className="flex items-center gap-1">
                <Check className="h-3 w-3" />
                Verified
              </Badge>
            ) : (
              <span className="text-xs text-gray-500">Unverified</span>
            )}
            {review.verified_purchase && (
              <Badge variant="outline" className="flex items-center gap-1">
                <Check className="h-3 w-3" />
                Verified Purchase
              </Badge>
            )}
          </div>
        </div>

        <p className="text-gray-700 mb-4 leading-relaxed">{review.review}</p>
        
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-500">
            {review.item_type} • Helpful: {review.helpful}
          </div>
          
          {showActions && review.status === 'pending' && (
            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={() => handleApprove(review.id)}
                className="bg-green-600 hover:bg-green-700"
              >
                <Check className="h-4 w-4 mr-1" />
                Approve
              </Button>
              <Button
                size="sm"
                variant="destructive"
                onClick={() => handleDecline(review.id)}
              >
                <X className="h-4 w-4 mr-1" />
                Decline
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-8">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-culinary-navy mb-2">Review Management</h1>
            <p className="text-gray-600">Manage customer reviews and feedback</p>
          </div>

          {/* Statistics */}
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6 text-center">
                <Clock className="h-8 w-8 text-orange-500 mx-auto mb-2" />
                <div className="text-2xl font-bold text-culinary-navy">{pendingReviews.length}</div>
                <div className="text-sm text-gray-600">Pending Reviews</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <Check className="h-8 w-8 text-green-500 mx-auto mb-2" />
                <div className="text-2xl font-bold text-culinary-navy">{approvedReviews.length}</div>
                <div className="text-sm text-gray-600">Approved Reviews</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <X className="h-8 w-8 text-red-500 mx-auto mb-2" />
                <div className="text-2xl font-bold text-culinary-navy">{declinedReviews.length}</div>
                <div className="text-sm text-gray-600">Declined Reviews</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <User className="h-8 w-8 text-culinary-terracotta mx-auto mb-2" />
                <div className="text-2xl font-bold text-culinary-navy">{reviews.length}</div>
                <div className="text-sm text-gray-600">Total Reviews</div>
              </CardContent>
            </Card>
          </div>

          {/* Pending Reviews */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-culinary-navy">
                <Clock className="h-5 w-5" />
                Pending Reviews ({pendingReviews.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {pendingReviews.length > 0 ? (
                pendingReviews.map((review) => (
                  <ReviewCard key={review.id} review={review} showActions={true} />
                ))
              ) : (
                <p className="text-gray-500 text-center py-8">No pending reviews</p>
              )}
            </CardContent>
          </Card>

          {/* Recent Approved Reviews */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-culinary-navy">
                <Check className="h-5 w-5" />
                Recent Approved Reviews
              </CardTitle>
            </CardHeader>
            <CardContent>
              {approvedReviews.slice(0, 5).map((review) => (
                <ReviewCard key={review.id} review={review} />
              ))}
            </CardContent>
          </Card>

          {/* Declined Reviews */}
          {declinedReviews.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-culinary-navy">
                  <X className="h-5 w-5" />
                  Declined Reviews ({declinedReviews.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {declinedReviews.map((review) => (
                  <ReviewCard key={review.id} review={review} />
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default AdminReviews;