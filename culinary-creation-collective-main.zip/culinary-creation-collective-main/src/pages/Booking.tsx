
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BookingCalendar from "@/components/BookingCalendar";
import InquiryForm from "@/components/InquiryForm";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, MessageSquare } from "lucide-react";
import { useState } from "react";

const Booking = () => {
  const [tab, setTab] = useState("calendar");
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero */}
        <div className="bg-culinary-navy text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">Book Your Experience</h1>
            <p className="text-lg max-w-2xl mx-auto">
              Reserve your spot in our upcoming workshops or request a custom culinary experience
            </p>
          </div>
        </div>
        
        {/* Booking Section */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <Tabs value={tab} onValueChange={setTab}>
              <div className="flex justify-center mb-8">
                <TabsList>
                  <TabsTrigger value="calendar" className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    Book by Calendar
                  </TabsTrigger>
                  <TabsTrigger value="inquiry" className="flex items-center">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Custom Inquiry
                  </TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="calendar">
                <div className="max-w-5xl mx-auto">
                  <div className="text-center mb-8">
                    <h2 className="text-2xl font-semibold mb-2 text-culinary-navy">Browse Available Workshops</h2>
                    <p className="text-gray-600">
                      Select a date to see scheduled workshops and reserve your spot
                    </p>
                  </div>
                  
                  <BookingCalendar onRequestCustom={() => setTab("inquiry")} />
                </div>
              </TabsContent>
              
              <TabsContent value="inquiry">
                <div className="max-w-3xl mx-auto">
                  <div className="text-center mb-8">
                    <h2 className="text-2xl font-semibold mb-2 text-culinary-navy">Custom Booking Request</h2>
                    <p className="text-gray-600">
                      Planning a special event or looking for a customized workshop? Let us know your requirements.
                    </p>
                  </div>
                  
                  <div className="bg-white rounded-lg shadow-sm border p-8">
                    <InquiryForm />
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>
        
        {/* Information Section */}
        <section className="py-12 bg-culinary-cream">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-2xl font-semibold mb-6 text-center text-culinary-navy">Booking Information</h2>
              
              <div className="grid gap-6 md:grid-cols-2">
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-lg font-semibold mb-3 text-culinary-navy">Payment Options</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Full payment required at time of booking</li>
                    <li>• We accept all major credit cards</li>
                    <li>• Gift certificates available for purchase</li>
                    <li>• Group discounts available for 5+ participants</li>
                  </ul>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-lg font-semibold mb-3 text-culinary-navy">Cancellation Policy</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Full refund if cancelled 7+ days before</li>
                    <li>• 50% refund if cancelled 3-6 days before</li>
                    <li>• No refund if cancelled within 48 hours</li>
                    <li>• Workshops can be rescheduled once with 3+ days notice</li>
                  </ul>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-lg font-semibold mb-3 text-culinary-navy">What to Bring</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Just yourself! All equipment and ingredients provided</li>
                    <li>• Optional: Favorite apron</li>
                    <li>• Container for leftovers recommended</li>
                    <li>• Please inform us of any allergies/dietary restrictions</li>
                  </ul>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-lg font-semibold mb-3 text-culinary-navy">Workshop Location</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Culinary Creations Studio</li>
                    <li>• 123 Culinary Street, Foodville, FC 12345</li>
                    <li>• Free parking available</li>
                    <li>• Accessible entrance and facilities</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Booking;
