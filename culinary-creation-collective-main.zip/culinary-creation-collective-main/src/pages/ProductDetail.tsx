import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ShoppingBag, Star, ArrowLeft, Heart, Share2, Truck, Shield, RotateCcw, MessageSquare, ThumbsUp } from "lucide-react";
import { formatUserDate } from "@/utils/timezone";
import { toast } from "sonner";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { useReviews } from "@/context/ReviewContext";
import { LoginModal } from "@/components/LoginModal";
import axios from "axios";

const ProductDetail = () => {
  const { id } = useParams();
  const { addToCart } = useCart();
  const { user, isAuthenticated } = useAuth();
  const { getReviewsForProduct, addReview, markHelpful } = useReviews();
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [newReview, setNewReview] = useState({
    rating: 5,
    comment: ""
  });

  const [product, setProduct] = useState<{
    id: number;
    name: string;
    images: string[];
    price: number;
    category: string;
    rating: number | null;
    reviewCount: number;
    description: string;
    features: string[];
    specifications: Record<string, string>;
    stockCount: number;
    inStock: boolean;
  } | null>(null);

  // Reset selected image when navigating to a different product
  useEffect(() => {
    setSelectedImageIndex(0);
  }, [id]);

  useEffect(() => {
    axios
      .get(`${import.meta.env.VITE_API_BASE_URL}/api/public/products/${id}`)
      .then((r) => {
        const d = r.data;
        const images = Array.from(
          new Set([d.image, ...(d.images ?? [])].filter(Boolean))
        );
        setProduct({
          id: d.id,
          name: d.name,
          images,
          price: d.price,
          category: d.category ?? "Product",
          rating: d.rating ?? null,
          reviewCount: d.review_count ?? 0,
          description: d.description ?? "",
          features: d.features ?? [],
          specifications: d.specifications ?? {},
          stockCount: d.stock_count ?? 0,
          inStock: (d.stock_count ?? 0) > 0,
        });
      })
      .catch(() => setProduct(null));
  }, [id]);

  const productReviews = product ? getReviewsForProduct(product.name) : [];
  
  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4 text-culinary-navy">Product Not Found</h1>
            <Link to="/shop">
              <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90">
                Back to Shop
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart({
        id: product.id,
        name: product.name,
        price: product.price,
        category: product.category,
        image: product.images[0],
        type: 'product'
      });
    }
    toast.success(`${quantity} x ${product.name} added to cart`);
  };

  const handleSubmitReview = () => {
    if (!newReview.comment.trim()) {
      toast.error("Please write a review comment");
      return;
    }
    
    if (!user) {
      toast.error("Please log in to submit a review");
      return;
    }

    addReview({
      item_type: 'Product',
      item_title: product!.name,
      rating: newReview.rating,
      review: newReview.comment
    });
    
    toast.success("Review submitted and is pending approval!");
    setShowReviewForm(false);
    setNewReview({ rating: 5, comment: "" });
  };

  const handleWriteReview = () => {
    if (!isAuthenticated) {
      setShowLoginModal(true);
      return;
    }
    setShowReviewForm(true);
  };

  const handleLoginSuccess = () => {
    setShowReviewForm(true);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-8">
        <div className="container mx-auto px-4">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 mb-6 text-sm">
            <Link to="/shop" className="text-culinary-terracotta hover:underline">Shop</Link>
            <span className="text-gray-400">/</span>
            <Link to={`/shop?category=${product.category}`} className="text-culinary-terracotta hover:underline">{product.category}</Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-600">{product.name}</span>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Product Images */}
            <div className="space-y-4">
              <div className="aspect-square overflow-hidden rounded-lg bg-gray-100">
                <img
                  src={product.images[selectedImageIndex]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex gap-2 overflow-x-auto">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImageIndex(index)}
                    className={`flex-shrink-0 w-20 h-20 rounded-md overflow-hidden border-2 ${
                      selectedImageIndex === index ? 'border-culinary-terracotta' : 'border-gray-200'
                    }`}
                  >
                    <img src={image} alt={`${product.name} ${index + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-6">
              <div>
                <Badge variant="secondary" className="mb-2">{product.category}</Badge>
                <h1 className="text-3xl font-bold text-culinary-navy mb-2">{product.name}</h1>
                
                {product.rating !== null && (
                  <div className="flex items-center gap-4 mb-4">
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                        />
                      ))}
                      <span className="text-sm text-gray-600 ml-1">({product.reviewCount} reviews)</span>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-3 mb-4">
                  <span className="text-3xl font-bold text-culinary-navy">${product.price.toFixed(2)}</span>
                  {product.originalPrice && (
                    <span className="text-lg text-gray-500 line-through">{product.originalPrice}</span>
                  )}
                </div>

                <p className="text-gray-600 leading-relaxed">{product.description}</p>
              </div>

              {/* Stock Status */}
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${product.inStock ? 'bg-green-500' : 'bg-red-500'}`}></div>
                <span className={`text-sm font-medium ${product.inStock ? 'text-green-600' : 'text-red-600'}`}>
                  {product.inStock ? `In Stock (${product.stockCount} available)` : 'Out of Stock'}
                </span>
              </div>

              {/* Quantity and Add to Cart */}
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium">Quantity:</label>
                  <div className="flex items-center border rounded-md">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-1 hover:bg-gray-100"
                      disabled={quantity <= 1}
                    >
                      -
                    </button>
                    <span className="px-4 py-1 border-x">{quantity}</span>
                    <button
                      onClick={() => setQuantity(Math.min(product.stockCount, quantity + 1))}
                      className="px-3 py-1 hover:bg-gray-100"
                      disabled={quantity >= product.stockCount}
                    >
                      +
                    </button>
                  </div>
                </div>

                <Button
                  onClick={handleAddToCart}
                  disabled={!product.inStock}
                  className="bg-culinary-terracotta hover:bg-culinary-terracotta/90 flex-1"
                  size="lg"
                >
                  <ShoppingBag className="h-4 w-4 mr-2" />
                  Add to Cart
                </Button>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button variant="outline" size="sm" className="flex-1">
                  <Heart className="h-4 w-4 mr-2" />
                  Add to Wishlist
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  <Share2 className="h-4 w-4 mr-2" />
                  Share
                </Button>
              </div>

              {/* Features */}
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3 text-culinary-navy">Key Features</h3>
                  <ul className="space-y-2">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 rounded-full bg-culinary-terracotta"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Shipping Info */}
              <div className="grid grid-cols-3 gap-4 text-center text-sm">
                <div className="flex flex-col items-center gap-2">
                  <Truck className="h-8 w-8 text-culinary-terracotta" />
                  <span className="font-medium">Free Shipping</span>
                  <span className="text-gray-500">On orders $50+</span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <Shield className="h-8 w-8 text-culinary-terracotta" />
                  <span className="font-medium">2 Year Warranty</span>
                  <span className="text-gray-500">Quality guaranteed</span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <RotateCcw className="h-8 w-8 text-culinary-terracotta" />
                  <span className="font-medium">30-Day Returns</span>
                  <span className="text-gray-500">Hassle-free returns</span>
                </div>
              </div>
            </div>
          </div>

          {/* Product Details Tabs */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-6 text-culinary-navy">Product Specifications</h2>
            <Card>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="font-semibold mb-4 text-culinary-navy">Specifications</h3>
                    <div className="space-y-3">
                      {Object.entries(product.specifications).map(([key, value]) => (
                        <div key={key} className="flex justify-between">
                          <span className="text-gray-600">{key}:</span>
                          <span className="font-medium">{value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-4 text-culinary-navy">Care Instructions</h3>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Hand wash with mild soap and warm water</li>
                      <li>• Dry immediately after washing</li>
                      <li>• Store in a dry, cool place</li>
                      <li>• Avoid dishwasher and harsh chemicals</li>
                      <li>• Regular maintenance recommended</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Reviews Section */}
          <div className="mt-16">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-culinary-navy">Customer Reviews</h2>
              <Button 
                onClick={handleWriteReview}
                className="bg-culinary-terracotta hover:bg-culinary-terracotta/90"
              >
                <MessageSquare className="h-4 w-4 mr-2" />
                {showReviewForm ? "Cancel" : "Write a Review"}
              </Button>
            </div>

            {/* Review Summary */}
            <Card className="mb-6">
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-culinary-navy mb-2">
                      {productReviews.length > 0 ? (productReviews.reduce((acc, r) => acc + r.rating, 0) / productReviews.length).toFixed(1) : 'N/A'}
                    </div>
                    <div className="flex justify-center mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i}
                          className={`h-5 w-5 ${productReviews.length > 0 && i < Math.floor(productReviews.reduce((acc, r) => acc + r.rating, 0) / productReviews.length) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                        />
                      ))}
                    </div>
                    <div className="text-gray-600">Based on {productReviews.length} reviews</div>
                  </div>
                  <div className="space-y-2">
                    {[5, 4, 3, 2, 1].map((rating) => {
                      const count = productReviews.filter(r => Math.floor(r.rating) === rating).length;
                      const percentage = productReviews.length ? (count / productReviews.length) * 100 : 0;
                      return (
                        <div key={rating} className="flex items-center gap-2">
                          <span className="text-sm w-8">{rating}★</span>
                          <div className="flex-1 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-yellow-400 h-2 rounded-full" 
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-600 w-8">{count}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Review Form */}
            {showReviewForm && isAuthenticated && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="text-culinary-navy">Write Your Review</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Rating</label>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((rating) => (
                        <button
                          key={rating}
                          onClick={() => setNewReview({ ...newReview, rating })}
                          className="p-1"
                        >
                          <Star 
                            className={`h-6 w-6 ${rating <= newReview.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-2">Your Review</label>
                    <Textarea
                      value={newReview.comment}
                      onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                      placeholder="Share your experience with this product..."
                      rows={4}
                    />
                  </div>
                  
                  <div className="flex gap-3">
                    <Button onClick={handleSubmitReview} className="bg-culinary-terracotta hover:bg-culinary-terracotta/90">
                      Submit Review
                    </Button>
                    <Button variant="outline" onClick={() => setShowReviewForm(false)}>
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Reviews List */}
            <div className="space-y-4">
              {productReviews.length > 0 ? (
                productReviews.map((review) => (
                  <Card key={review.id}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold text-culinary-navy">Anonymous</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star 
                                  key={i}
                                  className={`h-4 w-4 ${i < Math.floor(review.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                                />
                              ))}
                            </div>
                            <span className="text-sm text-gray-500">{formatUserDate(review.date)}</span>
                          </div>
                        </div>
                      </div>
                      
                      <p className="text-gray-700 mb-3 leading-relaxed">{review.review}</p>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <button 
                          className="flex items-center gap-1 hover:text-culinary-terracotta transition-colors"
                          onClick={() => markHelpful(review.id)}
                        >
                          <ThumbsUp className="h-4 w-4" />
                          Helpful ({review.helpful})
                        </button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card>
                  <CardContent className="p-6 text-center">
                    <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-600">No reviews yet. Be the first to review this product!</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* Login Modal */}
          <LoginModal 
            isOpen={showLoginModal} 
            onClose={() => setShowLoginModal(false)}
            onLoginSuccess={handleLoginSuccess}
          />

          {/* Back to Shop */}
          <div className="mt-12 text-center">
            <Link to="/shop">
              <Button variant="outline" size="lg">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Shop
              </Button>
            </Link>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ProductDetail;