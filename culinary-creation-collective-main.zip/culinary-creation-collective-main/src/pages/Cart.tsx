import { useEffect, useMemo, useState } from "react";
import api from "@/utils/api";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Minus, Plus, Trash2, CreditCard } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { Link, useNavigate } from "react-router-dom";
import { PaymentModal } from "@/components/PaymentModal";
import { formatUserDate, formatUserTime, userTimeZone } from "@/utils/timezone";

const Cart = () => {
  const { cartItems, removeFromCart, updateQuantity, clearCart, getCartTotal } = useCart();
  const { isAuthenticated } = useAuth();
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const navigate = useNavigate();
  const stripePublishableKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY;

  const apiInstance = useMemo(() => api, []);

  const [summary, setSummary] = useState<{ subtotal: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSummary = async () => {
      if (!isAuthenticated) {
        setSummary({ subtotal: getCartTotal() });
        setError(null);
        return;
      }

      try {
        const res = await apiInstance.get("/api/cart/summary");
        setSummary({ subtotal: res.data.subtotal });
        setError(null);
      } catch {
        setError("Unable to fetch cart summary. Showing local totals.");
        toast.error("Failed to fetch cart summary");
        setSummary({ subtotal: getCartTotal() });
      }
    };

    fetchSummary();
  }, [cartItems, apiInstance, getCartTotal, isAuthenticated]);

  const handleCheckout = async () => {
    if (!stripePublishableKey) {
      toast.error("Payment processing is currently unavailable");
      return;
    }
    if (!isAuthenticated) {
      toast.error("You must be logged in to proceed to checkout");
      navigate("/login", { state: { from: "/cart" } });
      return;
    }
    setShowPaymentModal(true);
  };

  const handlePaymentComplete = (transactions: any[]) => {
    clearCart();
    setShowPaymentModal(false);
    const paymentIntentId = transactions[0]?.payment_intent_id;
    navigate(
      paymentIntentId
        ? `/payment-success?payment_intent_id=${paymentIntentId}`
        : "/payment-success",
      { state: { transactions } }
    );
  };

  const handlePaymentFailure = async (paymentIntentId?: string) => {
    setShowPaymentModal(false);
    if (paymentIntentId) {
      try {
        await apiInstance.post("/api/cart/cancel-payment-intent", {
          payment_intent_id: paymentIntentId,
        });
        toast.success("Payment canceled");
      } catch {
        toast.error("Failed to cancel payment");
      }
    }
    navigate(
      paymentIntentId
        ? `/payment-cancelled?payment_intent_id=${paymentIntentId}`
        : "/payment-cancelled"
    );
  };

  const formatPrice = (price: number) => {
    return `$${price.toFixed(2)}`;
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-4 text-culinary-navy">Your Cart is Empty</h1>
            <p className="text-gray-600 mb-8">Add some delicious items to get started!</p>
            <Link to="/shop">
              <Button className="bg-culinary-terracotta hover:bg-culinary-terracotta/90">
                Continue Shopping
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-8 text-culinary-navy">Shopping Cart</h1>
          
          <div className="grid gap-8 lg:grid-cols-3">
            {/* Cart Items */}
            <div className="lg:col-span-2">
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <Card key={item.id} className="overflow-hidden">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-20 h-20 object-cover rounded-lg"
                        />
                        <div className="flex-grow">
                          <h3 className="font-semibold text-culinary-navy">{item.name}</h3>
                          <p className="text-sm text-culinary-terracotta">{item.category}</p>
                          {item.scheduled_at && (
                            <p className="text-xs text-gray-500">
                              Scheduled for {formatUserDate(item.scheduled_at)} at {formatUserTime(item.scheduled_at)} ({userTimeZone})
                            </p>
                          )}
                          <p className="font-bold text-culinary-navy">{formatPrice(item.price)}</p>
                        </div>
                        <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => updateQuantity(item.id, item.type, item.quantity - 1, item.scheduled_at)}
                          className="h-8 w-8"
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => updateQuantity(item.id, item.type, item.quantity + 1, item.scheduled_at)}
                          className="h-8 w-8"
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeFromCart(item.id, item.type, item.scheduled_at)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-4">
                <CardHeader>
                  <CardTitle className="text-culinary-navy">Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {summary ? (
                    <>
                      <div className="flex justify-between">
                        <span>Subtotal</span>
                        <span>{formatPrice(summary.subtotal)}</span>
                      </div>
                      <div className="border-t pt-4">
                        <div className="flex justify-between font-bold text-lg">
                          <span>Total</span>
                          <span className="text-culinary-navy">
                            {formatPrice(summary.subtotal)}
                          </span>
                        </div>
                      </div>
                    </>
                  ) : (
                    <p>Loading summary...</p>
                  )}
                  {error && <p className="text-sm text-red-500">{error}</p>}
                  <Button
                    className="w-full bg-culinary-terracotta hover:bg-culinary-terracotta/90"
                    size="lg"
                    onClick={handleCheckout}
                    disabled={!stripePublishableKey}
                  >
                    <CreditCard className="h-4 w-4 mr-2" />
                    Proceed to Payment
                  </Button>
                  {!stripePublishableKey && (
                    <p className="text-sm text-red-500 text-center mt-2">
                      Payment processing is currently unavailable.
                    </p>
                  )}
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={clearCart}
                  >
                    Clear Cart
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        onPaymentComplete={handlePaymentComplete}
        onPaymentFailure={handlePaymentFailure}
      />
      
      <Footer />
    </div>
  );
};

export default Cart;
