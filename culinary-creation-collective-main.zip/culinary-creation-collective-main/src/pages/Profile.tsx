
import { useState, useEffect } from "react";
import api from "@/utils/api";
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ChevronLeft, MapPin, Pencil, Save, UserRound, Utensils } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

const Profile = () => {
  const { user } = useAuth();
  interface Workshop {
    id: number;
    title: string;
    date: string;
    instructor: string;
    location: string;
  }
  const [isEditing, setIsEditing] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [profileData, setProfileData] = useState({
    name: "",
    email: "",
    phone: "",
    location: "",
    bio: "",
    dietary_restrictions: "",
    cooking_experience: "",
    favorite_cuisines: "",
    cooking_goals: "",
    equipment_available: "",
    image: ""
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProfileData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      setProfileData(prev => ({
        ...prev,
        image: URL.createObjectURL(file)
      }));
    }
  };

  const handleSaveProfile = () => {
    const formData = new FormData();
    Object.entries(profileData).forEach(([key, value]) => {
      formData.append(key, value as string);
    });
    if (selectedImage) {
      formData.set("image", selectedImage);
    }
    api
      .put(`/api/users/me`, formData, {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      })
      .then(() => {
        setIsEditing(false);
        setSelectedImage(null);
      })
      .catch(() => {});
  };

  const [workshopHistory, setWorkshopHistory] = useState<Workshop[]>([]);
  const [upcomingWorkshops, setUpcomingWorkshops] = useState<Workshop[]>([]);

  useEffect(() => {
    api
      .get(`/api/users/me`)
      .then(res => setProfileData(prev => ({ ...prev, ...res.data })))
      .catch(() => {});

    api
      .get(`/api/users/me/workshops/upcoming`)
      .then(res => setUpcomingWorkshops(res.data))
      .catch(() => {});

    api
      .get(`/api/users/me/workshops/history`)
      .then(res => setWorkshopHistory(res.data))
      .catch(() => {});
  }, []);


  return (
    <div className="container mx-auto py-6 max-w-5xl">
      <div className="mb-6">
        <Link to="/dashboard" className="flex items-center text-culinary-navy hover:text-culinary-terracotta transition-colors">
          <ChevronLeft className="h-4 w-4 mr-1" />
          <span>Back to Dashboard</span>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Summary */}
        <div className="md:col-span-1">
          <Card>
            <CardHeader className="flex flex-col items-center text-center">
              <Avatar className="h-24 w-24 border-2 border-culinary-terracotta mb-4">
                <AvatarImage src={profileData.image || user?.image} />
                <AvatarFallback>
                  {(profileData.name || user?.name || "")
                    .split(" ")
                    .map(n => n[0])
                    .join("")
                    .toUpperCase() || "U"}
                </AvatarFallback>
              </Avatar>
              {isEditing && (
                <Input
                  type="file"
                  accept="image/*"
                  className="mt-2"
                  onChange={handleImageChange}
                />
              )}
              <CardTitle>{profileData.name}</CardTitle>
              <div className="text-sm text-muted-foreground mt-1">Student</div>
              
              <div className="mt-4 flex items-center text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mr-1" />
                <span>{profileData.location}</span>
              </div>
            </CardHeader>
            <CardContent className="text-center">
              <div className="flex justify-center mt-4">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setIsEditing(!isEditing)}
                >
                  {isEditing ? (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Cancel
                    </>
                  ) : (
                    <>
                      <Pencil className="h-4 w-4 mr-2" />
                      Edit Profile
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-lg">Cooking Experience</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Experience Level</Label>
                  <div className="font-medium">{profileData.cooking_experience}</div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Dietary Restrictions</Label>
                  <div className="font-medium">{profileData.dietary_restrictions}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="md:col-span-2">
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="grid grid-cols-3 mb-6">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="workshops">My Workshops</TabsTrigger>
              <TabsTrigger value="preferences">Preferences</TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <UserRound className="h-5 w-5 mr-2" />
                    Personal Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {isEditing ? (
                      <div className="grid gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="name">Full Name</Label>
                          <Input 
                            id="name"
                            name="name"
                            value={profileData.name}
                            onChange={handleInputChange}
                          />
                        </div>
                        
                        <div className="grid gap-2">
                          <Label htmlFor="email">Email</Label>
                          <Input 
                            id="email"
                            name="email"
                            value={profileData.email}
                            onChange={handleInputChange}
                          />
                        </div>
                        
                        <div className="grid gap-2">
                          <Label htmlFor="phone">Phone Number</Label>
                          <Input 
                            id="phone"
                            name="phone"
                            value={profileData.phone}
                            onChange={handleInputChange}
                          />
                        </div>
                        
                        <div className="grid gap-2">
                          <Label htmlFor="location">Location</Label>
                          <Input 
                            id="location"
                            name="location"
                            value={profileData.location}
                            onChange={handleInputChange}
                          />
                        </div>
                        
                        <div className="grid gap-2">
                          <Label htmlFor="bio">About Me</Label>
                          <Input 
                            id="bio"
                            name="bio"
                            value={profileData.bio}
                            onChange={handleInputChange}
                            className="h-24"
                          />
                        </div>
                        
                        <div className="grid gap-2">
                          <Label htmlFor="dietary_restrictions">Dietary Restrictions</Label>
                          <Input
                            id="dietary_restrictions"
                            name="dietary_restrictions"
                            value={profileData.dietary_restrictions}
                            onChange={handleInputChange}
                          />
                        </div>

                        <div className="grid gap-2">
                          <Label htmlFor="cooking_experience">Cooking Experience</Label>
                          <Input
                            id="cooking_experience"
                            name="cooking_experience"
                            value={profileData.cooking_experience}
                            onChange={handleInputChange}
                          />
                        </div>
                        
                        <Button 
                          onClick={handleSaveProfile}
                          className="mt-4"
                        >
                          <Save className="h-4 w-4 mr-2" />
                          Save Changes
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Email</Label>
                          <div className="font-medium">{profileData.email}</div>
                        </div>
                        
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Phone</Label>
                          <div className="font-medium">{profileData.phone}</div>
                        </div>
                        
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">About Me</Label>
                          <div className="font-medium">{profileData.bio}</div>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Workshops Tab */}
            <TabsContent value="workshops">
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Utensils className="h-5 w-5 mr-2" />
                    Upcoming Workshops
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {upcomingWorkshops.length > 0 ? (
                    <div className="space-y-4">
                      {upcomingWorkshops.map((workshop) => (
                        <div key={workshop.id} className="border rounded-md p-4 hover:bg-muted transition-colors">
                          <h3 className="font-medium">{workshop.title}</h3>
                          <div className="text-sm text-muted-foreground mt-1">
                            <div>Date: {workshop.date}</div>
                            <div>Instructor: {workshop.instructor}</div>
                            <div>
                              Location: <a
                                href={`https://maps.google.com/?q=${workshop.location}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-culinary-terracotta hover:underline"
                              >
                                {workshop.location}
                              </a>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-muted-foreground">
                      No upcoming workshops.
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Utensils className="h-5 w-5 mr-2" />
                    Workshop History
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {workshopHistory.length > 0 ? (
                    <div className="space-y-4">
                      {workshopHistory.map((workshop) => (
                        <div key={workshop.id} className="border rounded-md p-4 hover:bg-muted transition-colors">
                          <h3 className="font-medium">{workshop.title}</h3>
                          <div className="text-sm text-muted-foreground mt-1">
                            <div>Date: {workshop.date}</div>
                            <div>Instructor: {workshop.instructor}</div>
                            <div>
                              Location: <a
                                href={`https://maps.google.com/?q=${workshop.location}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-culinary-terracotta hover:underline"
                              >
                                {workshop.location}
                              </a>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-muted-foreground">
                      No workshop history available.
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Preferences Tab */}
            <TabsContent value="preferences">
              <Card>
                <CardHeader>
                  <CardTitle>Cooking Preferences</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Favorite Cuisines</Label>
                      <div className="font-medium">{profileData.favorite_cuisines}</div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Cooking Goals</Label>
                      <div className="font-medium">{profileData.cooking_goals}</div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Equipment Available</Label>
                      <div className="font-medium">{profileData.equipment_available}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Profile;
