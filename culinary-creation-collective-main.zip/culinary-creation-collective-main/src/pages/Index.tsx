
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import WorkshopTypes from "@/components/WorkshopTypes";
import FeaturedWorkshops from "@/components/FeaturedWorkshops";
import BookingCalendar from "@/components/BookingCalendar";
import InquiryForm from "@/components/InquiryForm";
import ShopPreview from "@/components/ShopPreview";
import Footer from "@/components/Footer";
import { ChefHat, MessageSquare } from "lucide-react";
import { useEffect, useState } from "react";
import axios from "axios";

const Index = () => {
  const [settings, setSettings] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get(`${import.meta.env.VITE_API_BASE_URL}/api/public/site-settings`)
      .then((r) => {
        const hp = r.data["homepage"] ? JSON.parse(r.data["homepage"]) : {};
        setSettings(hp);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="py-20 text-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow">
        <Hero
          title={settings?.hero_title || "Welcome"}
          subtitle={settings?.hero_subtitle || ""}
          image={settings?.hero_image || ""}
        />

        <WorkshopTypes types={settings?.workshop_types || []} />
        
        <FeaturedWorkshops />
        
        {/* Booking Preview Section */}
        <section className="py-16 bg-culinary-cream">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-culinary-navy">Book Your Culinary Experience</h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Browse our upcoming workshops and secure your spot today
              </p>
            </div>
            
            <BookingCalendar />
          </div>
        </section>
        
        <ShopPreview />
        
        {/* Inquiry Form Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-block p-3 bg-culinary-cream rounded-full mb-4">
                  <MessageSquare className="h-6 w-6 text-culinary-terracotta" />
                </div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4 text-culinary-navy">
                  {settings?.inquiry_title || 'Custom Booking Request'}
                </h2>
                <p className="text-lg text-gray-600 mb-6">
                  {settings?.inquiry_description || ''}
                </p>

                <div className="bg-culinary-cream p-6 rounded-lg mb-6">
                  <div className="flex items-start">
                    <ChefHat className="h-6 w-6 text-culinary-terracotta mr-3 mt-1" />
                    <div>
                      <h3 className="font-semibold text-culinary-navy">
                        {settings?.expert_title || 'Expert Chefs at Your Service'}
                      </h3>
                      <p className="text-gray-600">
                        {settings?.expert_description || 'Our professional chefs bring years of culinary expertise to each lesson, ensuring a high-quality learning experience.'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm border p-6">
                <h3 className="text-xl font-semibold mb-6 text-culinary-navy">Submit Your Inquiry</h3>
                <InquiryForm />
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
