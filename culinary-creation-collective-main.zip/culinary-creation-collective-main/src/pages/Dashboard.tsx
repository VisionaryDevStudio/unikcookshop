import { useEffect, useState } from "react";
import api from "@/utils/api";
import { Link } from "react-router-dom";
import {
  Calendar,
  ChefHat,
  Clock,
  MapPin,
  Plus,
  Users,
  Package,
  Star,
  ThumbsUp,
  CreditCard,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatUserDate, formatUserTime } from "@/utils/timezone";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import DashboardSidebar from "@/components/DashboardSidebar";
import { useAuth } from "@/context/AuthContext";


// Define the allowed badge variant types for better type safety
type BadgeVariantType =
  | "default"
  | "secondary"
  | "destructive"
  | "outline"
  | "culinary"
  | "terracotta";

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const [upcoming, setUpcoming] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [billing, setBilling] = useState<any[]>([]);
  const [methods, setMethods] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [pendingReviews, setPendingReviews] = useState<any[]>([]);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [selectedReview, setSelectedReview] = useState<any | null>(null);
  const [newReview, setNewReview] = useState({ rating: 5, comment: "" });

  const handleWriteReview = (review: any) => {
    setSelectedReview(review);
    setShowReviewForm(true);
  };

  const handleCloseReviewForm = () => {
    setShowReviewForm(false);
    setSelectedReview(null);
    setNewReview({ rating: 5, comment: "" });
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReview) return;
    try {
      await api.post(
        `/api/users/reviews`,
        {
          item_type: selectedReview.item_type,
          item_title: selectedReview.item_title,
          rating: newReview.rating,
          review: newReview.comment,
        },
      );
      toast.success("Review submitted!");
      setPendingReviews((prev) =>
        prev.filter((r) => r.id !== selectedReview.id),
      );
      handleCloseReviewForm();
    } catch {
      toast.error("Failed to submit review");
    }
  };

  const { user, isAdmin } = useAuth();
  const role = isAdmin ? "Admin" : "Student";

  const handleDeleteMethod = async (id: number) => {
    try {
      await api.delete(
        `/api/users/me/payment-methods/${id}`,
      );
      setMethods((prev) => prev.filter((m) => m.id !== id));
      toast.success("Card removed");
    } catch {
      toast.error("Failed to remove card");
    }
  };

  const handleSetPrimary = async (id: number) => {
    try {
      await api.post(
        `/api/users/me/payment-methods/${id}/primary`,
        {},
      );
      setMethods((prev) =>
        prev.map((m) => ({ ...m, is_primary: m.id === id }))
      );
      toast.success("Primary card updated");
    } catch {
      toast.error("Failed to update primary card");
    }
  };

  useEffect(() => {
    api
      .get(`/api/users/me/workshops/upcoming`)
      .then((r) => setUpcoming(r.data))
      .catch(() => {});
    api
      .get(`/api/users/me/workshops/history`)
      .then((r) => setHistory(r.data))
      .catch(() => {});
    api
      .get(`/api/users/me/products`)
      .then((r) => setProducts(r.data))
      .catch(() => {});
    api
      .get(`/api/users/me/billing`)
      .then((r) => setBilling(r.data))
      .catch(() => {});
    api
      .get(`/api/users/me/payment-methods`)
      .then((r) => setMethods(r.data))
      .catch(() => {});
    api
      .get(`/api/users/me/reviews`)
      .then((r) => setReviews(r.data))
      .catch(() => {});
    api
      .get(`/api/users/me/reviews/pending`)
      .then((r) => setPendingReviews(r.data))
      .catch(() => {});
  }, []);

  const sortedUpcoming = [...upcoming].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
  );
  const nextWorkshop = sortedUpcoming[0];

  return (
    <div className="min-h-screen flex flex-col bg-culinary-cream/10">
      <Navbar />

      <div className="container mx-auto px-4 py-8 flex-grow flex flex-col md:flex-row gap-6">
        <DashboardSidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        <div className="flex-grow">
          <header className="mb-6">
            <h1 className="text-3xl font-bold text-culinary-navy">
              {role} Dashboard
            </h1>
            <p className="text-muted-foreground">
              {user
                ? `Welcome back, ${user.name}! You're logged in as ${role}.`
                : "Welcome back!"}
            </p>
          </header>

          <Tabs
            value={activeTab}
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList className="mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="workshops">My Workshops</TabsTrigger>
              <TabsTrigger value="calendar">Calendar</TabsTrigger>
              <TabsTrigger value="products">Products</TabsTrigger>
              <TabsTrigger value="billing">Billing</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6 animate-fade-in">
              {/* Welcome Card */}
              <Alert className="bg-culinary-terracotta/10 border-culinary-terracotta/20">
                <ChefHat className="h-5 w-5 text-culinary-terracotta" />
                <AlertTitle className="text-culinary-terracotta">
                  Ready for your next workshop!
                </AlertTitle>
                {nextWorkshop ? (
                  <AlertDescription>
                    Your next in-person class "{nextWorkshop.title}" is on{" "}
                    {formatUserDate(nextWorkshop.date)} at {nextWorkshop.location}.
                  </AlertDescription>
                ) : (
                  <AlertDescription>
                    No upcoming workshops scheduled.
                  </AlertDescription>
                )}
              </Alert>

              {/* Upcoming Classes */}
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Workshops</CardTitle>
                  <CardDescription>
                    Your scheduled in-person classes
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {upcoming.map((ws) => (
                      <UpcomingClass
                        key={ws.id}
                        title={ws.title}
                        date={formatUserDate(ws.date)}
                        time={formatUserTime(ws.date)}
                        instructor={ws.instructor}
                        location={ws.location}
                        locationCoords={ws.location_coords}
                        badgeText="Confirmed"
                      />
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setActiveTab("calendar")}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    View Full Schedule
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            {/* My Workshops Tab */}
            <TabsContent
              value="workshops"
              className="space-y-6 animate-fade-in"
            >
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-culinary-navy">
                  My In-Person Workshops
                </h2>
                <Link to="/booking">
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Book New Workshop
                  </Button>
                </Link>
              </div>

              <Card>
                <CardContent className="p-6">
                  <div className="space-y-6">
                    {history.map((ws) => {
                      const seats = ws.spots
                        ? `${ws.attendees_count}/${ws.spots}`
                        : `${ws.attendees_count || 0}`;
                      const progress = ws.spots
                        ? Math.round((ws.attendees_count / ws.spots) * 100)
                        : 100;
                      return (
                        <WorkshopItem
                          key={ws.id}
                          title={ws.title}
                          date={formatUserDate(ws.date)}
                          location={ws.location}
                          locationCoords={ws.location_coords}
                          progress={progress}
                          status="Completed"
                          seats={seats}
                        />
                      );
                    })}
                    {upcoming.map((ws) => {
                      const seats = ws.spots
                        ? `${ws.attendees_count}/${ws.spots}`
                        : `${ws.attendees_count || 0}`;
                      const progress = ws.spots
                        ? Math.round((ws.attendees_count / ws.spots) * 100)
                        : 0;
                      return (
                        <WorkshopItem
                          key={`u-${ws.id}`}
                          title={ws.title}
                          date={formatUserDate(ws.date)}
                          location={ws.location}
                          locationCoords={ws.location_coords}
                          progress={progress}
                          status="Upcoming"
                          seats={seats}
                        />
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Calendar Tab */}
            <TabsContent value="calendar" className="space-y-6 animate-fade-in">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-culinary-navy">
                  Workshop Calendar
                </h2>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Schedule</CardTitle>
                  <CardDescription>
                    Your upcoming in-person cooking workshops
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {upcoming.map((ws) => (
                      <div
                        key={ws.id}
                        className="flex items-center justify-between p-4 border rounded-lg"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="flex flex-col items-center justify-center w-12 h-12 bg-culinary-cream rounded-lg">
                            <span className="text-lg font-bold text-culinary-navy">
                              {formatUserDate(ws.date, { day: '2-digit' })}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {formatUserDate(ws.date, { month: 'short' })}
                            </span>
                          </div>
                          <div>
                            <h4 className="font-medium">{ws.title}</h4>
                            <div className="flex items-center text-sm text-muted-foreground space-x-2">
                              <Clock className="h-3 w-3" />
                              <span>{formatUserTime(ws.date)}</span>
                              <span>•</span>
                              {ws.location_coords ? (
                                <a
                                  href={`https://maps.google.com/?q=${ws.location_coords}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center text-culinary-terracotta hover:underline"
                                >
                                  <MapPin className="h-3 w-3 mr-1" />
                                  <span>{ws.location}</span>
                                </a>
                              ) : (
                                <span className="flex items-center text-muted-foreground">
                                  <MapPin className="h-3 w-3 mr-1" />
                                  <span>{ws.location}</span>
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <Badge variant="culinary">Confirmed</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Products Tab */}
            <TabsContent value="products" className="space-y-6 animate-fade-in">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-culinary-navy">
                  My Products
                </h2>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Purchased Products</CardTitle>
                  <CardDescription>
                    Products you've purchased from our shop
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {products.map((p) => (
                      <ProductItem
                        key={p.id}
                        name={p.name}
                        purchaseDate={formatUserDate(p.purchase_date)}
                        price={`$${p.price.toFixed(2)}`}
                        image={p.image}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Billing Tab */}
            <TabsContent value="billing" className="space-y-6 animate-fade-in">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-culinary-navy">
                  Billing History
                </h2>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Purchase History</CardTitle>
                  <CardDescription>
                    Your complete purchase and payment history
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {billing.map((b) => (
                      <BillingItem
                        key={b.id}
                        type={b.type}
                        description={b.description}
                        date={formatUserDate(b.date)}
                        amount={`$${b.amount.toFixed(2)}`}
                        status={b.status}
                        method={b.method}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Payment Methods</CardTitle>
                  <CardDescription>
                    Manage your saved payment methods
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-3">
                    {methods.map((m) => (
                      <div
                        key={m.id}
                        className="flex items-center justify-between p-4 border rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded bg-culinary-cream flex items-center justify-center">
                            <CreditCard className="h-4 w-4 text-culinary-terracotta" />
                          </div>
                          <div>
                            <p className="font-medium">
                              •••• •••• •••• {m.last4}
                            </p>
                            <p className="text-sm text-gray-500">
                              Expires {m.expiry}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {m.is_primary && <Badge variant="culinary">Primary</Badge>}
                          {!m.is_primary && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleSetPrimary(m.id)}
                            >
                              Set Primary
                            </Button>
                          )}
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteMethod(m.id)}
                          >
                            Delete
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Reviews Tab */}
            <TabsContent value="reviews" className="space-y-6 animate-fade-in">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-culinary-navy">
                  My Reviews
                </h2>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Reviews You've Written</CardTitle>
                  <CardDescription>
                    Your feedback on workshops and products
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-6">
                    {reviews.map((r) => (
                      <ReviewItem
                        key={r.id}
                        type={r.item_type}
                        title={r.item_title}
                        date={formatUserDate(r.date)}
                        rating={r.rating}
                        review={r.review}
                        helpful={r.helpful}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Pending Reviews</CardTitle>
                  <CardDescription>
                    Share your experience with recent purchases
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {pendingReviews.map((r) => (
                      <div
                        key={r.id}
                        className="flex items-center justify-between p-4 border rounded-lg"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 rounded bg-culinary-cream flex items-center justify-center">
                            <Package className="h-5 w-5 text-culinary-terracotta" />
                          </div>
                          <div>
                            <h4 className="font-medium">{r.item_title}</h4>
                            <p className="text-sm text-gray-500">
                              Purchased on{" "}
                              {formatUserDate(r.date)}
                            </p>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleWriteReview(r)}
                        >
                          Write Review
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Dialog
        open={showReviewForm}
        onOpenChange={(open) => {
          if (!open) handleCloseReviewForm();
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Write a Review</DialogTitle>
            <DialogDescription>
              Share your experience with {selectedReview?.item_title}
            </DialogDescription>
          </DialogHeader>
          <form className="space-y-4" onSubmit={handleSubmitReview}>
            <div>
              <label className="block text-sm font-medium mb-2">Rating</label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <button
                    type="button"
                    key={rating}
                    onClick={() =>
                      setNewReview({ ...newReview, rating })
                    }
                    className="p-1"
                  >
                    <Star
                      className={`h-6 w-6 ${
                        rating <= newReview.rating
                          ? "text-yellow-400 fill-yellow-400"
                          : "text-gray-300"
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">
                Your Review
              </label>
              <Textarea
                value={newReview.comment}
                onChange={(e) =>
                  setNewReview({ ...newReview, comment: e.target.value })
                }
                placeholder="Share your experience..."
                rows={4}
              />
            </div>
            <div className="flex gap-3">
              <Button
                type="submit"
                className="bg-culinary-terracotta hover:bg-culinary-terracotta/90"
              >
                Submit Review
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={handleCloseReviewForm}
              >
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

// Component for upcoming class
const UpcomingClass = ({
  title,
  date,
  time,
  instructor,
  location,
  locationCoords,
  badgeText,
  badgeVariant = "culinary",
}: {
  title: string;
  date: string;
  time: string;
  instructor: string;
  location: string;
  locationCoords: string;
  badgeText: string;
  badgeVariant?: BadgeVariantType;
}) => (
  <div className="flex items-center justify-between">
    <div className="flex items-center space-x-4">
      <div className="w-12 h-12 rounded-md bg-culinary-cream flex items-center justify-center">
        <ChefHat className="h-6 w-6 text-culinary-terracotta" />
      </div>
      <div>
        <h4 className="font-medium">{title}</h4>
        <div className="flex items-center text-sm text-muted-foreground space-x-2">
          <span>{date}</span>
          <span>•</span>
          <span>{time}</span>
        </div>
        <div className="flex items-center text-sm space-x-2 mt-1">
          <span className="text-culinary-navy">{instructor}</span>
          <span className="text-xs text-muted-foreground">•</span>
          {locationCoords ? (
            <a
              href={`https://maps.google.com/?q=${locationCoords}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs flex items-center text-culinary-terracotta hover:underline"
            >
              <MapPin className="h-3 w-3 mr-1" />
              {location}
            </a>
          ) : (
            <span className="text-xs flex items-center text-muted-foreground">
              <MapPin className="h-3 w-3 mr-1" />
              {location}
            </span>
          )}
        </div>
      </div>
    </div>
    <Badge variant={badgeVariant}>{badgeText}</Badge>
  </div>
);

// Component for workshop item
const WorkshopItem = ({
  title,
  date,
  location,
  locationCoords,
  progress,
  status,
  seats,
}: {
  title: string;
  date: string;
  location: string;
  locationCoords: string;
  progress: number;
  status: string;
  seats: string;
}) => {
  // Map the status string to one of the allowed variant types
  const getBadgeVariant = (status: string): BadgeVariantType => {
    if (status === "Completed") return "culinary";
    if (status === "Upcoming") return "terracotta";
    return "default";
  };

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <div className="w-12 h-12 rounded-md bg-culinary-cream flex items-center justify-center">
          <ChefHat className="h-6 w-6 text-culinary-terracotta" />
        </div>
        <div>
          <h4 className="font-medium">{title}</h4>
          <div className="flex items-center text-sm space-x-2">
            <span className="text-muted-foreground">{date}</span>
            <span className="text-xs text-muted-foreground">•</span>
            {locationCoords ? (
              <a
                href={`https://maps.google.com/?q=${locationCoords}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs flex items-center text-culinary-terracotta hover:underline"
              >
                <MapPin className="h-3 w-3 mr-1" />
                {location}
              </a>
            ) : (
              <span className="text-xs flex items-center text-muted-foreground">
                <MapPin className="h-3 w-3 mr-1" />
                {location}
              </span>
            )}
          </div>
          <div className="flex items-center text-xs space-x-2 mt-1">
            <span className="flex items-center text-muted-foreground">
              <Users className="h-3 w-3 mr-1" />
              {seats}
            </span>
          </div>
          {progress > 0 && progress < 100 && (
            <div className="w-32 h-1.5 bg-slate-200 rounded-full mt-2">
              <div
                className="bg-culinary-terracotta h-full rounded-full"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          )}
        </div>
      </div>
      <Badge variant={getBadgeVariant(status)}>{status}</Badge>
    </div>
  );
};

// Component for product item
const ProductItem = ({
  name,
  purchaseDate,
  price,
  image,
}: {
  name: string;
  purchaseDate: string;
  price: string;
  image: string;
}) => {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <img
          src={image}
          alt={name}
          className="w-16 h-16 rounded-lg object-cover"
        />
        <div>
          <h4 className="font-medium">{name}</h4>
          <div className="flex items-center text-sm space-x-2">
            <span className="text-muted-foreground">
              Purchased: {purchaseDate}
            </span>
            <span className="text-xs text-muted-foreground">•</span>
            <span className="font-medium text-culinary-navy">{price}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// Component for billing item
const BillingItem = ({
  type,
  description,
  date,
  amount,
  status,
  method,
}: {
  type: string;
  description: string;
  date: string;
  amount: string;
  status: string;
  method: string;
}) => {
  const getStatusVariant = (status: string): BadgeVariantType => {
    if (status === "Paid") return "culinary";
    if (status === "Pending") return "terracotta";
    return "default";
  };

  return (
    <div className="flex items-center justify-between p-4 border rounded-lg">
      <div className="flex items-center space-x-4">
        <div className="w-10 h-10 rounded-lg bg-culinary-cream flex items-center justify-center">
          {type === "Workshop" ? (
            <ChefHat className="h-5 w-5 text-culinary-terracotta" />
          ) : (
            <Package className="h-5 w-5 text-culinary-terracotta" />
          )}
        </div>
        <div>
          <div className="flex items-center space-x-2">
            <h4 className="font-medium">{description}</h4>
            <Badge variant="outline" className="text-xs">
              {type}
            </Badge>
          </div>
          <div className="flex items-center text-sm text-muted-foreground space-x-2">
            <span>{date}</span>
            <span>•</span>
            <span>{method}</span>
          </div>
        </div>
      </div>
      <div className="text-right">
        <p className="font-medium text-culinary-navy">{amount}</p>
        <Badge variant={getStatusVariant(status)} className="text-xs">
          {status}
        </Badge>
      </div>
    </div>
  );
};

// Component for review item
const ReviewItem = ({
  type,
  title,
  date,
  rating,
  review,
  helpful,
}: {
  type: string;
  title: string;
  date: string;
  rating: number;
  review: string;
  helpful: number;
}) => {
  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, index) => (
        <Star
          key={index}
          className={`h-4 w-4 ${
            index < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
          }`}
        />
      ));
  };

  return (
    <div className="p-4 border rounded-lg">
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="flex items-center space-x-2 mb-1">
            <h4 className="font-medium">{title}</h4>
            <Badge variant="outline" className="text-xs">
              {type}
            </Badge>
          </div>
          <div className="flex items-center space-x-2">
            <div className="flex">{renderStars(rating)}</div>
            <span className="text-sm text-muted-foreground">{date}</span>
          </div>
        </div>
      </div>
      <p className="text-gray-700 mb-3">{review}</p>
      <div className="flex items-center text-sm text-muted-foreground">
        <ThumbsUp className="h-4 w-4 mr-1" />
        <span>{helpful} people found this helpful</span>
      </div>
    </div>
  );
};

export default Dashboard;
