import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { 
  ChefHat, 
  Clock, 
  Users, 
  Tag, 
  Leaf, 
  DollarSign,
  Calendar as CalendarIcon,
  MapPin,
  Image as ImageIcon,
  Plus,
  Minus,
  ArrowLeft,
  Save,
  Star,
  Eye,
  ShoppingCart
} from "lucide-react";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Calendar } from "@/components/ui/calendar";
import api from "@/utils/api";

const workshopSchema = z.object({
  // Workshop Overview
  title: z.string().min(3, "Workshop title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  image: z.string().url("Please enter a valid image URL"),
  
  // Workshop Details
  type: z.string().min(1, "Workshop type is required"),
  cuisine: z.string().min(1, "Cuisine type is required"),
  chef: z.string().min(2, "Chef name is required"),
  level: z.string().min(1, "Skill level is required"),
  duration: z.string().min(1, "Duration is required"),
  location: z.string().min(1, "Location is required"),
  
  // Pricing
  price: z.string().refine((val) => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
    message: "Price must be a positive number",
  }),
  spots: z.string().refine((val) => !isNaN(parseInt(val)) && parseInt(val) > 0, {
    message: "Number of spots must be a positive number",
  }),
  
  // Workshop Overview Details
  fullDescription: z.string().min(50, "Full description must be at least 50 characters"),
  whatYoullMake: z.string().min(10, "Please describe what participants will make"),
});

// Preview Component that exactly matches the real WorkshopDetail page
const WorkshopPreview = ({ formData, seasonalIngredients, learningOutcomes, workshopDate, workshopTime, workshopDates }: any) => {
  const [visibleSection, setVisibleSection] = useState("overview");
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(
    workshopDate ? new Date(workshopDate) : undefined
  );
  const [selectedTime, setSelectedTime] = useState<string>("");

  const [participants, setParticipants] = useState(1);

  useEffect(() => {
    setSelectedDate(workshopDate ? new Date(workshopDate) : undefined);
    if (workshopDate && workshopTime) {
      const dateObj = new Date(`${workshopDate}T${workshopTime}`);
      setSelectedTime(dateObj.toISOString());
    } else {
      setSelectedTime("");
    }
  }, [workshopDate, workshopTime]);

  const getTypeLabel = (type: string) => {
    const typeLabels: { [key: string]: string } = {
      'group': 'Group Lesson',
      'kids': 'Kids Workshop',
      'date-night': 'Date Night',
      'private': 'Private Session',
      'team-building': 'Team Building',
      'crash-course': 'Crash Course',
      'seasonal': 'Seasonal Special'
    };
    return typeLabels[type] || type;
  };

  const validIngredients = seasonalIngredients.filter((ingredient: string) => ingredient.trim());
  const validOutcomes = learningOutcomes.filter((outcome: string) => outcome.trim());

  const validWorkshopSessions = workshopDates
    .filter((ws: any) => ws.date && ws.times.some((time: string) => time.trim()))
    .map((ws: any) => ({
      date: ws.date,
      times: ws.times.filter((time: string) => time.trim()),
    }));

  const calendarDates = validWorkshopSessions
    .map((ws: any) => new Date(ws.date))
    .filter((date: Date) => !isNaN(date.getTime()));

  const sessionForDate = selectedDate
    ? validWorkshopSessions.find(
        (ws: any) =>
          new Date(ws.date).toDateString() === selectedDate.toDateString()
      )
    : undefined;

  const availableTimes = sessionForDate
    ? sessionForDate.times.map((time: string) => {
        const dateObj = new Date(`${sessionForDate.date}T${time}`);
        return {
          iso: dateObj.toISOString(),
          label: dateObj.toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
          }),
        };
      })
    : [];

  useEffect(() => {
    if (availableTimes.length > 0) {
      const match = availableTimes.find((t) => t.iso === selectedTime);
      if (!match) {
        setSelectedTime(availableTimes[0].iso);
      }
    } else {
      setSelectedTime('');
    }
  }, [availableTimes, selectedTime]);

  const priceNumber = parseFloat(formData.price) || 0;
  const totalPrice = priceNumber * participants;
  const maxSpots = parseInt(formData.spots) || 12;

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="bg-culinary-terracotta text-white p-4">
        <div className="flex items-center gap-2">
          <Eye className="h-5 w-5" />
          <h3 className="font-semibold">Live Preview</h3>
        </div>
        <p className="text-sm opacity-90">See how your workshop will appear to customers</p>
      </div>
      
      <div>
        {/* Hero Section - Exactly matching WorkshopDetail */}
        <div 
          className="relative bg-cover bg-center py-20" 
          style={{ 
            backgroundImage: formData.image 
              ? `linear-gradient(to bottom, rgba(0,0,0,0.3), rgba(0,0,0,0.6)), url(${formData.image})` 
              : 'linear-gradient(to bottom, rgba(0,0,0,0.3), rgba(0,0,0,0.6)), url(https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3)'
          }}
        >
          <div className="container mx-auto px-4 relative z-10 text-white">
            {formData.type && (
              <Badge variant="terracotta" className="mb-4">
                {getTypeLabel(formData.type)}
              </Badge>
            )}
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
              {formData.title || "Workshop Title"}
            </h1>
            
            <div className="flex flex-wrap items-center gap-4 mb-6">
              {formData.chef && (
                <div className="flex items-center">
                  <ChefHat className="h-5 w-5 mr-2" />
                  <span>{formData.chef}</span>
                </div>
              )}
              {formData.cuisine && (
                <div className="flex items-center">
                  <Tag className="h-5 w-5 mr-2" />
                  <span>{formData.cuisine}</span>
                </div>
              )}
              {formData.duration && (
                <div className="flex items-center">
                  <Clock className="h-5 w-5 mr-2" />
                  <span>{formData.duration}</span>
                </div>
              )}
              {formData.spots && (
                <div className="flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  <span>{formData.spots} spots available</span>
                </div>
              )}
            </div>
            
            <p className="text-lg max-w-2xl">
              {formData.description || "Workshop description will appear here..."}
            </p>
          </div>
        </div>

        {/* Main Content Area - Exactly matching WorkshopDetail */}
        <div className="py-12 bg-culinary-cream">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
              {/* Left Content Area */}
              <div className="lg:col-span-2">
                <div className="flex border-b border-gray-200 mb-8 gap-1">
                  <button
                    onClick={() => setVisibleSection("overview")}
                    className={`px-4 py-2 font-medium rounded-t-md transition-colors ${
                      visibleSection === "overview" 
                        ? "bg-culinary-terracotta text-white" 
                        : "text-gray-600 hover:text-culinary-terracotta"
                    }`}
                  >
                    Overview
                  </button>
                  <button
                    onClick={() => setVisibleSection("ingredients")}
                    className={`px-4 py-2 font-medium rounded-t-md transition-colors ${
                      visibleSection === "ingredients" 
                        ? "bg-culinary-terracotta text-white" 
                        : "text-gray-600 hover:text-culinary-terracotta"
                    }`}
                  >
                    Seasonal Ingredients
                  </button>
                  <button
                    onClick={() => setVisibleSection("learning")}
                    className={`px-4 py-2 font-medium rounded-t-md transition-colors ${
                      visibleSection === "learning" 
                        ? "bg-culinary-terracotta text-white" 
                        : "text-gray-600 hover:text-culinary-terracotta"
                    }`}
                  >
                    What You'll Learn
                  </button>
                </div>
                
                <div className="p-2">
                  {/* Overview Section */}
                  <div className={`${visibleSection === "overview" ? "block animate-fade-in" : "hidden"}`}>
                    <div className="prose max-w-none text-gray-700">
                      <h2 className="text-2xl font-semibold text-culinary-navy mb-4">Workshop Overview</h2>
                      <p className="mb-4">
                        {formData.fullDescription || "Join our experienced chef for this hands-on cooking workshop that will teach you valuable culinary skills. You'll learn professional techniques while creating delicious dishes in a fun, supportive environment."}
                      </p>
                      
                      {formData.whatYoullMake && (
                        <div className="mb-4">
                          <p className="mb-4">By the end of the workshop, you'll have created:</p>
                          <p className="mb-4">{formData.whatYoullMake}</p>
                        </div>
                      )}
                      
                      <p>Then, the best part - we'll all sit down together to enjoy the fruits of our labor!</p>
                    </div>
                    
                    <div className="mt-8 p-6 bg-white rounded-lg shadow-sm border border-gray-100">
                      <h3 className="text-xl font-semibold text-culinary-navy mb-4">Workshop Details</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex items-start">
                          <Clock className="h-5 w-5 mr-3 text-culinary-terracotta mt-0.5" />
                          <div>
                            <h4 className="font-medium text-culinary-navy">Duration</h4>
                            <p className="text-gray-600">{formData.duration || "Duration TBD"} of hands-on cooking</p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <ChefHat className="h-5 w-5 mr-3 text-culinary-terracotta mt-0.5" />
                          <div>
                            <h4 className="font-medium text-culinary-navy">Instructor</h4>
                            <p className="text-gray-600">{formData.chef || "Chef TBD"}, Culinary Specialist</p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <Users className="h-5 w-5 mr-3 text-culinary-terracotta mt-0.5" />
                          <div>
                            <h4 className="font-medium text-culinary-navy">Group Size</h4>
                            <p className="text-gray-600">Small class of max {formData.spots || "TBD"} participants</p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <Leaf className="h-5 w-5 mr-3 text-culinary-terracotta mt-0.5" />
                          <div>
                            <h4 className="font-medium text-culinary-navy">Skill Level</h4>
                            <p className="text-gray-600">{formData.level || "All levels welcome"}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Ingredients Section */}
                  <div className={`${visibleSection === "ingredients" ? "block animate-fade-in" : "hidden"}`}>
                    <h2 className="text-2xl font-semibold text-culinary-navy mb-6">Seasonal Ingredients</h2>
                    <p className="text-gray-700 mb-6">
                      Our workshop features the freshest seasonal ingredients, sourced from local farms and producers. 
                      You'll learn how to select, prepare, and highlight these beautiful ingredients in your cooking.
                    </p>
                    
                    {validIngredients.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                        {validIngredients.map((ingredient: string, index: number) => (
                          <div 
                            key={index}
                            className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 flex items-center hover:-translate-y-1 transition-transform duration-300"
                          >
                            <div className="w-8 h-8 rounded-full bg-culinary-sage/20 flex items-center justify-center mr-3">
                              <Leaf className="h-4 w-4 text-culinary-sage" />
                            </div>
                            <span className="text-gray-700">{ingredient}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 italic mb-8">Add seasonal ingredients to see them displayed here...</p>
                    )}
                    
                    <div className="bg-culinary-sage/10 p-6 rounded-lg border border-culinary-sage/30">
                      <h3 className="text-lg font-semibold text-culinary-navy mb-3 flex items-center">
                        <Star className="h-5 w-5 mr-2 text-culinary-sage" />
                        Seasonal Spotlight
                      </h3>
                      <p className="text-gray-700">
                        We focus on seasonal ingredients to provide the best flavors while supporting sustainable food systems. 
                        Our chef will demonstrate proper preparation techniques and share creative ways to incorporate 
                        these ingredients into your home cooking.
                      </p>
                    </div>
                  </div>
                  
                  {/* Learning Section */}
                  <div className={`${visibleSection === "learning" ? "block animate-fade-in" : "hidden"}`}>
                    <h2 className="text-2xl font-semibold text-culinary-navy mb-6">What You'll Learn</h2>
                    <p className="text-gray-700 mb-6">
                      By the end of this workshop, you'll have gained valuable culinary skills and knowledge 
                      that you can apply to your own cooking at home. Here's what you can expect to learn:
                    </p>
                    
                    {validOutcomes.length > 0 ? (
                      <div className="space-y-4 mb-8">
                        {validOutcomes.map((outcome: string, index: number) => (
                          <div 
                            key={index}
                            className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 flex items-start"
                          >
                            <div className="w-8 h-8 rounded-full bg-culinary-terracotta/20 flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
                              <span className="text-culinary-terracotta font-medium">{index + 1}</span>
                            </div>
                            <span className="text-gray-700">{outcome}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 italic mb-8">Add learning outcomes to see them displayed here...</p>
                    )}
                    
                    <div className="bg-culinary-butter/30 p-6 rounded-lg border border-culinary-butter">
                      <h3 className="text-lg font-semibold text-culinary-navy mb-3">Take Home Materials</h3>
                      <p className="text-gray-700 mb-4">You'll leave the workshop with:</p>
                      <ul className="list-disc pl-6 space-y-2 text-gray-700">
                        <li>A recipe booklet with all the dishes covered in class</li>
                        <li>Tips and techniques cheat sheet</li>
                        <li>A small herb plant to grow at home</li>
                        <li>10% discount coupon for our shop</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Sidebar - Booking Section */}
              <div className="lg:col-span-1">
                <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200 sticky top-8 max-w-[300px] mx-auto">
                  <h2 className="text-2xl font-semibold text-culinary-navy mb-6">Book This Workshop</h2>
                  
                  <div className="mb-6">
                    <h3 className="text-lg font-medium text-culinary-navy mb-3">Select Date</h3>
                    <div className="border rounded-md p-1 compact-calendar w-full min-w-[240px] flex justify-center mr-4">
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={setSelectedDate}
                        disabled={(date) => {
                          // Disable past dates
                          if (date < new Date()) return true;

                          // If no workshop dates are set, disable all dates
                          if (calendarDates.length === 0) return true;

                          // Only enable dates that have workshop sessions
                          const dateString = date.toDateString();
                          const hasWorkshop = calendarDates.some(wsDate =>
                            wsDate.toDateString() === dateString
                          );

                          return !hasWorkshop;
                        }}
                        className="w-full"
                        modifiers={{
                          workshopDate: calendarDates
                        }}
                        modifiersStyles={{
                          workshopDate: {
                            backgroundColor: 'hsl(var(--culinary-terracotta))',
                            color: 'white',
                            fontWeight: 'bold'
                          }
                        }}
                      />
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <h3 className="text-lg font-medium text-culinary-navy mb-3">Select Time</h3>
                    <Select value={selectedTime} onValueChange={setSelectedTime}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select a time" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableTimes.map(time => (
                          <SelectItem key={time.iso} value={time.iso}>
                            {time.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="mb-6">
                    <h3 className="text-lg font-medium text-culinary-navy mb-3">Participants</h3>
                    <div className="flex items-center">
                      <button 
                        className="w-10 h-10 rounded-md bg-culinary-cream flex items-center justify-center hover:bg-culinary-cream/80 transition-colors"
                        onClick={() => setParticipants(prev => Math.max(1, prev - 1))}
                      >
                        -
                      </button>
                      <span className="mx-4 text-lg font-medium text-culinary-navy">{participants}</span>
                      <button 
                        className="w-10 h-10 rounded-md bg-culinary-cream flex items-center justify-center hover:bg-culinary-cream/80 transition-colors"
                        onClick={() => setParticipants(prev => Math.min(maxSpots, prev + 1))}
                      >
                        +
                      </button>
                    </div>
                  </div>
                  
                  {formData.price && (
                    <div className="mb-6 pt-4 border-t border-gray-200">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600">Price per person:</span>
                        <span className="font-medium text-culinary-navy">${formData.price}</span>
                      </div>
                      {participants > 1 && (
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-gray-600">{participants} participants:</span>
                          <span className="font-medium text-culinary-navy">${priceNumber * participants}</span>
                        </div>
                      )}
                      <div className="flex justify-between items-center text-lg font-bold mt-4">
                        <span className="text-culinary-navy">Total:</span>
                        <span className="text-culinary-terracotta">${totalPrice}</span>
                      </div>
                    </div>
                  )}
                  
                  <Button 
                    className="w-full bg-culinary-terracotta hover:bg-culinary-terracotta/90 h-12 text-lg flex items-center justify-center gap-2"
                    disabled={!formData.price}
                  >
                    <ShoppingCart className="h-5 w-5" />
                    {formData.price ? "Add to Cart" : "Set Price First"}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const AddWorkshop = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const editingWorkshop = (location.state as any)?.workshop as
    | {
        id: number;
        title: string;
        date: string;
        instructor: string;
        location: string;
        description?: string;
        type?: string;
        cuisine?: string;
        level?: string;
        duration?: string;
        price?: number;
        spots?: number;
        full_description?: string;
        what_youll_make?: string;
        seasonal_ingredients?: string[];
        learning_outcomes?: string[];
        image?: string | null;
      }
    | undefined;
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [seasonalIngredients, setSeasonalIngredients] = useState<string[]>(
    editingWorkshop?.seasonal_ingredients ?? [""]
  );
  const [learningOutcomes, setLearningOutcomes] = useState<string[]>(
    editingWorkshop?.learning_outcomes ?? [""]
  );
  const [workshopDate, setWorkshopDate] = useState<string>(
    editingWorkshop?.date ? editingWorkshop.date.split('T')[0] : ""
  );
  const [workshopTime, setWorkshopTime] = useState<string>("");
  const [workshopDates, setWorkshopDates] = useState<{date: string, times: string[]}[]>(() => {
    if (editingWorkshop?.date) {
      const d = new Date(editingWorkshop.date);
      return [
        {
          date: d.toLocaleDateString('en-CA'),
          times: [
            d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
          ],
        },
      ];
    }
    return [{ date: "", times: [""] }];
  });
  const [selectedImage, setSelectedImage] = useState<string>(editingWorkshop?.image ?? "");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  const form = useForm<z.infer<typeof workshopSchema>>({
    resolver: zodResolver(workshopSchema),
    defaultValues: {
      title: editingWorkshop?.title ?? "",
      description: editingWorkshop?.description ?? "",
      image: editingWorkshop?.image ?? "",
      type: editingWorkshop?.type ?? "",
      cuisine: editingWorkshop?.cuisine ?? "",
      chef: editingWorkshop?.instructor ?? "",
      level: editingWorkshop?.level ?? "",
      duration: editingWorkshop?.duration ?? "",
      location: editingWorkshop?.location ?? "",
      price: editingWorkshop?.price ? String(editingWorkshop.price) : "",
      spots: editingWorkshop?.spots ? String(editingWorkshop.spots) : "",
      fullDescription: editingWorkshop?.full_description ?? "",
      whatYoullMake: editingWorkshop?.what_youll_make ?? "",
    },
  });

  const watchedValues = form.watch();

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('file', file);
    setUploadingImage(true);
    try {
      const res = await api.post(
        `/api/admin/upload-image`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );
      const imgPath = res.data.path;
      form.setValue('image', imgPath);
      setSelectedImage(
        imgPath.startsWith('http')
          ? imgPath
          : `${import.meta.env.VITE_API_BASE_URL}${imgPath}`
      );
      setImageFile(file);
    } catch {
      toast.error('Failed to upload image');
    } finally {
      setUploadingImage(false);
    }
  };

  const addSeasonalIngredient = () => {
    setSeasonalIngredients([...seasonalIngredients, ""]);
  };

  const removeSeasonalIngredient = (index: number) => {
    if (seasonalIngredients.length > 1) {
      setSeasonalIngredients(seasonalIngredients.filter((_, i) => i !== index));
    }
  };

  const updateSeasonalIngredient = (index: number, value: string) => {
    const updated = [...seasonalIngredients];
    updated[index] = value;
    setSeasonalIngredients(updated);
  };

  const addLearningOutcome = () => {
    setLearningOutcomes([...learningOutcomes, ""]);
  };

  const removeLearningOutcome = (index: number) => {
    if (learningOutcomes.length > 1) {
      setLearningOutcomes(learningOutcomes.filter((_, i) => i !== index));
    }
  };

  const updateLearningOutcome = (index: number, value: string) => {
    const updated = [...learningOutcomes];
    updated[index] = value;
    setLearningOutcomes(updated);
  };

  const onSubmit = async (values: z.infer<typeof workshopSchema>) => {
    setIsSubmitting(true);

    // Validate additional fields
    const validIngredients = seasonalIngredients.filter(ingredient => ingredient.trim());
    const validOutcomes = learningOutcomes.filter(outcome => outcome.trim());
    const validDates = workshopDates
      .filter(dateObj => dateObj.date && dateObj.times.some(time => time.trim()))
      .map(ws => {
        const firstTime = ws.times.find(time => time.trim())!;
        const iso = new Date(`${ws.date}T${firstTime}`).toISOString();
        return { ...ws, date: iso };
      });

    if (validIngredients.length === 0) {
      toast.error("Please add at least one seasonal ingredient");
      setIsSubmitting(false);
      return;
    }

    if (validOutcomes.length === 0) {
      toast.error("Please add at least one learning outcome");
      setIsSubmitting(false);
      return;
    }

    if (!workshopDate || !workshopTime) {
      toast.error("Please add a workshop date and time");
      setIsSubmitting(false);
      return;
    }

    try {
      if (editingWorkshop) {
        await api.put(
          `/api/admin/workshops/${editingWorkshop.id}`,
          {
            title: values.title,
            date: workshopDate,
            instructor: values.chef,
            location: values.location,
            image: values.image,
            description: values.description,
            type: values.type,
            cuisine: values.cuisine,
            level: values.level,
            duration: values.duration,
            price: parseFloat(values.price),
            spots: parseInt(values.spots),
            full_description: values.fullDescription,
            what_youll_make: values.whatYoullMake,
            seasonal_ingredients: validIngredients,
            learning_outcomes: validOutcomes,
          },
        );
        toast.success("Workshop updated successfully!");
      } else {
        await api.post(
          `/api/admin/workshops`,
          {
            title: values.title,
            date: workshopDate,
            instructor: values.chef,
            location: values.location,
            image: values.image,
            description: values.description,
            type: values.type,
            cuisine: values.cuisine,
            level: values.level,
            duration: values.duration,
            price: parseFloat(values.price),
            spots: parseInt(values.spots),
            full_description: values.fullDescription,
            what_youll_make: values.whatYoullMake,
            seasonal_ingredients: validIngredients,
            learning_outcomes: validOutcomes,
          },
        );
        toast.success("Workshop created successfully!");
      }
      navigate("/admin");
    } catch (error) {
      toast.error(
        editingWorkshop ? "Failed to update workshop. Please try again." : "Failed to create workshop. Please try again."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-culinary-cream/10">
      <Navbar />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <div className="flex items-center gap-4 mb-8">
            <Button 
              variant="outline" 
              onClick={() => navigate("/admin")}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-culinary-navy">
                {editingWorkshop ? 'Edit Workshop' : 'Add New Workshop'}
              </h1>
              <p className="text-muted-foreground">
                {editingWorkshop ? 'Update your workshop details' : 'Create a detailed workshop experience for your customers'}
              </p>
            </div>
          </div>

          <div className="max-w-4xl mx-auto">
            {/* Form Section */}
            <div className="space-y-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  
                  {/* Workshop Overview Section */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <ChefHat className="h-5 w-5 text-culinary-terracotta" />
                        Workshop Overview
                      </CardTitle>
                      <CardDescription>
                        Basic information that appears on the workshop card and listing
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Workshop Title</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Italian Pasta Masterclass" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="image"
                        render={({ field }) => (
                           <FormItem>
                             <FormLabel className="flex items-center gap-2">
                               <ImageIcon className="h-4 w-4" />
                               Featured Image
                             </FormLabel>
                             <FormControl>
                               <div className="space-y-4">
                                 {/* Image Preview */}
                                 {(selectedImage || field.value) && (
                                   <div className="relative border border-gray-200 rounded-lg overflow-hidden">
                                     <img 
                                       src={selectedImage || field.value} 
                                       alt="Workshop preview" 
                                       className="w-full h-48 object-cover"
                                     />
                                     <button
                                       type="button"
                                       onClick={() => {
                                         setSelectedImage("");
                                         setImageFile(null);
                                         field.onChange("");
                                       }}
                                       className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-red-600"
                                     >
                                       ×
                                     </button>
                                   </div>
                                 )}
                                 
                                 {/* Upload Button */}
                                 <div className="flex items-center gap-4">
                                   <input
                                     type="file"
                                     accept="image/*"
                                     onChange={handleImageUpload}
                                     className="hidden"
                                     id="image-upload"
                                   />
                                   <label
                                     htmlFor="image-upload"
                                     className="cursor-pointer bg-culinary-sage text-white px-4 py-2 rounded-md hover:bg-culinary-sage/90 transition-colors flex items-center gap-2"
                                   >
                                     <ImageIcon className="h-4 w-4" />
                                     {uploadingImage ? 'Uploading...' : selectedImage || field.value ? 'Change Image' : 'Upload Image'}
                                   </label>
                                   
                                   {/* Fallback URL Input */}
                                   <div className="flex-1">
                                     <Input 
                                       placeholder="Or paste image URL" 
                                       value={field.value}
                                       onChange={(e) => {
                                         field.onChange(e.target.value);
                                         if (e.target.value) {
                                           setSelectedImage("");
                                           setImageFile(null);
                                         }
                                       }}
                                       className="text-sm"
                                     />
                                   </div>
                                 </div>
                               </div>
                             </FormControl>
                             <FormDescription>
                               Upload an image or paste a URL. Use high-quality images that represent your workshop.
                             </FormDescription>
                             <FormMessage />
                           </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Short Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="A brief, engaging description that appears on the workshop card..."
                                className="min-h-[100px]"
                                {...field} 
                              />
                            </FormControl>
                            <FormDescription>
                              This appears on workshop listings and cards (keep it concise)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>

                  {/* Workshop Details Section */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Tag className="h-5 w-5 text-culinary-terracotta" />
                        Workshop Details
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="type"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Workshop Type</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="group">Group Lesson</SelectItem>
                                  <SelectItem value="kids">Kids Workshop</SelectItem>
                                  <SelectItem value="date-night">Date Night</SelectItem>
                                  <SelectItem value="private">Private Session</SelectItem>
                                  <SelectItem value="team-building">Team Building</SelectItem>
                                  <SelectItem value="crash-course">Crash Course</SelectItem>
                                  <SelectItem value="seasonal">Seasonal Special</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="cuisine"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Cuisine Type</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select cuisine" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="Italian">Italian</SelectItem>
                                  <SelectItem value="Japanese">Japanese</SelectItem>
                                  <SelectItem value="French">French</SelectItem>
                                  <SelectItem value="Thai">Thai</SelectItem>
                                  <SelectItem value="Mediterranean">Mediterranean</SelectItem>
                                  <SelectItem value="Baking">Baking</SelectItem>
                                  <SelectItem value="Fusion">Fusion</SelectItem>
                                  <SelectItem value="Modern American">Modern American</SelectItem>
                                  <SelectItem value="Various">Various</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="chef"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Chef/Instructor</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Chef Maria" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="duration"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="flex items-center gap-2">
                                <Clock className="h-4 w-4" />
                                Duration
                              </FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., 3 hours" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="location"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="flex items-center gap-2">
                                <MapPin className="h-4 w-4" />
                                Location
                              </FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Main Kitchen Studio" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="level"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Skill Level</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select level" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="beginner">Beginner</SelectItem>
                                  <SelectItem value="intermediate">Intermediate</SelectItem>
                                  <SelectItem value="advanced">Advanced</SelectItem>
                                  <SelectItem value="all-levels">All Levels</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Pricing Section */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <DollarSign className="h-5 w-5 text-culinary-terracotta" />
                        Pricing & Capacity
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="price"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Price per Person ($)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01"
                                  placeholder="85.00" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>
                                Enter price in USD (without $ symbol)
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="spots"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="flex items-center gap-2">
                                <Users className="h-4 w-4" />
                                Maximum Participants
                              </FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="12" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Seasonal Ingredients Section */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Leaf className="h-5 w-5 text-culinary-terracotta" />
                        Seasonal Ingredients
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {seasonalIngredients.map((ingredient, index) => (
                        <div key={index} className="flex gap-2">
                          <Input
                            placeholder={`Seasonal ingredient ${index + 1}`}
                            value={ingredient}
                            onChange={(e) => updateSeasonalIngredient(index, e.target.value)}
                          />
                          {seasonalIngredients.length > 1 && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => removeSeasonalIngredient(index)}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      ))}
                      <Button
                        type="button"
                        variant="outline"
                        onClick={addSeasonalIngredient}
                        className="w-full"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Seasonal Ingredient
                      </Button>
                    </CardContent>
                  </Card>

                  {/* What You'll Learn Section */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <ChefHat className="h-5 w-5 text-culinary-terracotta" />
                        What You'll Learn
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {learningOutcomes.map((outcome, index) => (
                        <div key={index} className="flex gap-2">
                          <Textarea
                            placeholder={`Learning outcome ${index + 1}`}
                            value={outcome}
                            onChange={(e) => updateLearningOutcome(index, e.target.value)}
                            className="min-h-[60px]"
                          />
                          {learningOutcomes.length > 1 && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => removeLearningOutcome(index)}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      ))}
                      <Button
                        type="button"
                        variant="outline"
                        onClick={addLearningOutcome}
                        className="w-full"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Learning Outcome
                      </Button>
                    </CardContent>
                  </Card>

                  {/* Full Description Section */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Detailed Description</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="fullDescription"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Workshop Overview (Detailed)</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Provide a detailed description of the workshop experience..."
                                className="min-h-[120px]"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="whatYoullMake"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>What You'll Make</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Describe the specific dishes participants will create..."
                                className="min-h-[80px]"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>

                  {/* Workshop Dates & Times Section */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <CalendarIcon className="h-5 w-5 text-culinary-terracotta" />
                        Workshop Dates & Times
                      </CardTitle>
                      <CardDescription>
                        Set up multiple workshop sessions with dates and time slots
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Workshop Date
                          </label>
                          <Input
                            type="date"
                            value={workshopDate}
                            onChange={(e) => setWorkshopDate(e.target.value)}
                            min={new Date().toISOString().split('T')[0]}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Time
                          </label>
                          <Input
                            type="time"
                            value={workshopTime}
                            onChange={(e) => setWorkshopTime(e.target.value)}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <div className="flex justify-end gap-4 pt-4">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => navigate("/admin")}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={isSubmitting}
                      className="bg-culinary-sage hover:bg-culinary-sage/90"
                    >
                      {isSubmitting ? (
                        editingWorkshop ? 'Updating Workshop...' : 'Creating Workshop...'
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          {editingWorkshop ? 'Update Workshop' : 'Create Workshop'}
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </div>

            {/* Live Preview Section - Below Form */}
            <div className="mt-12">
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-culinary-navy mb-2">Workshop Preview</h2>
                <p className="text-muted-foreground">This is how your workshop will appear to customers</p>
              </div>
              <WorkshopPreview
                formData={watchedValues}
                seasonalIngredients={seasonalIngredients}
                learningOutcomes={learningOutcomes}
                workshopDate={workshopDate}
                workshopTime={workshopTime}
                workshopDates={workshopDates}
              />
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default AddWorkshop;