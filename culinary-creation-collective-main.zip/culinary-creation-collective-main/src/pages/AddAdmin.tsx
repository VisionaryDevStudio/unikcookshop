import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import api from "@/utils/api";
import { toast } from "sonner";
import { useLocation, useNavigate } from "react-router-dom";
import { ArrowLeft, User } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";

const adminSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6).optional(),
  isAdmin: z.boolean(),
});

type AdminValues = z.infer<typeof adminSchema>;

const AddAdmin = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const editingUser = (location.state as any)?.user as
    | { id: number; name: string; email: string; is_admin: boolean }
    | undefined;

  const form = useForm<AdminValues>({
    resolver: zodResolver(adminSchema),
    defaultValues: {
      name: editingUser?.name ?? "",
      email: editingUser?.email ?? "",
      password: editingUser ? undefined : "",
      isAdmin: editingUser?.is_admin ?? true,
    },
  });

  const onSubmit = async (data: AdminValues) => {
    try {
      if (editingUser) {
        await api.put(
          `/api/admin/users/${editingUser.id}`,
          { name: data.name, email: data.email, is_admin: data.isAdmin },
        );
        toast.success("Admin updated");
      } else {
        await api.post(
          `/api/admin/create`,
          { name: data.name, email: data.email, password: data.password },
        );
        toast.success("Admin created");
        form.reset();
      }
      navigate('/admin');
    } catch {
      toast.error(editingUser ? "Failed to update admin" : "Failed to create admin");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />

      <main className="flex-grow py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 mb-8">
            <Button
              variant="outline"
              onClick={() => navigate('/admin')}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Admin
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-culinary-navy">
                {editingUser ? 'Edit Admin' : 'Add New Admin'}
              </h1>
              <p className="text-gray-600">
                {editingUser ? 'Update admin information' : 'Create a new admin user'}
              </p>
            </div>
          </div>

          <div className="max-w-lg mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Admin Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    {!editingUser && (
                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                    {editingUser && (
                      <FormField
                        control={form.control}
                        name="isAdmin"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Admin privileges</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                    )}
                    <Button type="submit" className="w-full bg-culinary-terracotta hover:bg-culinary-terracotta/90">
                      {editingUser ? 'Update Admin' : 'Create Admin'}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default AddAdmin;
