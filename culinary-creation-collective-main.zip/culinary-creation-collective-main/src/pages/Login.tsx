
import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { ChefHat } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useAuth } from "@/context/AuthContext";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

type LoginValues = z.infer<typeof loginSchema>;

const Login = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const { login, googleLogin } = useAuth();

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    try {
      await googleLogin();
      toast({
        title: "Login Successful",
        description: "Welcome back to Unikcookshop!",
      });
      const from = location.state?.from || "/dashboard";
      navigate(from);
    } catch (error) {
      toast({
        title: "Login Failed",
        description: "Google login failed",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const form = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginValues) => {
    setIsLoading(true);
    
    try {
      await login(data.email, data.password);
      
      // Display message based on login
      toast({
        title: "Login Successful",
        description: "Welcome back to Unikcookshop!",
      });
      
      // Redirect to previous location or dashboard
      const from = location.state?.from || "/dashboard";
      navigate(from);
    } catch (error) {
      toast({
        title: "Login Failed",
        description: "Invalid email or password",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Navbar />
      <div className="container mx-auto px-4 py-8 md:py-16">
        <div className="mx-auto max-w-md space-y-6">
          <div className="flex justify-center">
            <div className="rounded-full bg-culinary-cream p-3">
              <ChefHat className="h-8 w-8 text-culinary-terracotta" />
            </div>
          </div>
          
          <div className="space-y-2 text-center">
            <h1 className="text-3xl font-bold text-culinary-navy">Welcome Back</h1>
            <p className="text-muted-foreground">Sign in to continue your culinary journey</p>
          </div>

          <div className="rounded-lg border bg-card p-6 shadow-sm">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="email@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="••••••••" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-between items-center">
                  <Link to="/forgot-password" className="text-sm text-culinary-terracotta hover:underline">
                    Forgot Password?
                  </Link>
                </div>
                
                <Button type="submit" className="w-full bg-culinary-terracotta hover:bg-culinary-terracotta/90" disabled={isLoading}>
                  {isLoading ? "Signing in..." : "Sign In"}
                </Button>
              </form>
            </Form>
            
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or continue with</span>
              </div>
            </div>
            
            <Button
              variant="outline"
              className="w-full"
              onClick={handleGoogleLogin}
              disabled={isLoading}
            >
              <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                <path
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  fill="#4285F4"
                />
                <path
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  fill="#34A853"
                />
                <path
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  fill="#FBBC05"
                />
                <path
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  fill="#EA4335"
                />
              </svg>
              Continue with Google
            </Button>
            
            <div className="mt-6 text-center text-sm">
              Don't have an account?{" "}
              <Link to="/signup" className="font-medium text-culinary-terracotta hover:underline">
                Sign up
              </Link>
            </div>

            <div className="mt-6 pt-4 border-t border-gray-200">
              <div className="text-center text-sm text-gray-500 mb-2">For demo purposes:</div>
              <div className="text-xs text-gray-500">
                <p>Admin login: admin@unikcookshop.com / admin123</p>
                <p>Student login: student@example.com / any password</p>
              </div>
            </div>
          </div>
          
          <div className="text-center text-sm text-muted-foreground">
            By signing in, you agree to our{" "}
            <Link to="#" className="underline underline-offset-4 hover:text-foreground">
              Terms of Service
            </Link>{" "}
            and{" "}
            <Link to="#" className="underline underline-offset-4 hover:text-foreground">
              Privacy Policy
            </Link>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Login;
