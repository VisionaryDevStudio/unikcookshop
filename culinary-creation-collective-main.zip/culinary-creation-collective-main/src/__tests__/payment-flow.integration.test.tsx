import * as React from "react";
import { describe, it, beforeEach, expect, vi } from "vitest";

const mockApi = {
  get: vi.fn(),
  post: vi.fn(),
  defaults: { headers: { common: {} as Record<string, unknown> } },
  interceptors: { request: { use: vi.fn() }, response: { use: vi.fn() } },
};

const axiosGetMock = vi.fn();

const hasAxiosFlag = (err: unknown): err is { isAxiosError?: boolean } =>
  typeof err === "object" && err !== null && "isAxiosError" in err;

const hasNameProperty = (err: unknown): err is { name?: string } =>
  typeof err === "object" && err !== null && "name" in err;

type StripeCardElementMock = {
  on: (event: string, handler: (event: unknown) => void) => void;
  off: (event: string, handler: (event: unknown) => void) => void;
};

const cardElementMock: StripeCardElementMock = {
  on: vi.fn(),
  off: vi.fn(),
};

const mockElements = {
  getElement: vi.fn<[], StripeCardElementMock | null>(() => cardElementMock),
};

interface ConfirmCardPaymentResult {
  paymentIntent?: { id: string; status: string; client_secret?: string };
  error?: {
    type?: string;
    message?: string;
    payment_intent?: { id?: string; status?: string };
  };
}

const mockStripe = {
  confirmCardPayment: vi.fn<
    [string, Record<string, unknown>],
    Promise<ConfirmCardPaymentResult>
  >(),
};

const toast = {
  success: vi.fn(),
  error: vi.fn(),
  info: vi.fn(),
};

vi.mock("@/utils/api", () => ({ default: mockApi }));

vi.mock("axios", () => ({
  default: {
    get: axiosGetMock,
    create: () => mockApi,
    isAxiosError: (err: unknown) =>
      hasAxiosFlag(err) ? Boolean(err.isAxiosError) : false,
    isCancel: (err: unknown) =>
      hasNameProperty(err) ? err.name === "CanceledError" : false,
  },
  get: axiosGetMock,
  create: () => mockApi,
  isAxiosError: (err: unknown) =>
    hasAxiosFlag(err) ? Boolean(err.isAxiosError) : false,
  isCancel: (err: unknown) =>
    hasNameProperty(err) ? err.name === "CanceledError" : false,
}));

vi.mock("@stripe/react-stripe-js", () => {
  const MockCardElement: React.FC<
    React.InputHTMLAttributes<HTMLInputElement>
  > = (props) => <input data-testid="card-element" {...props} />;
  const MockElements: React.FC<React.PropsWithChildren> = ({ children }) => (
    <>{children}</>
  );
  return {
    CardElement: MockCardElement,
    Elements: MockElements,
    useStripe: () => mockStripe,
    useElements: () => mockElements,
  };
});

vi.mock("sonner", () => ({ toast }));

vi.mock("@/components/Navbar", () => ({
  default: () => <div data-testid="navbar" />,
}));

vi.mock("@/components/Footer", () => ({
  default: () => <div data-testid="footer" />,
}));

vi.mock("@/context/AuthContext", () => {
  type AuthContextValue = {
    user: { id: number; name: string } | null;
    login: () => Promise<void>;
    logout: () => void;
    signup: () => Promise<void>;
    googleLogin: () => Promise<void>;
    updateProfile: () => Promise<void>;
    changePassword: () => Promise<void>;
    isAuthenticated: boolean;
    isAdmin: boolean;
  };
  const AuthContext = React.createContext<AuthContextValue | null>(null);
  const value: AuthContextValue = {
    user: { id: 1, name: "Test User" },
    login: vi.fn(async () => {}),
    logout: vi.fn(),
    signup: vi.fn(async () => {}),
    googleLogin: vi.fn(async () => {}),
    updateProfile: vi.fn(async () => {}),
    changePassword: vi.fn(async () => {}),
    isAuthenticated: true,
    isAdmin: false,
  };
  const AuthProvider: React.FC<React.PropsWithChildren> = ({ children }) => (
    <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
  );
  const useAuth = () => {
    const context = React.useContext(AuthContext);
    if (!context) {
      throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
  };
  return { AuthProvider, useAuth };
});

vi.mock("@/context/CartContext", () => {
  type CartItem = {
    id: number;
    name: string;
    price: number;
    category: string;
    image: string;
    quantity: number;
    type: "product" | "workshop";
    scheduled_at?: string;
  };
  type CartContextValue = {
    cartItems: CartItem[];
    addToCart: (item: Omit<CartItem, "quantity">) => void;
    removeFromCart: (
      id: number,
      type: "product" | "workshop",
      scheduled_at?: string,
    ) => void;
    updateQuantity: (
      id: number,
      type: "product" | "workshop",
      quantity: number,
      scheduled_at?: string,
    ) => void;
    clearCart: () => void;
    getCartTotal: () => number;
  };
  const CartContext = React.createContext<CartContextValue | null>(null);
  const CartProvider: React.FC<React.PropsWithChildren> = ({ children }) => {
    const [cartItems, setCartItems] = React.useState<CartItem[]>([]);
    const value = React.useMemo<CartContextValue>(
      () => ({
        cartItems,
        addToCart: (item: Omit<CartItem, "quantity">) => {
          setCartItems((prev) => {
            const existingIndex = prev.findIndex(
              (p) =>
                p.id === item.id &&
                p.type === item.type &&
                p.scheduled_at === item.scheduled_at,
            );
            if (existingIndex >= 0) {
              const updated = [...prev];
              updated[existingIndex] = {
                ...updated[existingIndex],
                quantity: updated[existingIndex].quantity + 1,
              };
              return updated;
            }
            return [...prev, { ...item, quantity: 1 }];
          });
        },
        removeFromCart: (
          id: number,
          type: "product" | "workshop",
          scheduled_at?: string,
        ) => {
          setCartItems((prev) =>
            prev.filter(
              (item) =>
                !(item.id === id && item.type === type && item.scheduled_at === scheduled_at),
            ),
          );
        },
        updateQuantity: (
          id: number,
          type: "product" | "workshop",
          quantity: number,
          scheduled_at?: string,
        ) => {
          setCartItems((prev) =>
            prev.map((item) =>
              item.id === id && item.type === type && item.scheduled_at === scheduled_at
                ? { ...item, quantity }
                : item,
            ),
          );
        },
        clearCart: () => setCartItems([]),
        getCartTotal: () =>
          cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0),
      }),
      [cartItems],
    );
    return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
  };
  const useCart = () => {
    const context = React.useContext(CartContext);
    if (!context) {
      throw new Error("useCart must be used within a CartProvider");
    }
    return context;
  };
  return { CartProvider, useCart };
});

import { render, screen, waitFor, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
  MemoryRouter,
  Routes,
  Route,
  useNavigate,
  type NavigateFunction,
} from "react-router-dom";
import { useEffect } from "react";

import ShopPreview from "@/components/ShopPreview";
import Cart from "@/pages/Cart";
import { AuthProvider } from "@/context/AuthContext";
import { CartProvider } from "@/context/CartContext";

interface BackendStub {
  totalCents: number;
  transactions: Array<{ id: number; payment_intent_id: string | undefined; status: string; total: number }>;
  cancellations: string[];
  webhookEvents: Array<{ type: string; payload: unknown }>;
  readonly lastClientSecret: string | null;
  setCheckoutFailure: (error: unknown) => void;
  resetCheckoutFailure: () => void;
  handleAxiosGet: (url: string) => Promise<{ data: unknown }>;
  handleGet: (url: string) => Promise<{ data: unknown }>;
  handlePost: (
    url: string,
    body?: Record<string, unknown>,
  ) => Promise<{ data: unknown }>;
  product: { id: number; name: string; price: number; image: string; rating: number; review_count: number };
}

const createBackendStub = (totalCents = 2500): BackendStub => {
  let intentCounter = 0;
  let checkoutFailure: unknown | null = null;
  const transactions: BackendStub["transactions"] = [];
  const cancellations: string[] = [];
  const webhookEvents: BackendStub["webhookEvents"] = [];
  let lastClientSecret: string | null = null;
  const product = {
    id: 101,
    name: "Artisan Chef Knife",
    price: totalCents / 100,
    image: "knife.jpg",
    rating: 4.9,
    review_count: 128,
  };
  return {
    totalCents,
    transactions,
    cancellations,
    webhookEvents,
    get lastClientSecret() {
      return lastClientSecret;
    },
    product,
      setCheckoutFailure: (error: unknown) => {
        checkoutFailure = error ?? new Error("Checkout failed");
        if (checkoutFailure instanceof Error) {
          (checkoutFailure as Error & { isAxiosError?: boolean }).isAxiosError = true;
        }
      },
    resetCheckoutFailure: () => {
      checkoutFailure = null;
    },
    async handleAxiosGet(url: string) {
      if (url.endsWith("/api/public/products")) {
        return { data: [product] };
      }
      throw new Error(`Unhandled axios GET: ${url}`);
    },
    async handleGet(url: string) {
      if (url === "/api/cart/total") {
        return { data: { total: totalCents } };
      }
      if (url === "/api/cart/summary") {
        return { data: { subtotal: totalCents / 100 } };
      }
      if (url === "/api/users/me/payment-methods") {
        return { data: [] };
      }
      throw new Error(`Unhandled API GET: ${url}`);
    },
      async handlePost(url: string, body?: Record<string, unknown>) {
        if (url === "/api/cart/create-payment-intent") {
          const id = `pi_${++intentCounter}`;
          const secret = `${id}_secret_mock`;
        lastClientSecret = secret;
        return {
          data: {
            client_secret: secret,
            amount: totalCents,
          },
        };
      }
        if (url === "/api/cart/checkout") {
          if (checkoutFailure) {
            throw checkoutFailure;
          }
          const paymentIntentId =
            typeof body?.payment_intent_id === "string"
              ? (body.payment_intent_id as string)
              : undefined;
          const transaction = {
            id: transactions.length + 1,
            payment_intent_id: paymentIntentId ?? "",
            status: "Paid",
            total: totalCents / 100,
          };
        transactions.push(transaction);
        webhookEvents.push({ type: "payment_intent.succeeded", payload: transaction });
        return { data: [transaction] };
      }
        if (url === "/api/cart/cancel-payment-intent") {
          const paymentIntentId =
            typeof body?.payment_intent_id === "string"
              ? (body.payment_intent_id as string)
              : undefined;
          if (paymentIntentId) {
            cancellations.push(paymentIntentId);
            webhookEvents.push({
              type: "payment_intent.canceled",
              payload: { id: paymentIntentId },
            });
          }
          return { data: { cancelled: true } };
      }
      throw new Error(`Unhandled API POST: ${url}`);
    },
  };
};

let backend: BackendStub;
let navigateRef: NavigateFunction | null = null;

const NavigationCatcher = () => {
  const navigate = useNavigate();
  useEffect(() => {
    navigateRef = navigate;
  }, [navigate]);
  return null;
};

const renderFlow = () => {
  return render(
    <AuthProvider>
      <CartProvider>
        <MemoryRouter initialEntries={["/"]}>
          <NavigationCatcher />
          <Routes>
            <Route path="/" element={<ShopPreview />} />
            <Route path="/cart" element={<Cart />} />
            <Route
              path="/payment-success"
              element={<div data-testid="payment-success-page">Payment success page</div>}
            />
            <Route
              path="/payment-cancelled"
              element={<div data-testid="payment-cancelled-page">Payment cancelled page</div>}
            />
            <Route path="/login" element={<div data-testid="login-page">Login</div>} />
          </Routes>
        </MemoryRouter>
      </CartProvider>
    </AuthProvider>,
  );
};

const openCartAndModal = async (user: ReturnType<typeof userEvent.setup>) => {
  await waitFor(() => expect(navigateRef).toBeInstanceOf(Function));

  const productName = backend.product.name;
  await waitFor(() => expect(axiosGetMock).toHaveBeenCalled());
  await screen.findByText(productName);
  const addButton = screen.getAllByRole("button", { name: /Add to Cart/i })[0];
  await user.click(addButton);

  await act(async () => {
    navigateRef!("/cart");
  });

  await screen.findByRole("heading", { name: /Shopping Cart/i });
  const proceedButton = await screen.findByRole("button", { name: /Proceed to Payment/i });
  await user.click(proceedButton);
  await screen.findByRole("heading", { name: /Payment Information/i });
  await screen.findByText(/Total Amount:/i);
};

const fillPaymentForm = async (user: ReturnType<typeof userEvent.setup>) => {
  await user.type(screen.getByLabelText(/Email Address/i), "guest@example.com");
  await user.type(screen.getByLabelText(/Cardholder Name/i), "Jane Doe");
  await user.type(screen.getByLabelText(/Street Address/i), "123 Main Street");
  await user.type(screen.getByLabelText(/^City/i), "New York");
  await user.type(screen.getByLabelText(/Postal Code/i), "10001");
  await user.type(screen.getByLabelText(/Country/i), "US");
  await user.click(
    screen.getByText(/I agree to the Terms of Service and Privacy Policy/i),
  );
};

beforeEach(() => {
  backend = createBackendStub();
  navigateRef = null;
  mockApi.get.mockReset();
  mockApi.post.mockReset();
  axiosGetMock.mockReset();
  mockStripe.confirmCardPayment.mockReset();
  mockElements.getElement.mockImplementation(() => cardElementMock);
  cardElementMock.on.mockReset();
  cardElementMock.off.mockReset();
  toast.success.mockReset();
  toast.error.mockReset();
  toast.info.mockReset();
  import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY = "pk_test_123";
  import.meta.env.VITE_API_BASE_URL = "";

  axiosGetMock.mockImplementation((...args: unknown[]) =>
    backend.handleAxiosGet(args[0] as string),
  );
  mockApi.get.mockImplementation((...args: unknown[]) =>
    backend.handleGet(args[0] as string),
  );
  mockApi.post.mockImplementation((...args: unknown[]) =>
    backend.handlePost(args[0] as string, args[1]),
  );
});

describe("payment lifecycle integration", () => {
  it("processes a successful payment and persists transactions", async () => {
    renderFlow();
    const user = userEvent.setup();

    await openCartAndModal(user);
    await fillPaymentForm(user);

    mockStripe.confirmCardPayment.mockResolvedValueOnce({
      paymentIntent: { id: "pi_1", status: "succeeded" },
    });

    const payButton = await screen.findByRole("button", { name: /Pay/i });
    await user.click(payButton);

    await screen.findByTestId("payment-success-page");

    expect(mockStripe.confirmCardPayment).toHaveBeenCalledWith(
      backend.lastClientSecret,
      expect.any(Object),
    );
    expect(backend.transactions).toHaveLength(1);
    expect(backend.transactions[0].payment_intent_id).toBe("pi_1");
    expect(backend.webhookEvents).toContainEqual(
      expect.objectContaining({ type: "payment_intent.succeeded" }),
    );
    expect(toast.success).toHaveBeenCalledWith(
      "Payment successful! Thank you for your purchase.",
    );
  });

  it("handles Stripe cancellations and routes to the cancellation screen", async () => {
    renderFlow();
    const user = userEvent.setup();

    await openCartAndModal(user);
    await fillPaymentForm(user);

    mockStripe.confirmCardPayment.mockResolvedValueOnce({
      error: {
        type: "card_error",
        message: "Card declined",
        payment_intent: { id: "pi_cancel", status: "requires_payment_method" },
      },
    });

    const payButton = await screen.findByRole("button", { name: /Pay/i });
    await user.click(payButton);

    await screen.findByTestId("payment-cancelled-page");

    expect(toast.error).toHaveBeenCalledWith(
      "Your card was declined. Please try another payment method.",
    );
    expect(toast.success).toHaveBeenCalledWith("Payment canceled");
    expect(backend.cancellations).toContain("pi_cancel");
    expect(backend.webhookEvents).toContainEqual(
      expect.objectContaining({
        type: "payment_intent.canceled",
        payload: expect.objectContaining({ id: "pi_cancel" }),
      }),
    );
  });

  it("surfaces checkout failures and avoids recording transactions", async () => {
    backend.setCheckoutFailure(new Error("Checkout unavailable"));
    renderFlow();
    const user = userEvent.setup();

    await openCartAndModal(user);
    await fillPaymentForm(user);

    mockStripe.confirmCardPayment.mockResolvedValueOnce({
      paymentIntent: { id: "pi_fail", status: "succeeded" },
    });

    const payButton = await screen.findByRole("button", { name: /Pay/i });
    await user.click(payButton);

    await screen.findByTestId("payment-cancelled-page");

    await waitFor(() =>
      expect(toast.error).toHaveBeenCalledWith(
        "Payment succeeded but checkout failed",
        expect.any(Object),
      ),
    );
    expect(backend.transactions).toHaveLength(0);
    expect(backend.cancellations).toContain("pi_fail");
  });
});

