import { render, screen } from "@testing-library/react";
import App from "../App";

describe("App payment warning", () => {
  it("renders warning when Stripe key is missing", () => {
    // Ensure the key is absent for this test
    // @ts-ignore
    import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY = undefined;
    render(<App />);
    expect(
      screen.getByText(/Payment processing is currently unavailable/i)
    ).toBeInTheDocument();
  });
});
