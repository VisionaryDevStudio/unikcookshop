import axios from 'axios';

function getCsrfToken(): string | null {
  // Try reading from cookie first
  const match = document.cookie.match(/(?:^|;\s*)csrf_token=([^;]+)/);
  if (match) {
    return decodeURIComponent(match[1]);
  }

  // Fallback to meta tag
  const meta = document.querySelector('meta[name="csrf-token"]');
  return meta ? meta.getAttribute('content') : null;
}

async function ensureCsrfToken(): Promise<string | null> {
  const existing = getCsrfToken();
  if (existing) {
    api.defaults.headers.common['X-CSRF-Token'] = existing;
    return existing;
  }

  try {
    const resp = await api.get('/api/auth/csrf-token');
    const token = resp.data?.csrf_token;
    if (token) {
      api.defaults.headers.common['X-CSRF-Token'] = token;
      return token;
    }
  } catch {
    // ignore
  }
  return null;
}

const api = axios.create({
  // Allow overriding the API base URL via environment variable while
  // defaulting to relative paths so the Vite proxy can be used in
  // development without triggering CORS errors.
  baseURL: import.meta.env.VITE_API_BASE_URL || '',
  withCredentials: true,
});

void ensureCsrfToken();

api.interceptors.request.use(async (config) => {
  if (config.url?.includes('/api/auth/csrf-token')) {
    return config;
  }
  const token = getCsrfToken();
  if (!token) {
    const newToken = await ensureCsrfToken();
    if (newToken) {
      config.headers = config.headers || {};
      config.headers['X-CSRF-Token'] = newToken;
    }
  } else {
    config.headers = config.headers || {};
    config.headers['X-CSRF-Token'] = token;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 403 && !error.config.__isCsrfRetry) {
      const newToken = await ensureCsrfToken();
      if (newToken) {
        error.config.__isCsrfRetry = true;
        error.config.headers['X-CSRF-Token'] = newToken;
        return api(error.config);
      }
    }

    if (error.response?.status === 401 && !error.config.__isRetry) {
      try {
        error.config.__isRetry = true;
        await api.post('/api/auth/refresh');
        return api(error.config);
      } catch {
        return Promise.reject(error);
      }
    }
    return Promise.reject(error);
  }
);

export default api;
