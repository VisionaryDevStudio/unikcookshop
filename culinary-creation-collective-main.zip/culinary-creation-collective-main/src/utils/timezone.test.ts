import { formatUserTime, getTimeZoneForLocation } from './timezone';
import { describe, it, expect, vi } from 'vitest';

describe('timezone utilities', () => {
  it('maps location to timezone', () => {
    expect(getTimeZoneForLocation('Culinary Studio A')).toBe('America/New_York');
  });

  it('formats time in provided timezone even when user timezone differs', () => {
    vi
      .spyOn(Intl.DateTimeFormat.prototype, 'resolvedOptions')
      .mockReturnValue({ timeZone: 'Asia/Tokyo' } as Intl.ResolvedDateTimeFormatOptions);
    const date = new Date('2023-01-01T15:00:00Z');
    const formatted = formatUserTime(date, {}, 'America/New_York');
    expect(formatted).toMatch(/10:00/);
  });
});
