export const getStatusColor = (status: string) => {
  switch (status?.toLowerCase()) {
    case "completed":
    case "paid":
      return "text-green-600";
    case "processing":
    case "pending":
      return "text-yellow-600";
    case "refunded":
      return "text-blue-600";
    case "failed":
      return "text-red-600";
    case "canceled":
    case "cancelled":
      return "text-orange-600";
    case "disputed":
      return "text-purple-600";
    default:
      return "text-gray-600";
  }
};
