import { describe, it, expect } from 'vitest';
import { isValidPaymentIntentId } from './payment';

describe('isValidPaymentIntentId', () => {
  it('accepts valid payment intent IDs', () => {
    expect(isValidPaymentIntentId('pi_abc123')).toBe(true);
  });

  it('rejects invalid payment intent IDs', () => {
    expect(isValidPaymentIntentId('invalid')).toBe(false);
  });
});
