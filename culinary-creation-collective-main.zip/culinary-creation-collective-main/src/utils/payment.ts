export function isValidPaymentIntentId(id: string): boolean {
  return /^pi_[A-Za-z0-9]+$/.test(id);
}
