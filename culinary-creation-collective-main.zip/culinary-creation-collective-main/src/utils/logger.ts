const SENSITIVE_KEYS = [
  "card",
  "client_secret",
  "payment_method",
  "paymentMethod",
  "payment_method_details",
];

function sanitize(data: unknown): unknown {
  if (!data || typeof data !== "object") return data;
  if (Array.isArray(data)) return data.map(sanitize);
  const sanitized: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(data as Record<string, unknown>)) {
    if (SENSITIVE_KEYS.includes(key)) {
      sanitized[key] = "[REDACTED]";
    } else {
      sanitized[key] = sanitize(value);
    }
  }
  return sanitized;
}

export function sanitizeError(error: unknown): unknown {
  return sanitize(error);
}

interface MonitoringSDK {
  captureException: (error: unknown, context?: string) => void;
}

export function logError(error: unknown, context?: string) {
  const safeError = sanitizeError(error);
  if (context) {
    console.error(context, safeError);
  } else {
    console.error(safeError);
  }
  const globalObj = globalThis as unknown as {
    Sentry?: MonitoringSDK;
    __monitoring__?: MonitoringSDK;
  };
  const monitoring = globalObj.Sentry ?? globalObj.__monitoring__;
  if (typeof monitoring?.captureException === "function") {
    monitoring.captureException(safeError, context);
  }
}
