export const userTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

// Map known workshop locations to their respective IANA time zone identifiers
const LOCATION_TIMEZONES: Record<string, string> = {
  'Culinary Studio A': 'America/New_York',
  'Culinary Studio B': 'America/Los_Angeles',
  // Short codes used in some tests
  A: 'America/New_York',
  B: 'America/Los_Angeles',
};

export function getTimeZoneForLocation(location: string): string | undefined {
  return LOCATION_TIMEZONES[location];
}

export function formatUserDate(
  date: string | Date,
  options: Intl.DateTimeFormatOptions = {},
  timeZoneOverride?: string
) {
  const d = typeof date === 'string' ? new Date(date) : date;
  return new Intl.DateTimeFormat('default', {
    timeZone: timeZoneOverride || userTimeZone,
    ...options,
  }).format(d);
}

export function formatUserTime(
  date: string | Date,
  options: Intl.DateTimeFormatOptions = {},
  timeZoneOverride?: string
) {
  const d = typeof date === 'string' ? new Date(date) : date;
  return new Intl.DateTimeFormat('default', {
    timeZone: timeZoneOverride || userTimeZone,
    hour: '2-digit',
    minute: '2-digit',
    ...options,
  }).format(d);
}
