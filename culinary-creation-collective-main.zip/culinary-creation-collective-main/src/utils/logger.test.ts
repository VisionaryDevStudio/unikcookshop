import { logError } from './logger';
import { describe, it, expect, vi } from 'vitest';

describe('logError', () => {
  it('masks sensitive payment fields', () => {
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {});
    const err = {
      message: 'fail',
      client_secret: 'secret123',
      card: { number: '4242424242424242' },
      nested: { payment_method: 'pm_123', details: { client_secret: 'sec' } },
    };
    logError(err, 'payment error');
    const logged = spy.mock.calls[0][1];
    const output = JSON.stringify(logged);
    expect(output).not.toContain('secret123');
    expect(output).not.toContain('424242');
    expect(output).not.toContain('pm_123');
    spy.mockRestore();
  });

  it('sends sanitized error to monitoring SDK', () => {
    interface Monitor {
      captureException: (error: unknown, context?: string) => void;
    }
    const capture = vi.fn();
    const globalObj = globalThis as unknown as { __monitoring__?: Monitor };
    globalObj.__monitoring__ = { captureException: capture };
    vi.stubEnv('VITE_SENTRY_DSN', 'dsn');
    const err = {
      message: 'fail',
      client_secret: 'secret123',
      card: { number: '4242424242424242' },
    };
    logError(err, 'context');
    expect(capture).toHaveBeenCalled();
    const sent = capture.mock.calls[0][0];
    const output = JSON.stringify(sent);
    expect(output).not.toContain('secret123');
    expect(output).not.toContain('424242');
    expect(capture.mock.calls[0][1]).toBe('context');
    delete globalObj.__monitoring__;
    vi.unstubAllEnvs();
  });
});
